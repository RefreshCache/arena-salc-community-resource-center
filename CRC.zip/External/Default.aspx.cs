﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Arena.MyPlan;
using System.Web.Security;
using Arena.Custom.SALC.ResourceCenter.Entity;

namespace MyPlan
{

    public partial class _Default : System.Web.UI.Page
    {
        private MembershipUser muUser = null;
        private string nodeName = string.Empty;

        private int clientId = -1;
        private int helpId = -1;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (User.Identity.IsAuthenticated)
            {
                //litDebug.Text = User.Identity.Name;
                pLoggedIn.Visible = true;
                pGeneral.Visible = false;

                MyPlanMembershipProvider membership = new MyPlanMembershipProvider();
                membership.Initialize("Arena", new System.Collections.Specialized.NameValueCollection());
                muUser = membership.GetUser(User.Identity.Name, false);

                clientId = (int)muUser.ProviderUserKey;
                helpId = DataHelper.GetHelpId(clientId);

                bool hasGoals = false;

                rtvGoals.Nodes.Clear();

                GoalCollection goals = GoalCollection.LoadAll(helpId, 1);
                foreach (GoalType gt in GoalTypeCollection.LoadAll(1))
                {
                    hasGoals = false;
                    Telerik.Web.UI.RadTreeNode typeNode = new Telerik.Web.UI.RadTreeNode(gt.Name, "");
                    foreach (Goal goal in goals)
                    {
                        if (gt.Id == goal.Type)
                        {
                            hasGoals = true;
                            Telerik.Web.UI.RadTreeNode goalNode = new Telerik.Web.UI.RadTreeNode(goal.Name, goal.Id.ToString());
                            if (goal.IsClosed)
                            {
                                goalNode.ImageUrl = "~/Images/sm_check.png";
                                goalNode.Value = "";
                            }
                            else
                            {
                                goalNode.ImageUrl = "~/Images/warning.gif";
                            }
                            typeNode.Nodes.Add(goalNode);
                            if (goalNode.Text == hfNodeName.Value) goalNode.Selected = true;
                            if (typeNode.Text == hfNodeName.Value) typeNode.Selected = true;
                        }
                    }
                    typeNode.Expanded = true;

                    if (hasGoals)
                    {
                        rtvGoals.Nodes.Add(typeNode);
                    }

                }
                ShowReports();
            }
            else
            {
                pLoggedIn.Visible = false;
                pGeneral.Visible = true;
            }
            
        }

        protected void ShowReports()
        {
            DataTable dti = ProgressReportCollection.LoadAll(helpId, 0).DataTable();
            DataTable dto = dti.Clone();

            for (int i = dti.Rows.Count - 1; i >= 0; i--)
            {
                dto.ImportRow(dti.Rows[i]);
            }
            dgReports.DataSource = dto;
            dgReports.DataBind();
        }

        protected void Goals_Click(object sender, Telerik.Web.UI.RadTreeNodeEventArgs e)
        {
            if (e.Node.Value != "")
            {
                //valid click
                pNewReport.Visible = true;
                hfGoalId.Value = e.Node.Value;
                int gid = Convert.ToInt32(e.Node.Value);
                Goal g = new Goal(gid);
                lbReportGoal.Text = g.Name;

                if (g.UserClosable)
                {
                    ddlReportClosed.Visible = true;
                    lbReportDone.Visible = true;
                }
                else
                {
                    lbReportDone.Visible = false;
                    ddlReportClosed.Visible = false;
                }

                tbReport.Text = "";
                ddlReportClosed.SelectedValue = "0";
            }
            else
            {
                pNewReport.Visible = false;
            }
            hfNodeName.Value = e.Node.Text;
            e.Node.Selected = true;
            upWhole.Update();
        }

        protected void Cancel_Click(object sender, EventArgs e)
        {
            pNewReport.Visible = false;
            upWhole.Update();
        }

        protected void Save_Click(object sender, EventArgs e)
        {
            if (Page.IsValid)
            {
                ProgressReport pr = new ProgressReport();
                pr.GoalId = Convert.ToInt32(hfGoalId.Value);
                pr.Description = tbReport.Text;
                pr.Save(clientId.ToString());
                if (ddlReportClosed.SelectedValue == "1")
                {
                    Goal g = new Goal(Convert.ToInt32(hfGoalId.Value));
                    g.IsClosed = true;
                    g.Save(User.Identity.Name);
                }
                pNewReport.Visible = false;
                ShowReports();
                upWhole.Update();
                Response.Redirect("default.aspx");
            }
        }
    }
}
