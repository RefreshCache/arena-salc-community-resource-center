using System;
using System.IO;

namespace Arena.Custom.SALC.ResourceCenter.DataLayer
{
    public class ResourceCenterTextFile
    {
        public static string ReadFile(string filespec)
        {
            using (StreamReader sr = new StreamReader(filespec))
            {
                return sr.ReadToEnd();
            }
        }
    }
}