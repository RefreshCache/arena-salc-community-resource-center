using System;
using System.Collections;
using System.Data;
using System.Data.SqlClient;
using Arena.DataLib;

namespace Arena.Custom.SALC.ResourceCenter.DataLayer
{
    public class ResourceCenterPersonData : SqlData
    {
        /// <summary>
        /// Class constructor.
        /// </summary>
        public ResourceCenterPersonData()
        {
        }

        /// <summary>
        /// Returns a <see cref="System.Data.SqlClient.SqlDataReader">SqlDataReader</see> object
        /// containing the FoodBag with the ID specified
        /// </summary>
        /// <param name="foodBagID">FoodBag ID</param>
        /// <returns><see cref="System.Data.SqlClient.SqlDataReader">SqlDataReader</see></returns>
        public SqlDataReader GetResourceCenterPersonByID(int Id)
        {
            ArrayList lst = new ArrayList();

            lst.Add(new SqlParameter("@PersonId", Id));

            try
            {
                return this.ExecuteSqlDataReader("cust_sp_salc_rc_getbyid_client", lst);
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                lst = null;
            }
        }
  		
        public SqlDataReader GetResourceCenterPersonByPersonId(int personId)
        {
            ArrayList lst = new ArrayList();

            lst.Add(new SqlParameter("@PersonId", personId));

            try
            {
                return this.ExecuteSqlDataReader("cust_sp_salc_rc_getbyid_client", lst);
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                lst = null;
            }
        }
  		
        public SqlDataReader GetAllResourceCenterPersons(int orgId)
        {
            ArrayList lst = new ArrayList();

            lst.Add(new SqlParameter("@FirstName", ""));
            lst.Add(new SqlParameter("@LastName", ""));
            lst.Add(new SqlParameter("@Phone", ""));
            lst.Add(new SqlParameter("@Street", ""));
            lst.Add(new SqlParameter("@ZipCode", ""));
            lst.Add(new SqlParameter("@OrganizationId", orgId));

            try
            {
                return this.ExecuteSqlDataReader("cust_sp_salc_rc_getall_client", lst);
            }
            catch (SqlException ex)
            {
                throw ex;
            }
        }

        public SqlDataReader GetAllResourceCenterPersons(int orgId, string firstName, string lastName, string phone, string street, string zipCode)
        {
            ArrayList lst = new ArrayList();

            lst.Add(new SqlParameter("@FirstName", firstName));
            lst.Add(new SqlParameter("@LastName", lastName));
            lst.Add(new SqlParameter("@Phone", phone));
            lst.Add(new SqlParameter("@Street", street));
            lst.Add(new SqlParameter("@ZipCode", zipCode));
            lst.Add(new SqlParameter("@OrganizationId", orgId));

            try
            {
                return this.ExecuteSqlDataReader("cust_sp_salc_rc_getall_client", lst);
            }
            catch (SqlException ex)
            {
                throw ex;
            }
        }

        public SqlDataReader GetAllResourceCenterPersons(int orgId, string firstName, string lastName, string phone, string street, string zipCode, int helpIdExclude)
        {
            ArrayList lst = new ArrayList();

            lst.Add(new SqlParameter("@FirstName", firstName));
            lst.Add(new SqlParameter("@LastName", lastName));
            lst.Add(new SqlParameter("@Phone", phone));
            lst.Add(new SqlParameter("@Street", street));
            lst.Add(new SqlParameter("@ZipCode", zipCode));
            lst.Add(new SqlParameter("@HelpIdExclude", helpIdExclude));
            lst.Add(new SqlParameter("@OrganizationId", orgId));

            try
            {
                return this.ExecuteSqlDataReader("cust_sp_salc_rc_getall_client", lst);
            }
            catch (SqlException ex)
            {
                throw ex;
            }
        }

        public SqlDataReader GetFamily(int orgId, int personId)
        {
            ArrayList lst = new ArrayList();

            lst.Add(new SqlParameter("@PersonId", personId));
            lst.Add(new SqlParameter("@OrganizationId", orgId));

            try
            {
                return this.ExecuteSqlDataReader("cust_sp_salc_rc_misc_getfamilylist", lst);
            }
            catch (SqlException ex)
            {
                throw ex;
            }
        }

        public SqlDataReader GetHelpList(int helpId)
        {
            ArrayList lst = new ArrayList();

            lst.Add(new SqlParameter("@HelpId", helpId));

            try
            {
                return this.ExecuteSqlDataReader("cust_sp_salc_rc_misc_getclientsonhelp", lst);
            }
            catch (SqlException ex)
            {
                throw ex;
            }
        }

        public int CountSimilars(string firstName, string lastName, string street, string zipCode, int excludeID)
        {
            ArrayList lst = new ArrayList();

            lst.Add(new SqlParameter("@FirstName", firstName));
            lst.Add(new SqlParameter("@LastName", lastName));
            lst.Add(new SqlParameter("@Street", street));
            lst.Add(new SqlParameter("@ZipCode", zipCode));
            lst.Add(new SqlParameter("@Exclude", excludeID));

            SqlParameter paramOut = new SqlParameter();
            paramOut.ParameterName = "@COUNT";
            paramOut.Direction = ParameterDirection.Output;
            paramOut.SqlDbType = SqlDbType.Int;
            lst.Add(paramOut);

            try
            {
                this.ExecuteSqlDataReader("cust_sp_salc_rc_misc_clientcount", lst);
                return Convert.ToInt32(((SqlParameter)(lst[lst.Count - 1])).Value.ToString());
            }
            catch (SqlException ex)
            {
                throw ex;
            }
        }
  		
        /// <summary>
        /// deletes a FoodBag record.
        /// </summary>
        /// <param name="roleID">The poll_id key to delete.</param>
        public void DeleteResourceCenterPerson(int Id)
        {
            ArrayList lst = new ArrayList();

            lst.Add(new SqlParameter("@Id", Id));

            try
            {
                this.ExecuteNonQuery("cust_sp_salc_rc_del_client", lst);
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                lst = null;
            }
        }

        public void BulkChangeAddress(int personId, string street, string city, string zip, string state, string county, string userId)
        {
            ArrayList lst = new ArrayList();

            lst.Add(new SqlParameter("@PersonId", personId));
            lst.Add(new SqlParameter("@UserId", userId));
            lst.Add(new SqlParameter("@Street", street));
            lst.Add(new SqlParameter("@City", city));
            lst.Add(new SqlParameter("@Zip", zip));
            lst.Add(new SqlParameter("@State", state));
            lst.Add(new SqlParameter("@County", county));

            try
            {
                this.ExecuteNonQuery("cust_sp_salc_rc_misc_bulkchangeaddress", lst);
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                lst = null;
            }
        }

        /// <summary>
        /// saves FoodBag record
        /// </summary>
        /// <returns><see cref="System.Data.SqlClient.SqlDataReader">SqlDataReader</see></returns>
        public int SaveResourceCenterPerson(int orgId, int personId, int numAdults, int numChildren, string county, int helpRequested, string notes, string userId, string nickName, string firstName, string middleName, string lastName, string suffix, DateTime birthday, string gender, string email, string streetAddress, string city, string state, string postalCode, string ssn, string schoolDistrict, decimal incomeEmployment, decimal incomeUnemployment, decimal incomeMFIP, decimal incomeChildSupport, decimal incomeMA, decimal incomeSSISSDI, decimal incomeOther, decimal cashOnHand, decimal issuesOfNote, DateTime lasteDateWorked,
            int mstatus, int dlicense, int ebt, decimal foodSupport, DateTime assistanceApplied, string foodShelf, DateTime foodShelfVisit, string caseMgr1Name, string caseMgr1Agency, string caseMgr1Phone, string caseMgr2Name, string caseMgr2Agency, string caseMgr2Phone,
            string emgAssist1Agency, string emgAssist1CaseMgr, string emgAssist1Phone, DateTime emgAssist1Date, decimal emgAssist1Amount, int emgAssist1Status,
            string emgAssist2Agency, string emgAssist2CaseMgr, string emgAssist2Phone, DateTime emgAssist2Date, decimal emgAssist2Amount, int emgAssist2Status,
            int pastShelter, DateTime pastShelterDate, int pastUnsheltered, DateTime pastUnshelteredDate, int pastChemical, DateTime pastChemicalDate, int pastTransitional, DateTime pastTransitionalDate,
            int pastDoubled, DateTime pastDoubledDate, int pastEviction, DateTime pastEvictionDate, int pastForeclosure, DateTime pastForeclosureDate,
            string phoneHome, string phoneWork, string phoneMobile, string phoneOther, string caseMgr1Notes, string caseMgr2Notes, int empFreq, DateTime empDate,
            int mfipDay, DateTime childsupportDate, DateTime otherincomeDate, string message, int flag)
        {
            ArrayList lst = new ArrayList();
  			
            //lst.Add(new SqlParameter("@id", Id));
            lst.Add(new SqlParameter("@ClientId", personId));
            lst.Add(new SqlParameter("@UserID", userId));
            lst.Add(new SqlParameter("@NumAdults", numAdults));         //used for 3rd party status
            lst.Add(new SqlParameter("@NumChildren", numChildren));
            lst.Add(new SqlParameter("@County", county));
            lst.Add(new SqlParameter("@HelpRequested", helpRequested));
            lst.Add(new SqlParameter("@Notes", notes));
            lst.Add(new SqlParameter("@NickName", nickName));
            lst.Add(new SqlParameter("@FirstName", firstName));
            lst.Add(new SqlParameter("@MiddleName", middleName));
            lst.Add(new SqlParameter("@LastName", lastName));
            lst.Add(new SqlParameter("@Suffix", suffix));
            lst.Add(new SqlParameter("@Birthday", birthday));
            lst.Add(new SqlParameter("@Gender", gender));
            lst.Add(new SqlParameter("@Email", email));
            lst.Add(new SqlParameter("@Street", streetAddress));
            lst.Add(new SqlParameter("@City", city));
            lst.Add(new SqlParameter("@State", state));
            lst.Add(new SqlParameter("@PostalCode", postalCode));
            lst.Add(new SqlParameter("@SSN", ssn));
            lst.Add(new SqlParameter("@SchoolDistrict", schoolDistrict));
            lst.Add(new SqlParameter("@IncomeEmployment", incomeEmployment));
            lst.Add(new SqlParameter("@IncomeMFIP", incomeMFIP));
            lst.Add(new SqlParameter("@IncomeMA", incomeMA));
            lst.Add(new SqlParameter("@IncomeChildSupport", incomeChildSupport));
            lst.Add(new SqlParameter("@IncomeUnemployment", incomeUnemployment));
            lst.Add(new SqlParameter("@IncomeSSISSDI", incomeSSISSDI));
            lst.Add(new SqlParameter("@IncomeOther", incomeOther));
            lst.Add(new SqlParameter("@CashOnHand", cashOnHand));
            lst.Add(new SqlParameter("@IssuesOfNote", issuesOfNote));
            lst.Add(new SqlParameter("@LastDateWorked", lasteDateWorked));
            lst.Add(new SqlParameter("@MaritalStatus", mstatus));
            lst.Add(new SqlParameter("@DriversLicense", dlicense));
            lst.Add(new SqlParameter("@EBT", ebt));
            lst.Add(new SqlParameter("@FoodSupport", foodSupport));
            lst.Add(new SqlParameter("@AssistanceApplied", assistanceApplied));
            lst.Add(new SqlParameter("@FoodShelf", foodShelf));
            lst.Add(new SqlParameter("@FoodShelfVisit", foodShelfVisit));
            lst.Add(new SqlParameter("@CaseMgr1Name", caseMgr1Name));
            lst.Add(new SqlParameter("@CaseMgr1Agency", caseMgr1Agency));
            lst.Add(new SqlParameter("@CaseMgr1Phone", caseMgr1Phone));
            lst.Add(new SqlParameter("@CaseMgr1Notes", caseMgr1Notes));
            lst.Add(new SqlParameter("@CaseMgr2Name", caseMgr2Name));
            lst.Add(new SqlParameter("@CaseMgr2Agency", caseMgr2Agency));
            lst.Add(new SqlParameter("@CaseMgr2Phone", caseMgr2Phone));
            lst.Add(new SqlParameter("@CaseMgr2Notes", caseMgr2Notes));
            lst.Add(new SqlParameter("@EmgAssist1Agency", emgAssist1Agency));
            lst.Add(new SqlParameter("@EmgAssist1CaseMgr", emgAssist1CaseMgr));
            lst.Add(new SqlParameter("@EmgAssist1Phone", emgAssist1Phone));
            lst.Add(new SqlParameter("@EmgAssist1Date", emgAssist1Date));
            lst.Add(new SqlParameter("@EmgAssist1Amount", emgAssist1Amount));
            lst.Add(new SqlParameter("@EmgAssist1Status", emgAssist1Status));
            lst.Add(new SqlParameter("@EmgAssist2Agency", emgAssist2Agency));
            lst.Add(new SqlParameter("@EmgAssist2CaseMgr", emgAssist2CaseMgr));
            lst.Add(new SqlParameter("@EmgAssist2Phone", emgAssist2Phone));
            lst.Add(new SqlParameter("@EmgAssist2Date", emgAssist2Date));
            lst.Add(new SqlParameter("@EmgAssist2Amount", emgAssist2Amount));
            lst.Add(new SqlParameter("@EmgAssist2Status", emgAssist2Status));
            lst.Add(new SqlParameter("@PastShelter", pastShelter));
            lst.Add(new SqlParameter("@PastShelterDate", pastShelterDate));
            lst.Add(new SqlParameter("@PastUnsheltered", pastUnsheltered));
            lst.Add(new SqlParameter("@PastUnshelteredDate", pastUnshelteredDate));
            lst.Add(new SqlParameter("@PastChemical", pastChemical));
            lst.Add(new SqlParameter("@PastChemicalDate", pastChemicalDate));
            lst.Add(new SqlParameter("@PastTransitional", pastTransitional));
            lst.Add(new SqlParameter("@PastTransitionalDate", pastTransitionalDate));
            lst.Add(new SqlParameter("@PastDoubled", pastDoubled));
            lst.Add(new SqlParameter("@PastDoubledDate", pastDoubledDate));
            lst.Add(new SqlParameter("@PastEviction", pastEviction));
            lst.Add(new SqlParameter("@PastEvictionDate", pastEvictionDate));
            lst.Add(new SqlParameter("@PastForeclosure", pastForeclosure));
            lst.Add(new SqlParameter("@PastForeclosureDate", pastForeclosureDate));
            lst.Add(new SqlParameter("@PhoneHome", phoneHome));
            lst.Add(new SqlParameter("@PhoneWork", phoneWork));
            lst.Add(new SqlParameter("@PhoneMobile", phoneMobile));
            lst.Add(new SqlParameter("@PhoneOther", phoneOther));
            lst.Add(new SqlParameter("@EmpFreq", empFreq));
            lst.Add(new SqlParameter("@EmpDate", empDate));
            lst.Add(new SqlParameter("@MFIPDay", mfipDay));
            lst.Add(new SqlParameter("@ChildSupportDate", childsupportDate));
            lst.Add(new SqlParameter("@OtherSourcesDate", otherincomeDate));
            lst.Add(new SqlParameter("@Message", message));
            lst.Add(new SqlParameter("@Flag", flag));
            lst.Add(new SqlParameter("@OrganizationId", orgId));

            SqlParameter paramOut = new SqlParameter();
            paramOut.ParameterName = "@ID";
            paramOut.Direction = ParameterDirection.Output;
            paramOut.SqlDbType = SqlDbType.Int;
            lst.Add(paramOut);
  			
            try
            {
                this.ExecuteNonQuery("cust_sp_salc_rc_save_client", lst);
                //return (int)((SqlParameter)(lst[lst.Count - 1])).Value;
                return Convert.ToInt32(((SqlParameter)(lst[lst.Count - 1])).Value.ToString());
            }
            catch (SqlException ex)
            {
                if (ex.Number == 2627) //Unique Key Violation
                    return -1;
                else
                    throw ex;
            }
            finally
            {
                lst = null;
            }
        }
    }
}