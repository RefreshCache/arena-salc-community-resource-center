using System;
using System.Collections;
using System.Data;
using System.Data.SqlClient;
using Arena.DataLib;

namespace Arena.Custom.SALC.ResourceCenter.DataLayer
{
    public class ResourceCenterMealData : SqlData
    {
        /// <summary>
        /// Class constructor.
        /// </summary>
        public ResourceCenterMealData()
        {
        }

        /// <summary>
        /// Returns a <see cref="System.Data.SqlClient.SqlDataReader">SqlDataReader</see> object
        /// containing the FoodBag with the ID specified
        /// </summary>
        /// <param name="foodBagID">FoodBag ID</param>
        /// <returns><see cref="System.Data.SqlClient.SqlDataReader">SqlDataReader</see></returns>
        public SqlDataReader GetResourceCenterMealByID(int Id)
        {
            ArrayList lst = new ArrayList();

            lst.Add(new SqlParameter("@id", Id));

            try
            {
                return this.ExecuteSqlDataReader("cust_sp_salc_rc_getbyid_meal", lst);
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                lst = null;
            }
        }

        public SqlDataReader GetAllResourceCenterMeals(int orgId)
        {
            ArrayList lst = new ArrayList();
            lst.Add(new SqlParameter("@StartDate", new DateTime(1901, 1, 1)));
            lst.Add(new SqlParameter("@EndDate", new DateTime(2199, 12, 31)));
            lst.Add(new SqlParameter("@OrganizationId", orgId));

            try
            {
                return this.ExecuteSqlDataReader("cust_sp_salc_rc_getall_meal");
            }
            catch (SqlException ex)
            {
                throw ex;
            }
        }

        public SqlDataReader GetAllResourceCenterMeals(DateTime startDate, DateTime endDate, int orgId)
        {
            ArrayList lst = new ArrayList();
            lst.Add(new SqlParameter("@StartDate", startDate));
            lst.Add(new SqlParameter("@EndDate", endDate));
            lst.Add(new SqlParameter("@OrganizationId", orgId));

            try
            {
                return this.ExecuteSqlDataReader("cust_sp_salc_rc_getall_meal", lst);
            }
            catch (SqlException ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// deletes a FoodBag record.
        /// </summary>
        /// <param name="roleID">The poll_id key to delete.</param>
        public void DeleteResourceCenterMeal(int Id)
        {
            ArrayList lst = new ArrayList();

            lst.Add(new SqlParameter("@MealId", Id));

            try
            {
                this.ExecuteNonQuery("cust_sp_salc_rc_del_meal", lst);
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                lst = null;
            }
        }

        /// <summary>
        /// saves FoodBag record
        /// </summary>
        /// <returns><see cref="System.Data.SqlClient.SqlDataReader">SqlDataReader</see></returns>
        public int SaveResourceCenterMeal(int mealId, string userId, DateTime date, int served, int meals, int dist, int pounds)
        {
            ArrayList lst = new ArrayList();

            lst.Add(new SqlParameter("@MealId", mealId));
            lst.Add(new SqlParameter("@UserId", userId));
            lst.Add(new SqlParameter("@Date", date));
            lst.Add(new SqlParameter("@Served", served));
            lst.Add(new SqlParameter("@Meals", meals));
            lst.Add(new SqlParameter("@Dist", dist));
            lst.Add(new SqlParameter("@Pounds", pounds));

            SqlParameter paramOut = new SqlParameter();
            paramOut.ParameterName = "@ID";
            paramOut.Direction = ParameterDirection.Output;
            paramOut.SqlDbType = SqlDbType.Int;
            lst.Add(paramOut);

            try
            {
                this.ExecuteNonQuery("cust_sp_salc_rc_save_meal", lst);
                return Convert.ToInt32(((SqlParameter)(lst[lst.Count - 1])).Value.ToString());
            }
            catch (SqlException ex)
            {
                if (ex.Number == 2627) //Unique Key Violation
                    return -1;
                else
                    throw ex;
            }
            finally
            {
                lst = null;
            }
        }
    }
}