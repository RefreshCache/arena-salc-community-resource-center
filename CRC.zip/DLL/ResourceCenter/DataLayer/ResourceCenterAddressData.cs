using System.Collections;
using System.Data.SqlClient;
using Arena.DataLib;

namespace Arena.Custom.SALC.ResourceCenter.DataLayer
{
    public class ResourceCenterAddressData : SqlData
    {
        /// <summary>
        /// Class constructor.
        /// </summary>
        public ResourceCenterAddressData()
        {
        }

        /// <summary>
        /// Returns a <see cref="System.Data.SqlClient.SqlDataReader">SqlDataReader</see> object
        /// containing the FoodBag with the ID specified
        /// </summary>
        /// <param name="foodBagID">FoodBag ID</param>
        /// <returns><see cref="System.Data.SqlClient.SqlDataReader">SqlDataReader</see></returns>
        public SqlDataReader GetResourceCenterHelpByID(int id)
        {
            ArrayList lst = new ArrayList();

            lst.Add(new SqlParameter("@id", id));

            try
            {
                return this.ExecuteSqlDataReader("cust_sp_salc_rc_getbyid_address", lst);
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                lst = null;
            }
        }

        public SqlDataReader GetAllResourceCenterAddresses()
        {
            try
            {
                return this.ExecuteSqlDataReader("cust_sp_salc_rc_getall_address");
            }
            catch (SqlException ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// deletes a FoodBag record.
        /// </summary>
        /// <param name="roleID">The poll_id key to delete.</param>
        public void DeleteResourceCenterAddress(int id)
        {
            ArrayList lst = new ArrayList();

            lst.Add(new SqlParameter("@Id", id));

            try
            {
                this.ExecuteNonQuery("cust_sp_salc_rc_del_address", lst);
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                lst = null;
            }
        }

        /// <summary>
        /// saves FoodBag record
        /// </summary>
        /// <returns><see cref="System.Data.SqlClient.SqlDataReader">SqlDataReader</see></returns>
        public int SaveResourceCenterAddress(int addressId)
        {
            ArrayList lst = new ArrayList();

            //lst.Add(new SqlParameter("@id", Id));
            lst.Add(new SqlParameter("@Id", addressId));

            try
            {
                this.ExecuteNonQuery("cust_sp_salc_rc_save_address", lst);
                //return (int)((SqlParameter)(lst[lst.Count - 1])).Value;
            }
            catch (SqlException ex)
            {
                if (ex.Number == 2627) //Unique Key Violation
                    return -1;
                else
                    throw ex;
            }
            finally
            {
                lst = null;
            }
            return 0;
        }
    }
}