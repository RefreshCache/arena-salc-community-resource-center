using System;
using System.Collections;
using System.Data;
using System.Data.SqlClient;
using Arena.DataLib;

namespace Arena.Custom.SALC.ResourceCenter.DataLayer
{
    public class ResourceCenterLocationAssignmentData : SqlData
    {
        /// <summary>
        /// Class constructor.
        /// </summary>
        public ResourceCenterLocationAssignmentData()
        {
        }

        public SqlDataReader GetResourceCenterLocationAssignmentByID(int id)
        {
            ArrayList lst = new ArrayList();

            lst.Add(new SqlParameter("@id", id));

            try
            {
                return this.ExecuteSqlDataReader("cust_sp_salc_rc_getbyid_locationassignment", lst);
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                lst = null;
            }
        }

        public SqlDataReader GetAllResourceCenterLocationAssignments(int locationAssignmentId)
        {
            ArrayList lst = new ArrayList();

            lst.Add(new SqlParameter("@LocationAssignmentId", locationAssignmentId));

            try
            {
                return this.ExecuteSqlDataReader("cust_sp_salc_rc_getall_locationassignment", lst);
            }
            catch (SqlException ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// deletes a FoodBag record.
        /// </summary>
        /// <param name="id">The poll_id key to delete.</param>
        public void DeleteResourceCenterLocationAssignment(int id)
        {
            ArrayList lst = new ArrayList();

            lst.Add(new SqlParameter("@LocationAssignmentId", id));

            try
            {
                this.ExecuteNonQuery("cust_sp_salc_rc_del_locationassignment", lst);
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                lst = null;
            }
        }
          
        public int SaveResourceCenterLocationAssignment(int orgId, int locationAssignmentId, int helpId, DateTime effectiveDate, string reason, int facilityId, int locationId, string locationName, string userName)
        {
            ArrayList lst = new ArrayList();

            lst.Add(new SqlParameter("@LocationAssignmentId", locationAssignmentId));
            lst.Add(new SqlParameter("@HelpId", helpId));
            lst.Add(new SqlParameter("@EffectiveDate", effectiveDate));
            lst.Add(new SqlParameter("@Reason", reason));
            lst.Add(new SqlParameter("@FacilityId", facilityId));
            lst.Add(new SqlParameter("@LocationId", locationId));
            lst.Add(new SqlParameter("@UserName", userName));
            lst.Add(new SqlParameter("@OrganizationId", orgId));

            SqlParameter paramOut = new SqlParameter();
            paramOut.ParameterName = "@ID";
            paramOut.Direction = ParameterDirection.Output;
            paramOut.SqlDbType = SqlDbType.Int;
            lst.Add(paramOut);

            try
            {
                this.ExecuteNonQuery("cust_sp_salc_rc_save_locationassignment", lst);
                return Convert.ToInt32(((SqlParameter)(lst[lst.Count - 1])).Value.ToString());
            }
            catch (SqlException ex)
            {
                if (ex.Number == 2627) //Unique Key Violation
                    return -1;
                else
                    throw ex;
            }
            finally
            {
                lst = null;
            }
        }
    }
}