using System;
using System.Collections;
using System.Data;
using System.Data.SqlClient;
using Arena.DataLib;

namespace Arena.Custom.SALC.ResourceCenter.DataLayer
{
    public class ResourceCenterNoteData : SqlData
    {
        /// <summary>
        /// Class constructor.
        /// </summary>
        public ResourceCenterNoteData()
        {
        }

        /// <summary>
        /// Returns a <see cref="System.Data.SqlClient.SqlDataReader">SqlDataReader</see> object
        /// containing the FoodBag with the ID specified
        /// </summary>
        /// <param name="foodBagID">FoodBag ID</param>
        /// <returns><see cref="System.Data.SqlClient.SqlDataReader">SqlDataReader</see></returns>
        public SqlDataReader GetResourceCenterNoteByID(int Id)
        {
            ArrayList lst = new ArrayList();

            lst.Add(new SqlParameter("@id", Id));

            try
            {
                return this.ExecuteSqlDataReader("cust_sp_salc_rc_getbyid_note", lst);
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                lst = null;
            }
        }

        public SqlDataReader GetAllResourceCenterNotes(int orgId, DateTime startDate, DateTime endDate, int helpId, int clientId)
        {
            ArrayList lst = new ArrayList();
            lst.Add(new SqlParameter("@StartDate", startDate));
            lst.Add(new SqlParameter("@EndDate", endDate));
            lst.Add(new SqlParameter("@ClientId", clientId));
            lst.Add(new SqlParameter("@HelpId", helpId));
            lst.Add(new SqlParameter("@OrganizationId", orgId));

            try
            {
                return this.ExecuteSqlDataReader("cust_sp_salc_rc_getall_note", lst);
            }
            catch (SqlException ex)
            {
                throw ex;
            }
        }

        public SqlDataReader GetAllResourceCenterNotes(DateTime startDate, DateTime endDate, int orgId)
        {
            ArrayList lst = new ArrayList();
            lst.Add(new SqlParameter("@StartDate", startDate));
            lst.Add(new SqlParameter("@EndDate", endDate));
            lst.Add(new SqlParameter("@OrganizationId", orgId));

            try
            {
                return this.ExecuteSqlDataReader("cust_sp_salc_rc_getall_note", lst);
            }
            catch (SqlException ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// deletes a FoodBag record.
        /// </summary>
        /// <param name="roleID">The poll_id key to delete.</param>
        public void DeleteResourceCenterNote(int Id)
        {
            ArrayList lst = new ArrayList();

            lst.Add(new SqlParameter("@NoteId", Id));

            try
            {
                this.ExecuteNonQuery("cust_sp_salc_rc_del_note", lst);
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                lst = null;
            }
        }

        /// <summary>
        /// saves FoodBag record
        /// </summary>
        /// <returns><see cref="System.Data.SqlClient.SqlDataReader">SqlDataReader</see></returns>
        public int SaveResourceCenterNote(int noteId, string userId, DateTime tagDate, int clientId, int helpId, string note, int orgId)
        {
            ArrayList lst = new ArrayList();

            lst.Add(new SqlParameter("@NoteId", noteId));
            lst.Add(new SqlParameter("@UserId", userId));
            lst.Add(new SqlParameter("@TagDate", tagDate));
            lst.Add(new SqlParameter("@Note", note));
            lst.Add(new SqlParameter("@ClientId", clientId));
            lst.Add(new SqlParameter("@HelpId", helpId));
            lst.Add(new SqlParameter("@OrganizationId", orgId));

            SqlParameter paramOut = new SqlParameter();
            paramOut.ParameterName = "@ID";
            paramOut.Direction = ParameterDirection.Output;
            paramOut.SqlDbType = SqlDbType.Int;
            lst.Add(paramOut);

            try
            {
                this.ExecuteNonQuery("cust_sp_salc_rc_save_note", lst);
                return Convert.ToInt32(((SqlParameter)(lst[lst.Count - 1])).Value.ToString());
            }
            catch (SqlException ex)
            {
                if (ex.Number == 2627) //Unique Key Violation
                    return -1;
                else
                    throw ex;
            }
            finally
            {
                lst = null;
            }
        }
    }
}