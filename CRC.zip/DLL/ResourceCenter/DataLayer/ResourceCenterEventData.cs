using System;
using System.Collections;
using System.Data.SqlClient;
using Arena.DataLib;

namespace Arena.Custom.SALC.ResourceCenter.DataLayer
{
    public class ResourceCenterEventData : SqlData
    {
        public ResourceCenterEventData()
        {
        }

        public SqlDataReader GetAllResourceCenterEvents(int orgId, DateTime startDate, DateTime endDate, int personId, int helpId)
        {
            ArrayList lst = new ArrayList();
            lst.Add(new SqlParameter("@StartDate", startDate));
            lst.Add(new SqlParameter("@EndDate", endDate));
            lst.Add(new SqlParameter("@PersonId", personId));
            lst.Add(new SqlParameter("@HelpSubTypeId", helpId));
            lst.Add(new SqlParameter("@OrganizationId", orgId));

            try
            {
                return this.ExecuteSqlDataReader("cust_sp_salc_rc_getall_event", lst);
            }
            catch (SqlException ex)
            {
                throw ex;
            }
        }
    }
}