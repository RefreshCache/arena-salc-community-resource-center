using System;
using System.Collections;
using System.Data;
using System.Data.SqlClient;
using Arena.DataLib;

namespace Arena.Custom.SALC.ResourceCenter.DataLayer
{
    public class GoalTypeData : SqlData
    {
        /// <summary>
        /// Class constructor.
        /// </summary>
        public GoalTypeData()
        {
        }

        /// <summary>
        /// Returns a <see cref="System.Data.SqlClient.SqlDataReader">SqlDataReader</see> object
        /// containing the FoodBag with the ID specified
        /// </summary>
        /// <param name="foodBagID">FoodBag ID</param>
        /// <returns><see cref="System.Data.SqlClient.SqlDataReader">SqlDataReader</see></returns>
        public SqlDataReader GetResourceCenterGoalTypeByID(int id)
        {
            ArrayList lst = new ArrayList();

            lst.Add(new SqlParameter("@id", id));

            try
            {
                return this.ExecuteSqlDataReader("cust_sp_salc_rc_getbyid_goaltype", lst);
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                lst = null;
            }
        }

        public SqlDataReader GetAllResourceCenterGoalTypes(int orgId)
        {
            ArrayList lst = new ArrayList();

            lst.Add(new SqlParameter("@Enabled", 1));
            lst.Add(new SqlParameter("@OrganizationId", orgId));

            try
            {
                return this.ExecuteSqlDataReader("cust_sp_salc_rc_getall_goaltype", lst);
            }
            catch (SqlException ex)
            {
                throw ex;
            }
        }

        public SqlDataReader GetAllResourceCenterGoalTypes(int orgId, bool includingDisabled)
        {
            ArrayList lst = new ArrayList();

            lst.Add(new SqlParameter("@Enabled", includingDisabled ? 0 : 1));
            lst.Add(new SqlParameter("@OrganizationId", orgId));

            try
            {
                return this.ExecuteSqlDataReader("cust_sp_salc_rc_getall_goaltype", lst);
            }
            catch (SqlException ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// deletes a FoodBag record.
        /// </summary>
        /// <param name="roleID">The poll_id key to delete.</param>
        public void DeleteResourceCenterGoalType(int id)
        {
            ArrayList lst = new ArrayList();

            lst.Add(new SqlParameter("@SubTypeId", id));

            try
            {
                this.ExecuteNonQuery("cust_sp_salc_rc_del_goaltype", lst);
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                lst = null;
            }
        }

        /// <summary>
        /// saves FoodBag record
        /// </summary>
        /// <returns><see cref="System.Data.SqlClient.SqlDataReader">SqlDataReader</see></returns>
        public int SaveResourceCenterGoalType(int orgId, int goaltypeId, string name, bool enabled)
        {
            ArrayList lst = new ArrayList();

            lst.Add(new SqlParameter("@GoalTypeId", goaltypeId));
            lst.Add(new SqlParameter("@Name", name));
            lst.Add(new SqlParameter("@Enabled", enabled ? 1 : 0));
            lst.Add(new SqlParameter("@OrganizationId", orgId));

            SqlParameter paramOut = new SqlParameter();
            paramOut.ParameterName = "@ID";
            paramOut.Direction = ParameterDirection.Output;
            paramOut.SqlDbType = SqlDbType.Int;
            lst.Add(paramOut);

            try
            {
                this.ExecuteNonQuery("cust_sp_salc_rc_save_goaltype", lst);
                return Convert.ToInt32(((SqlParameter)(lst[lst.Count - 1])).Value.ToString());
            }
            catch (SqlException ex)
            {
                if (ex.Number == 2627) //Unique Key Violation
                    return -1;
                else
                    throw ex;
            }
            finally
            {
                lst = null;
            }
        }
    }
}