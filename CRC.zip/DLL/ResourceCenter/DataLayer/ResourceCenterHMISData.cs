using System;
using System.Collections;
using System.Data;
using System.Data.SqlClient;
using Arena.DataLib;

namespace Arena.Custom.SALC.ResourceCenter.DataLayer
{
    public class ResourceCenterHMISData : SqlData
    {
        /// <summary>
        /// Class constructor.
        /// </summary>
        public ResourceCenterHMISData()
        {
        }

        public SqlDataReader GetResourceCenterHMISByID(int id)
        {
            ArrayList lst = new ArrayList();

            lst.Add(new SqlParameter("@id", id));

            try
            {
                return this.ExecuteSqlDataReader("cust_sp_salc_rc_getbyid_hmis", lst);
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                lst = null;
            }
        }

        public SqlDataReader GetAllResourceCenterHMIS(int orgId, int helpId)
        {
            ArrayList lst = new ArrayList();

            lst.Add(new SqlParameter("@HelpId", helpId));
            lst.Add(new SqlParameter("@OrganizationId", orgId));

            try
            {
                return this.ExecuteSqlDataReader("cust_sp_salc_rc_getall_hmis", lst);
            }
            catch (SqlException ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// deletes a FoodBag record.
        /// </summary>
        /// <param name="id">The poll_id key to delete.</param>
        public void DeleteResourceCenterHMIS(int id)
        {
            ArrayList lst = new ArrayList();

            lst.Add(new SqlParameter("@HMISId", id));

            try
            {
                this.ExecuteNonQuery("cust_sp_salc_rc_del_hmis", lst);
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                lst = null;
            }
        }

        public int SaveResourceCenterHMIS(int orgId, int hmisId, int helpId, DateTime tagDate, DateTime enteredDate, int reasonForLeaving, int destination, string userName)
        {
            ArrayList lst = new ArrayList();

            lst.Add(new SqlParameter("@HMISId", hmisId));
            lst.Add(new SqlParameter("@UserId", userName));
            lst.Add(new SqlParameter("@TagDate", tagDate));
            lst.Add(new SqlParameter("@HelpId", helpId));
            lst.Add(new SqlParameter("@ReasonForLeaving", reasonForLeaving));
            lst.Add(new SqlParameter("@Destination", destination));
            lst.Add(new SqlParameter("@EnteredDate", enteredDate));
            lst.Add(new SqlParameter("@OrganizationId", orgId));

            SqlParameter paramOut = new SqlParameter();
            paramOut.ParameterName = "@ID";
            paramOut.Direction = ParameterDirection.Output;
            paramOut.SqlDbType = SqlDbType.Int;
            lst.Add(paramOut);

            try
            {
                this.ExecuteNonQuery("cust_sp_salc_rc_save_hmis", lst);
                return Convert.ToInt32(((SqlParameter)(lst[lst.Count - 1])).Value.ToString());
            }
            catch (SqlException ex)
            {
                if (ex.Number == 2627) //Unique Key Violation
                    return -1;
                else
                    throw ex;
            }
            finally
            {
                lst = null;
            }
        }
    }
}