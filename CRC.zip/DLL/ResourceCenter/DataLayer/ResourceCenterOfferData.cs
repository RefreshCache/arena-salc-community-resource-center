using System;
using System.Collections;
using System.Data;
using System.Data.SqlClient;
using Arena.DataLib;

namespace Arena.Custom.SALC.ResourceCenter.DataLayer
{
    public class ResourceCenterOfferData : SqlData
    {
        /// <summary>
        /// Class constructor.
        /// </summary>
        public ResourceCenterOfferData()
        {
        }

        /// <summary>
        /// Returns a <see cref="System.Data.SqlClient.SqlDataReader">SqlDataReader</see> object
        /// containing the FoodBag with the ID specified
        /// </summary>
        /// <param name="foodBagID">FoodBag ID</param>
        /// <returns><see cref="System.Data.SqlClient.SqlDataReader">SqlDataReader</see></returns>
        public SqlDataReader GetResourceCenterOfferByID(int Id)
        {
            ArrayList lst = new ArrayList();

            lst.Add(new SqlParameter("@id", Id));

            try
            {
                return this.ExecuteSqlDataReader("cust_sp_salc_rc_getbyid_offer", lst);
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                lst = null;
            }
        }

        public SqlDataReader GetAllResourceCenterOffers(int orgId, DateTime startDate, DateTime endDate, string firstName, string lastName, int type, int clientId, int callId, int status)
        {
            ArrayList lst = new ArrayList();
            lst.Add(new SqlParameter("@StartDate", startDate));
            lst.Add(new SqlParameter("@EndDate", endDate));
            lst.Add(new SqlParameter("@FirstName", firstName));
            lst.Add(new SqlParameter("@LastName", lastName));
            lst.Add(new SqlParameter("@Type", type));
            lst.Add(new SqlParameter("@ClientId", clientId));
            lst.Add(new SqlParameter("@CallId", callId));
            lst.Add(new SqlParameter("@Status", status));
            lst.Add(new SqlParameter("@OrganizationId", orgId));

            try
            {
                return this.ExecuteSqlDataReader("cust_sp_salc_rc_getall_offer", lst);
            }
            catch (SqlException ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// deletes a FoodBag record.
        /// </summary>
        /// <param name="roleID">The poll_id key to delete.</param>
        public void DeleteResourceCenterOffer(int Id)
        {
            ArrayList lst = new ArrayList();

            lst.Add(new SqlParameter("@OfferId", Id));

            try
            {
                this.ExecuteNonQuery("cust_sp_salc_rc_del_offer", lst);
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                lst = null;
            }
        }

        /// <summary>
        /// saves FoodBag record
        /// </summary>
        /// <returns><see cref="System.Data.SqlClient.SqlDataReader">SqlDataReader</see></returns>
        public int SaveResourceCenterOffer(int orgId, int mealId, string userId, int personId, DateTime date, int type, string description, int size, decimal amount, string notes, int clientId, int callId, int status, string name, string phone)
        {
            ArrayList lst = new ArrayList();

            lst.Add(new SqlParameter("@OfferId", mealId));
            lst.Add(new SqlParameter("@UserId", userId));
            lst.Add(new SqlParameter("@PersonId", personId));
            lst.Add(new SqlParameter("@GivenToId", clientId));
            lst.Add(new SqlParameter("@CallId", callId));
            lst.Add(new SqlParameter("@Date", date));
            lst.Add(new SqlParameter("@Type", type));
            lst.Add(new SqlParameter("@Description", description));
            lst.Add(new SqlParameter("@Size", size));
            lst.Add(new SqlParameter("@Amount", amount));
            lst.Add(new SqlParameter("@Status", status));
            lst.Add(new SqlParameter("@Name", name));
            lst.Add(new SqlParameter("@Phone", phone));
            lst.Add(new SqlParameter("@Notes", notes));
            lst.Add(new SqlParameter("@OrganizationId", orgId));

            SqlParameter paramOut = new SqlParameter();
            paramOut.ParameterName = "@ID";
            paramOut.Direction = ParameterDirection.Output;
            paramOut.SqlDbType = SqlDbType.Int;
            lst.Add(paramOut);

            try
            {
                this.ExecuteNonQuery("cust_sp_salc_rc_save_offer", lst);
                return Convert.ToInt32(((SqlParameter)(lst[lst.Count - 1])).Value.ToString());
            }
            catch (SqlException ex)
            {
                if (ex.Number == 2627) //Unique Key Violation
                    return -1;
                else
                    throw ex;
            }
            finally
            {
                lst = null;
            }
        }
    }
}