using System;
using System.Collections;
using System.Data;
using System.Data.SqlClient;
using Arena.DataLib;

namespace Arena.Custom.SALC.ResourceCenter.DataLayer
{
    public class ResourceCenterCallData : SqlData
    {
        /// <summary>
        /// Class constructor.
        /// </summary>
        public ResourceCenterCallData()
        {
        }

        /// <summary>
        /// Returns a <see cref="System.Data.SqlClient.SqlDataReader">SqlDataReader</see> object
        /// containing the FoodBag with the ID specified
        /// </summary>
        /// <param name="foodBagID">FoodBag ID</param>
        /// <returns><see cref="System.Data.SqlClient.SqlDataReader">SqlDataReader</see></returns>
        public SqlDataReader GetResourceCenterCallByID(int id)
        {
            ArrayList lst = new ArrayList();

            lst.Add(new SqlParameter("@id", id));

            try
            {
                return this.ExecuteSqlDataReader("cust_sp_salc_rc_getbyid_call", lst);
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                lst = null;
            }
        }

        public SqlDataReader GetAllResourceCenterCalls(int personId)
        {
            ArrayList lst = new ArrayList();

            int zero = 0;
            lst.Add(new SqlParameter("@StartDate", new DateTime(1901, 1, 1)));
            lst.Add(new SqlParameter("@EndDate", new DateTime(2199, 1, 1)));
            lst.Add(new SqlParameter("@MessageFor", ""));
            lst.Add(new SqlParameter("@Search", ""));
            lst.Add(new SqlParameter("@Status", zero)); //reused for completed
            lst.Add(new SqlParameter("@PersonId", personId));
            lst.Add(new SqlParameter("@OrganizationId", zero));

            try
            {
                return this.ExecuteSqlDataReader("cust_sp_salc_rc_getall_call", lst);
            }
            catch (SqlException ex)
            {
                throw ex;
            }
        }

        public SqlDataReader GetAllResourceCenterCalls(DateTime startDate, DateTime endDate, string messageFor, int request, string search, int status, int orgId)
        {
            ArrayList lst = new ArrayList();

            int zero = 0;
            lst.Add(new SqlParameter("@StartDate", startDate));
            lst.Add(new SqlParameter("@EndDate", endDate));
            lst.Add(new SqlParameter("@MessageFor", messageFor));
            lst.Add(new SqlParameter("@Type", request));
            lst.Add(new SqlParameter("@Search", search));
            lst.Add(new SqlParameter("@Status", status)); //reused for completed
            lst.Add(new SqlParameter("@PersonId", zero));
            lst.Add(new SqlParameter("@OrganizationId", orgId));

            try
            {
                return this.ExecuteSqlDataReader("cust_sp_salc_rc_getall_call", lst);
            }
            catch (SqlException ex)
            {
                throw ex;
            }
        }

        public SqlDataReader GetAllResourceCenterCalls(DateTime startDate, DateTime endDate, string messageFor, string search, int status, int orgId)
        {
            ArrayList lst = new ArrayList();

            int zero = 0;
            lst.Add(new SqlParameter("@StartDate", startDate));
            lst.Add(new SqlParameter("@EndDate", endDate));
            lst.Add(new SqlParameter("@MessageFor", messageFor));
            lst.Add(new SqlParameter("@Type", zero));
            lst.Add(new SqlParameter("@Search", search));
            lst.Add(new SqlParameter("@Status", status)); //reused for completed
            lst.Add(new SqlParameter("@PersonId", zero));
            lst.Add(new SqlParameter("@OrganizationId", orgId));

            try
            {
                return this.ExecuteSqlDataReader("cust_sp_salc_rc_getall_call", lst);
            }
            catch (SqlException ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// deletes a FoodBag record.
        /// </summary>
        /// <param name="roleID">The poll_id key to delete.</param>
        public void DeleteResourceCenterCall(int id)
        {
            ArrayList lst = new ArrayList();

            lst.Add(new SqlParameter("@CallId", id));

            try
            {
                this.ExecuteNonQuery("cust_sp_salc_rc_del_call", lst);
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                lst = null;
            }
        }

        /// <summary>
        /// saves FoodBag record
        /// </summary>
        /// <returns><see cref="System.Data.SqlClient.SqlDataReader">SqlDataReader</see></returns>
        public int SaveResourceCenterCall(int orgId, int mealId, string userId, DateTime date, string name, string phone, string county, string msgFor, int hh,
            int recieve, int callType, int reqFood, int reqShelter, int reqRent, int reqUtility, int reqFurn, int reqOther, string notes, int completed, int personId)
        {
            ArrayList lst = new ArrayList();

            lst.Add(new SqlParameter("@CallId", mealId));
            lst.Add(new SqlParameter("@UserId", userId));
            lst.Add(new SqlParameter("@Date", date));
            lst.Add(new SqlParameter("@Name", name));
            lst.Add(new SqlParameter("@Phone", phone));
            lst.Add(new SqlParameter("@County", county));
            lst.Add(new SqlParameter("@MessageFor", msgFor));
            lst.Add(new SqlParameter("@HH", hh));
            lst.Add(new SqlParameter("@Recieve", recieve));
            lst.Add(new SqlParameter("@CallType", callType));
            lst.Add(new SqlParameter("@ReqFood", reqFood));
            lst.Add(new SqlParameter("@ReqShelter", reqShelter));
            lst.Add(new SqlParameter("@ReqRent", reqRent));
            lst.Add(new SqlParameter("@ReqUtility", reqUtility));
            lst.Add(new SqlParameter("@ReqFurn", reqFurn));
            lst.Add(new SqlParameter("@ReqOther", reqOther));
            lst.Add(new SqlParameter("@Notes", notes));
            lst.Add(new SqlParameter("@Status", completed));
            lst.Add(new SqlParameter("@PersonId", personId));
            lst.Add(new SqlParameter("@OrganizationId", orgId));

            SqlParameter paramOut = new SqlParameter();
            paramOut.ParameterName = "@ID";
            paramOut.Direction = ParameterDirection.Output;
            paramOut.SqlDbType = SqlDbType.Int;
            lst.Add(paramOut);

            try
            {
                this.ExecuteNonQuery("cust_sp_salc_rc_save_call", lst);
                return Convert.ToInt32(((SqlParameter)(lst[lst.Count - 1])).Value.ToString());
            }
            catch (SqlException ex)
            {
                if (ex.Number == 2627) //Unique Key Violation
                    return -1;
                else
                    throw ex;
            }
            finally
            {
                lst = null;
            }
        }
    }
}