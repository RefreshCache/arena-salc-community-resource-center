using System;
using System.Collections;
using System.Data;
using System.Data.SqlClient;
using Arena.DataLib;

namespace Arena.Custom.SALC.ResourceCenter.DataLayer
{
    public class ProgressReportData : SqlData
    {
        /// <summary>
        /// Class constructor.
        /// </summary>
        public ProgressReportData()
        {
        }

        /// <summary>
        /// Returns a <see cref="System.Data.SqlClient.SqlDataReader">SqlDataReader</see> object
        /// containing the FoodBag with the ID specified
        /// </summary>
        /// <param name="foodBagID">FoodBag ID</param>
        /// <returns><see cref="System.Data.SqlClient.SqlDataReader">SqlDataReader</see></returns>
        public SqlDataReader GetProgressReportByID(int id)
        {
            ArrayList lst = new ArrayList();

            lst.Add(new SqlParameter("@id", id));

            try
            {
                return this.ExecuteSqlDataReader("cust_sp_salc_rc_getbyid_progrprt", lst);
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                lst = null;
            }
        }

        public SqlDataReader GetAllProgressReports(int goalId, int orgId)
        {
            ArrayList lst = new ArrayList();
            lst.Add(new SqlParameter("@StartDate", new DateTime(1901, 1, 1)));
            lst.Add(new SqlParameter("@EndDate", new DateTime(2099, 12, 31)));
            lst.Add(new SqlParameter("@GoalId", goalId));
            lst.Add(new SqlParameter("@OrganizationId", orgId));

            try
            {
                return this.ExecuteSqlDataReader("cust_sp_salc_rc_getall_progrprt", lst);
            }
            catch (SqlException ex)
            {
                throw ex;
            }
        }

        public SqlDataReader GetAllProgressReports(DateTime startDate, DateTime endDate, int goalId, int orgId)
        {
            ArrayList lst = new ArrayList();
            lst.Add(new SqlParameter("@StartDate", startDate));
            lst.Add(new SqlParameter("@EndDate", endDate));
            lst.Add(new SqlParameter("@GoalId", goalId));
            lst.Add(new SqlParameter("@OrganizationId", orgId));

            try
            {
                return this.ExecuteSqlDataReader("cust_sp_salc_rc_getall_progrprt", lst);
            }
            catch (SqlException ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// deletes a FoodBag record.
        /// </summary>
        /// <param name="roleID">The poll_id key to delete.</param>
        public void DeleteProgressReport(int id)
        {
            ArrayList lst = new ArrayList();

            lst.Add(new SqlParameter("@ProgressReportId", id));

            try
            {
                this.ExecuteNonQuery("cust_sp_salc_rc_del_progrprt", lst);
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                lst = null;
            }
        }

        /// <summary>
        /// saves FoodBag record
        /// </summary>
        /// <returns><see cref="System.Data.SqlClient.SqlDataReader">SqlDataReader</see></returns>
        public int SaveProgressReport(int progrprtId, string userId, int goalId, string description, int type, int orgId)
        {
            ArrayList lst = new ArrayList();

            lst.Add(new SqlParameter("@ProgressReportId", progrprtId));
            lst.Add(new SqlParameter("@UserId", userId));
            lst.Add(new SqlParameter("@GoalId", goalId));
            lst.Add(new SqlParameter("@Description", description));
            lst.Add(new SqlParameter("@Type", type));
            lst.Add(new SqlParameter("@OrganizationId", orgId));

            SqlParameter paramOut = new SqlParameter();
            paramOut.ParameterName = "@ID";
            paramOut.Direction = ParameterDirection.Output;
            paramOut.SqlDbType = SqlDbType.Int;
            lst.Add(paramOut);

            try
            {
                this.ExecuteNonQuery("cust_sp_salc_rc_save_progrprt", lst);
                return Convert.ToInt32(((SqlParameter)(lst[lst.Count - 1])).Value.ToString());
            }
            catch (SqlException ex)
            {
                if (ex.Number == 2627) //Unique Key Violation
                    return -1;
                else
                    throw ex;
            }
            finally
            {
                lst = null;
            }
        }
    }
}