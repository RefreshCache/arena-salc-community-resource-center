using System;
using System.Collections;
using System.Data;
using System.Data.SqlClient;
using Arena.Custom.SALC.ResourceCenter.Entity;
using Arena.DataLib;

namespace Arena.Custom.SALC.ResourceCenter.DataLayer
{
    public class ResourceCenterDocumentData : SqlData
    {
        /// <summary>
        /// Class constructor.
        /// </summary>
        public ResourceCenterDocumentData()
        {
        }

        public SqlDataReader GetResourceCenterDocumentByID(int id)
        {
            ArrayList lst = new ArrayList();

            lst.Add(new SqlParameter("@id", id));

            try
            {
                return this.ExecuteSqlDataReader("cust_sp_salc_rc_getbyid_document", lst);
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                lst = null;
            }
        }

        public SqlDataReader GetAllResourceCenterDocuments(int parent, int parentId)
        {
            ArrayList lst = new ArrayList();
            lst.Add(new SqlParameter("@Parent", parent));
            lst.Add(new SqlParameter("@ParentId", parentId));

            try
            {
                return this.ExecuteSqlDataReader("cust_sp_salc_rc_getall_document", lst);
            }
            catch (SqlException ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// deletes a FoodBag record.
        /// </summary>
        /// <param name="roleID">The poll_id key to delete.</param>
        public void DeleteResourceCenterDocument(int id)
        {
            ArrayList lst = new ArrayList();

            lst.Add(new SqlParameter("@DocumentId", id));

            try
            {
                this.ExecuteNonQuery("cust_sp_salc_rc_del_document", lst);
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                lst = null;
            }
        }

        /// <summary>
        /// saves FoodBag record
        /// </summary>
        /// <returns><see cref="System.Data.SqlClient.SqlDataReader">SqlDataReader</see></returns>
        public int SaveResourceCenterDocument(int orgId, int documentId, string userId, int parent, int parentId, string name, string mime, int size, byte[] data, bool family)
        {
            if (!family)
            {
                ArrayList lst = new ArrayList();
                lst.Add(new SqlParameter("@DocumentId", documentId));
                lst.Add(new SqlParameter("@Parent", parent));
                lst.Add(new SqlParameter("@ParentId", parentId));
                lst.Add(new SqlParameter("@Name", name));
                lst.Add(new SqlParameter("@Mime", mime));
                lst.Add(new SqlParameter("@Size", data.Length));
                SqlParameter spData = new SqlParameter("@Data", SqlDbType.VarBinary, -1);
                spData.Value = data;
                lst.Add(spData);
                lst.Add(new SqlParameter("@UserId", userId));

                SqlParameter paramOut = new SqlParameter();
                paramOut.ParameterName = "@ID";
                paramOut.Direction = ParameterDirection.Output;
                paramOut.SqlDbType = SqlDbType.Int;
                lst.Add(paramOut);

                try
                {
                    this.ExecuteNonQuery("cust_sp_salc_rc_save_document", lst);
                    return Convert.ToInt32(((SqlParameter)(lst[lst.Count - 1])).Value.ToString());
                }
                catch (SqlException ex)
                {
                    if (ex.Number == 2627) //Unique Key Violation
                        return -1;
                    else
                        throw ex;
                }
                finally
                {
                    lst = null;
                }
            }
            else
            {
                foreach (ResourceCenterPerson p in ResourceCenterPersonCollection.LoadAll(orgId, parentId))
                {
                    ArrayList lst = new ArrayList();
                    int iId = 0;
                    lst.Add(new SqlParameter("@DocumentId", iId));
                    lst.Add(new SqlParameter("@Parent", parent));
                    lst.Add(new SqlParameter("@ParentId", p.PersonId));
                    lst.Add(new SqlParameter("@Name", name));
                    lst.Add(new SqlParameter("@Mime", mime));
                    lst.Add(new SqlParameter("@Size", data.Length));
                    SqlParameter spData = new SqlParameter("@Data", SqlDbType.VarBinary, -1);
                    spData.Value = data;
                    lst.Add(spData);
                    lst.Add(new SqlParameter("@UserId", userId));

                    SqlParameter paramOut = new SqlParameter();
                    paramOut.ParameterName = "@ID";
                    paramOut.Direction = ParameterDirection.Output;
                    paramOut.SqlDbType = SqlDbType.Int;
                    lst.Add(paramOut);

                    try
                    {
                        this.ExecuteNonQuery("cust_sp_salc_rc_save_document", lst);
                        //return Convert.ToInt32(((SqlParameter)(lst[lst.Count - 1])).Value.ToString());
                    }
                    catch (SqlException ex)
                    {
                        if (ex.Number == 2627) //Unique Key Violation
                            return -1;
                        else
                            throw ex;
                    }
                    finally
                    {
                        lst = null;
                    }
                }
                return this.SaveResourceCenterDocument(orgId, 0, userId, parent, parentId, name, mime, size, data, false);
            }
        }
    }
}