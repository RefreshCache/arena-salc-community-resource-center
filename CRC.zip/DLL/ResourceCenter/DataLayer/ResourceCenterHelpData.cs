using System;
using System.Collections;
using System.Data;
using System.Data.SqlClient;
using Arena.DataLib;

namespace Arena.Custom.SALC.ResourceCenter.DataLayer
{
    public class ResourceCenterHelpData : SqlData
    {
        /// <summary>
        /// Class constructor.
        /// </summary>
        public ResourceCenterHelpData()
        {
        }

        /// <summary>
        /// Returns a <see cref="System.Data.SqlClient.SqlDataReader">SqlDataReader</see> object
        /// containing the FoodBag with the ID specified
        /// </summary>
        /// <param name="foodBagID">FoodBag ID</param>
        /// <returns><see cref="System.Data.SqlClient.SqlDataReader">SqlDataReader</see></returns>
        public SqlDataReader GetResourceCenterHelpByID(int Id)
        {
            ArrayList lst = new ArrayList();

            lst.Add(new SqlParameter("@id", Id));

            try
            {
                return this.ExecuteSqlDataReader("cust_sp_salc_rc_getbyid_help", lst);
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                lst = null;
            }
        }

        public SqlDataReader GetAllResourceCenterHelps(int orgId)
        {
            ArrayList lst = new ArrayList();

            lst.Add(new SqlParameter("@PersonId", 0));
            lst.Add(new SqlParameter("@OrganizationId", orgId));

            try
            {
                return this.ExecuteSqlDataReader("cust_sp_salc_rc_getall_help", lst);
            }
            catch (SqlException ex)
            {
                throw ex;
            }
        }

        public SqlDataReader GetAllResourceCenterHelps(int orgId, int personId)
        {
            ArrayList lst = new ArrayList();

            lst.Add(new SqlParameter("@PersonId", personId));
            lst.Add(new SqlParameter("@OrganizationId", orgId));

            try
            {
                return this.ExecuteSqlDataReader("cust_sp_salc_rc_getall_help", lst);
            }
            catch (SqlException ex)
            {
                throw ex;
            }
        }

        public int DeleteResourceCenterHelp(int helpId, int personId)
        {
            ArrayList lst = new ArrayList();

            lst.Add(new SqlParameter("@helpId", helpId));
            lst.Add(new SqlParameter("@personId", personId));

            SqlParameter paramOut = new SqlParameter();
            paramOut.ParameterName = "@CODE";
            paramOut.Direction = ParameterDirection.Output;
            paramOut.SqlDbType = SqlDbType.Int;
            lst.Add(paramOut);

            try
            {
                this.ExecuteNonQuery("cust_sp_salc_rc_del_help", lst);
                return Convert.ToInt32(((SqlParameter)(lst[lst.Count - 1])).Value.ToString());
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                lst = null;
            }
        }

        public void AddNewLink(int helpId, int personId)
        {
            ArrayList lst = new ArrayList();

            lst.Add(new SqlParameter("@helpId", helpId));
            lst.Add(new SqlParameter("@personId", personId));

            try
            {
                this.ExecuteNonQuery("cust_sp_salc_rc_create_helplink", lst);
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                lst = null;
            }
        }

        /// <summary>
        /// saves FoodBag record
        /// </summary>
        /// <returns><see cref="System.Data.SqlClient.SqlDataReader">SqlDataReader</see></returns>
        public int SaveResourceCenterHelp(int helpId, DateTime date, int type, Decimal amount, int size, string description, int subsedized, decimal subAmount, string subSource,
            string vendor, string complete, string assistedBy, DateTime dateCompleted, string resolution, int subType, string notes, string userId, string address, string city, string zip,
            string state, string county, int prototypeId, string followupNote, DateTime followupDate, int followupExperience, int followupHousingStatus)
        {
            ArrayList lst = new ArrayList();
            int iNewId = 0;

            lst.Add(new SqlParameter("@HelpId", helpId));
            lst.Add(new SqlParameter("@UserId", userId));
            lst.Add(new SqlParameter("@Date", date));
            lst.Add(new SqlParameter("@Type", type));
            lst.Add(new SqlParameter("@Amount", amount));
            lst.Add(new SqlParameter("@Size", size));
            lst.Add(new SqlParameter("@Description", description));
            lst.Add(new SqlParameter("@Subsidized", subsedized));
            lst.Add(new SqlParameter("@SubAmount", subAmount));
            lst.Add(new SqlParameter("@SubSource", subSource));
            lst.Add(new SqlParameter("@Vendor", vendor));
            lst.Add(new SqlParameter("@Complete", complete));
            lst.Add(new SqlParameter("@Assistant", assistedBy));
            lst.Add(new SqlParameter("@DateCompleted", dateCompleted));
            lst.Add(new SqlParameter("@Resolution", resolution));
            lst.Add(new SqlParameter("@SubType", subType));
            lst.Add(new SqlParameter("@Notes", notes));
            lst.Add(new SqlParameter("@Address", address));
            lst.Add(new SqlParameter("@City", city));
            lst.Add(new SqlParameter("@Zip", zip));
            lst.Add(new SqlParameter("@State", state));
            lst.Add(new SqlParameter("@County", county));
            lst.Add(new SqlParameter("@FollowUpNotes", followupNote));
            lst.Add(new SqlParameter("@FollowUpHousingStatus", followupHousingStatus));
            lst.Add(new SqlParameter("@FollowUpExperience", followupExperience));
            lst.Add(new SqlParameter("@FollowUpDate", followupDate));

            SqlParameter paramOut = new SqlParameter();
            paramOut.ParameterName = "@ID";
            paramOut.Direction = ParameterDirection.Output;
            paramOut.SqlDbType = SqlDbType.Int;
            lst.Add(paramOut);

            try
            {
                this.ExecuteNonQuery("cust_sp_salc_rc_save_help", lst);
                iNewId = Convert.ToInt32(((SqlParameter)(lst[lst.Count - 1])).Value.ToString());
            }
            catch (SqlException ex)
            {
                if (ex.Number == 2627) //Unique Key Violation
                    return -1;
                else
                    throw ex;
            }
            finally
            {
                lst = null;
            }

            //If the helpId returned from SQL is not the same the one supplied to this function...
            //then a new record was created. In that case, generate the default help links, adding all
            //clients that have the same address on file. (Hackish method)
            if (iNewId != helpId) //We should also check to see if the prototypeId is valid, but we'll play this one fast and loose...
            {
                lst = new ArrayList();
                lst.Add(new SqlParameter("@helpid", iNewId));
                lst.Add(new SqlParameter("@personid", prototypeId));

                try
                {
                    //All we can do is hope for the best here
                    this.ExecuteNonQuery("cust_sp_salc_rc_misc_generatehelplinks", lst);
                }
                catch (SqlException ex)
                {
                    //A unique key violation should never happen since the SQL stored procedure should be able to detect this...
                    //If this error (#2627) ever comes up, something has gone very VERY wrong...
                    if (ex.Number == 2627) //Unique Key Violation
                    //Return the new ID anyway... it will show no one attached... allow the user to figure it out from here...
                        return iNewId;
                    else
                        throw ex;
                }
                finally
                {
                    lst = null;
                }
            }
            return iNewId;
            //We have no way of returning an error condition here since the only value passed back is the current helpId...
            //... hope and pray... fast and loose
            //If the second stored procedure fails to generate links, then we'll have an orphaned help entry...
            //Not a big deal so long as we INNER JOIN all SELECT statements for reports to cust_salc_rclients_help_links
        }
    }
}