using System;
using System.Data.SqlClient;
using Arena.Core;
using Arena.Custom.SALC.ResourceCenter.DataLayer;

namespace Arena.Custom.SALC.ResourceCenter.Entity
{
    [Serializable]
    public class GoalTypeCollection : ArenaCollectionBase
    {
        #region Class Indexers
        public new GoalType this[int index]
        {
            get
            {
                if (this.List.Count > 0)
                {
                    return (GoalType)this.List[index];
                }
                else
                {
                    return null;
                }
            }
            set
            {
                this.List[index] = value;
            }
        }

        #endregion

        #region Constructors

        public GoalTypeCollection()
        {
        }

        public GoalTypeCollection(int orgId)
        {
            SqlDataReader reader = new GoalTypeData().GetAllResourceCenterGoalTypes(orgId);
            while (reader.Read())
                this.Add(new GoalType(reader));
            reader.Close();
        }

        #endregion

        #region Public Methods

        public void Add(GoalType item)
        {
            this.List.Add(item);
        }

        public void Insert(int index, GoalType item)
        {
            this.List.Insert(index, item);
        }

        #endregion

        #region Static Methods

        public static GoalTypeCollection LoadAll(int orgId)
        {
            SqlDataReader reader = new GoalTypeData().GetAllResourceCenterGoalTypes(orgId);
            GoalTypeCollection collection = new GoalTypeCollection();
            while (reader.Read())
            {
                collection.Add(new GoalType(reader));
            }
            reader.Close();
            return collection;
        }
        #endregion
    }
}