using System;
using System.Data.SqlClient;
using Arena.Core;
using Arena.Custom.SALC.ResourceCenter.DataLayer;

namespace Arena.Custom.SALC.ResourceCenter.Entity
{
    [Serializable]
    public class ResourceCenterDocumentCollection : ArenaCollectionBase
    {
        #region Class Indexers
        public new ResourceCenterDocument this[int index]
        {
            get
            {
                if (this.List.Count > 0)
                {
                    return (ResourceCenterDocument)this.List[index];
                }
                else
                {
                    return null;
                }
            }
            set
            {
                this.List[index] = value;
            }
        }

        #endregion

        #region Constructors

        public ResourceCenterDocumentCollection()
        {
        }

        public ResourceCenterDocumentCollection(int DocumentId)
        {
            SqlDataReader reader = new ResourceCenterDocumentData().GetResourceCenterDocumentByID(DocumentId);
            while (reader.Read())
                this.Add(new ResourceCenterDocument(reader));
            reader.Close();
        }

        #endregion

        #region Public Methods

        public void Add(ResourceCenterDocument item)
        {
            this.List.Add(item);
        }

        public void Insert(int index, ResourceCenterDocument item)
        {
            this.List.Insert(index, item);
        }

        #endregion

        #region Static Methods

        public static ResourceCenterDocumentCollection LoadAll(int parent, int parentId)
        {
            SqlDataReader reader = new ResourceCenterDocumentData().GetAllResourceCenterDocuments(parent, parentId);
            ResourceCenterDocumentCollection collection = new ResourceCenterDocumentCollection();
            while (reader.Read())
            {
                collection.Add(new ResourceCenterDocument(reader));
            }
            reader.Close();
            return collection;
        }
        #endregion
    }
}