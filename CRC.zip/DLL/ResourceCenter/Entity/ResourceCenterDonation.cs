using System;
using System.Data.SqlClient;
using Arena.Core;
using Arena.Custom.SALC.ResourceCenter.DataLayer;

namespace Arena.Custom.SALC.ResourceCenter.Entity
{
    [Serializable]
    public class ResourceCenterDonation : ArenaObjectBase
    {
        #region Private Members
        private int _Id = -1;
        private int _personId = -1;
        private DateTime _date = DateTime.MinValue;
        private int _type = 0;
        private string _description = string.Empty;
        private int _size = 0;
        private decimal _amount = 0;
        private string _notes = string.Empty;

        private string _firstName = string.Empty;
        private string _lastName = string.Empty;
        private string _middleName = string.Empty;
        private string _nickName = string.Empty;
        private string _guid = string.Empty;
        private string _fullName = string.Empty;

        private DateTime _dateCreated = DateTime.MinValue;      //General
        private DateTime _dateUpdated = DateTime.MinValue;      //General
        private string _createdBy = string.Empty;               //General
        private string _updatedBy = string.Empty;               //General

        private int organizationId = 1;

        #endregion

        #region Public Properties

        public int Id
        {
            get
            {
                return _Id;
            }
            //set { _Id = value; }
        }

        public DateTime DateCreated
        {
            get
            {
                return _dateCreated;
            }
            //set { _dateCreated = value; }
        }

        public DateTime DateUpdated
        {
            get
            {
                return _dateUpdated;
            }
            //set { _dateUpdated = value; }
        }

        public string CreatedBy
        {
            get
            {
                return _createdBy;
            }
            //set { _createdBy = value; }
        }

        public string UpdatedBy
        {
            get
            {
                return _updatedBy;
            }
            //set { _updatedBy = value; }
        }

        public int PersonId
        {
            get
            {
                return _personId;
            }
            set
            {
                _personId = value;
            }
        }

        public DateTime Date
        {
            get
            {
                return _date;
            }
            set
            {
                _date = value;
            }
        }

        public int Type
        {
            get
            {
                return _type;
            }
            set
            {
                _type = value;
            }
        }

        public string Description
        {
            get
            {
                return _description;
            }
            set
            {
                _description = value;
            }
        }

        public int Size
        {
            get
            {
                return _size;
            }
            set
            {
                _size = value;
            }
        }

        public decimal Amount
        {
            get
            {
                return _amount;
            }
            set
            {
                _amount = value;
            }
        }

        public string Notes
        {
            get
            {
                return _notes;
            }
            set
            {
                _notes = value;
            }
        }

        public string FirstName
        {
            get
            {
                return _firstName;
            }
        }

        public string MiddleName
        {
            get
            {
                return _middleName;
            }
        }

        public string LastName
        {
            get
            {
                return _lastName;
            }
        }

        public string NickName
        {
            get
            {
                return _nickName;
            }
        }

        public string FullName
        {
            get
            {
                return _fullName;
            }
        }

        public string GUID
        {
            get
            {
                return _guid;
            }
        }

        public int OrganizationId
        {
            get
            {
                return organizationId;
            }
            set
            {
                organizationId = value;
            }
        }

        #endregion

        #region Public Methods

        public void Save(int orgId, string userId)
        {
            SaveDonation(orgId, userId);
        }

        public static void Delete(int Id)
        {
            new ResourceCenterDonationData().DeleteResourceCenterDonation(Id);
        }

        public void Delete()
        {
            // delete record
            ResourceCenterDonationData DonationData = new ResourceCenterDonationData();
            DonationData.DeleteResourceCenterDonation(_Id);

            _Id = -1;
        }

        #endregion

        #region Private Methods

        private void SaveDonation(int orgId, string userId)
        {
            _Id = new ResourceCenterDonationData().SaveResourceCenterDonation(orgId, _Id, userId, _personId, _date, _type, _description, _size, _amount, _notes);
        }

        private void LoadDonation(SqlDataReader reader)
        {
            if (!reader.IsDBNull(reader.GetOrdinal("id")))
                _Id = (int)reader["id"];

            if (!reader.IsDBNull(reader.GetOrdinal("date_created")))
                _dateCreated = (DateTime)reader["date_created"];

            if (!reader.IsDBNull(reader.GetOrdinal("date_updated")))
                _dateUpdated = (DateTime)reader["date_updated"];

            _createdBy = reader["created_by"].ToString();
            _updatedBy = reader["updated_by"].ToString();
            _personId = (int)reader["person_id"];
            if (_personId > 0)
            {
                Person p = new Person(_personId);
                _firstName = p.FirstName;
                _middleName = p.MiddleName;
                _lastName = p.LastName;
                _nickName = p.NickName;
                _fullName = p.FullName;
                _guid = p.PersonGUID.ToString();
            }

            _date = (DateTime)reader["date"];
            _type = (int)reader["type"];

            if (!reader.IsDBNull(reader.GetOrdinal("description")))
                _description = reader["description"].ToString();
            if (!reader.IsDBNull(reader.GetOrdinal("size")))
                _size = (int)reader["size"];
            if (!reader.IsDBNull(reader.GetOrdinal("amount")))
                _amount = (decimal)reader["amount"];
            if (!reader.IsDBNull(reader.GetOrdinal("notes")))
                _notes = reader["notes"].ToString();
        }

        #endregion

        #region Static Methods
        #endregion

        #region Constructors

        public ResourceCenterDonation()
        {
        }

        public ResourceCenterDonation(int Id)
        {
            SqlDataReader reader = new ResourceCenterDonationData().GetResourceCenterDonationByID(Id);
            if (reader.Read())
                LoadDonation(reader);
            reader.Close();
        }

        public ResourceCenterDonation(SqlDataReader reader)
        {
            LoadDonation(reader);
        }
        #endregion
    }
}