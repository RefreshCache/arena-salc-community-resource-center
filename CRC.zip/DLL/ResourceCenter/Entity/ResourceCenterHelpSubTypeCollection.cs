using System;
using System.Data.SqlClient;
using Arena.Core;
using Arena.Custom.SALC.ResourceCenter.DataLayer;

namespace Arena.Custom.SALC.ResourceCenter.Entity
{
    [Serializable]
    public class ResourceCenterHelpSubTypeCollection : ArenaCollectionBase
    {
        #region Class Indexers
        public new ResourceCenterHelpSubType this[int index]
        {
            get
            {
                if (this.List.Count > 0)
                {
                    return (ResourceCenterHelpSubType)this.List[index];
                }
                else
                {
                    return null;
                }
            }
            set
            {
                this.List[index] = value;
            }
        }

        #endregion

        #region Constructors

        public ResourceCenterHelpSubTypeCollection()
        {
        }

        public ResourceCenterHelpSubTypeCollection(int orgId)
        {
            SqlDataReader reader = new ResourceCenterHelpSubTypeData().GetAllResourceCenterHelpSubTypes(orgId);
            while (reader.Read())
                this.Add(new ResourceCenterHelpSubType(reader));
            reader.Close();
        }

        #endregion

        #region Public Methods

        public void Add(ResourceCenterHelpSubType item)
        {
            this.List.Add(item);
        }

        public void Insert(int index, ResourceCenterHelpSubType item)
        {
            this.List.Insert(index, item);
        }

        #endregion

        #region Static Methods

        public static ResourceCenterHelpSubTypeCollection LoadAll(int orgId)
        {
            SqlDataReader reader = new ResourceCenterHelpSubTypeData().GetAllResourceCenterHelpSubTypes(orgId);
            ResourceCenterHelpSubTypeCollection collection = new ResourceCenterHelpSubTypeCollection();
            while (reader.Read())
            {
                collection.Add(new ResourceCenterHelpSubType(reader));
            }
            reader.Close();
            return collection;
        }
        #endregion
    }
}