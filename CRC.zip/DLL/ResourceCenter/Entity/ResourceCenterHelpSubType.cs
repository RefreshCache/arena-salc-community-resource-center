using System;
using System.Data.SqlClient;
using Arena.Core;
using Arena.Custom.SALC.ResourceCenter.DataLayer;

namespace Arena.Custom.SALC.ResourceCenter.Entity
{
    [Serializable]
    public class ResourceCenterHelpSubType : ArenaObjectBase
    {
        #region Private Members
        private int _Id = -1;
        private string _name = string.Empty;
        private string _text = string.Empty;
        private int _quantity = 0;
        private int _amount = 0;
        private int _organizationId = 1;
        private int _enabled = 0;

        #endregion

        #region Public Properties

        public int Id
        {
            get
            {
                return _Id;
            }
            //set { _Id = value; }
        }

        public string Name
        {
            get
            {
                return _name;
            }
            set
            {
                _name = value;
            }
        }

        public string Text
        {
            get
            {
                return _text;
            }
            set
            {
                _text = value;
            }
        }

        public bool IsQuantity
        {
            get
            {
                return (_quantity > 0);
            }
            set
            {
                if (value)
                    _quantity = 1;
                else
                    _quantity = 0;
            }
        }

        public bool IsAmount
        {
            get
            {
                return (_amount > 0);
            }
            set
            {
                if (value)
                    _amount = 1;
                else
                    _amount = 0;
            }
        }

        public int OrganizationId
        {
            get
            {
                return _organizationId;
            }
            set
            {
                _organizationId = value;
            }
        }

        public bool Enabled
        {
            get
            {
                return (_enabled > 0);
            }
            set
            {
                if (value)
                    _enabled = 1;
                else
                    _enabled = 0;
            }
        }

        #endregion

        #region Public Methods

        public void Save()
        {
            SaveHelpSubType();
        }

        public static void Delete(int Id)
        {
            new ResourceCenterHelpSubTypeData().DeleteResourceCenterHelpSubType(Id);
        }

        public void Delete()
        {
            // delete record
            ResourceCenterHelpSubTypeData HelpSubTypeData = new ResourceCenterHelpSubTypeData();
            HelpSubTypeData.DeleteResourceCenterHelpSubType(_Id);

            _Id = -1;
        }

        #endregion

        #region Private Methods

        private void SaveHelpSubType()
        {
            _Id = new ResourceCenterHelpSubTypeData().SaveResourceCenterHelpSubType(_organizationId, _Id, _name, _text, _quantity, _amount, _enabled > 0);
        }

        private void LoadHelpSubType(SqlDataReader reader)
        {
            if (!reader.IsDBNull(reader.GetOrdinal("id")))
                _Id = (int)reader["id"];

            _name = reader["name"].ToString();
            _text = reader["text"].ToString();
            _quantity = (int)reader["quantity"];
            _amount = (int)reader["amount"];
            _organizationId = (int)reader["organization_id"];
        }

        #endregion

        #region Static Methods
        #endregion

        #region Constructors

        public ResourceCenterHelpSubType()
        {
        }

        public ResourceCenterHelpSubType(int orgId, int id, string name, string text, bool quantity, bool amount)
        {
            _Id = id;
            _organizationId = orgId;
            _name = name;
            _text = text;
            _quantity = quantity ? 1 : 0;
            _amount = amount ? 1 : 0;
        }

        public ResourceCenterHelpSubType(int Id)
        {
            SqlDataReader reader = new ResourceCenterHelpSubTypeData().GetResourceCenterHelpSubTypeByID(Id);
            if (reader.Read())
                LoadHelpSubType(reader);
            reader.Close();
        }

        public ResourceCenterHelpSubType(SqlDataReader reader)
        {
            LoadHelpSubType(reader);
        }
        #endregion
    }
}