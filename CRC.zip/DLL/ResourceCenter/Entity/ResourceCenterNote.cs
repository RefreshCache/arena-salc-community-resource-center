using System;
using System.Data.SqlClient;
using Arena.Core;
using Arena.Custom.SALC.ResourceCenter.DataLayer;

namespace Arena.Custom.SALC.ResourceCenter.Entity
{
    [Serializable]
    public class ResourceCenterNote : ArenaObjectBase
    {
        #region Private Members
        private int _id = -1;
        private DateTime _date = DateTime.MinValue;
        private int _clientId = -1;
        private int _helpId = -1;
        private int _orgId = 1;
        private string _note = string.Empty;

        private DateTime _dateCreated = DateTime.MinValue;      //General
        private DateTime _dateUpdated = DateTime.MinValue;      //General
        private string _createdBy = string.Empty;               //General
        private string _updatedBy = string.Empty;               //General

        #endregion

        #region Public Properties

        public int Id
        {
            get
            {
                return _id;
            }
            //set { _Id = value; }
        }

        public DateTime DateCreated
        {
            get
            {
                return _dateCreated;
            }
            //set { _dateCreated = value; }
        }

        public DateTime DateUpdated
        {
            get
            {
                return _dateUpdated;
            }
            //set { _dateUpdated = value; }
        }

        public string CreatedBy
        {
            get
            {
                return _createdBy;
            }
            //set { _createdBy = value; }
        }

        public string UpdatedBy
        {
            get
            {
                return _updatedBy;
            }
            //set { _updatedBy = value; }
        }

        public DateTime TagDate
        {
            get
            {
                return _date;
            }
            set
            {
                _date = value;
            }
        }

        public string Note
        {
            get
            {
                return _note;
            }
            set
            {
                _note = value;
            }
        }

        public int ClientId
        {
            get
            {
                return _clientId;
            }
            set
            {
                _clientId = value;
            }
        }

        public int HelpId
        {
            get
            {
                return _helpId;
            }
            set
            {
                _helpId = value;
            }
        }

        #endregion

        #region Public Methods

        public void Save(string userId)
        {
            SaveNote(userId);
        }

        public static void Delete(int Id)
        {
            new ResourceCenterNoteData().DeleteResourceCenterNote(Id);
        }

        public void Delete()
        {
            // delete record
            ResourceCenterNoteData noteData = new ResourceCenterNoteData();
            noteData.DeleteResourceCenterNote(_id);

            _id = -1;
        }

        #endregion

        #region Private Methods

        private void SaveNote(string userId)
        {
            _id = new ResourceCenterNoteData().SaveResourceCenterNote(_id, userId, _date, _clientId, _helpId, _note, _orgId);
        }

        private void LoadNote(SqlDataReader reader)
        {
            if (!reader.IsDBNull(reader.GetOrdinal("note_id")))
                _id = (int)reader["note_id"];

            if (!reader.IsDBNull(reader.GetOrdinal("create_date")))
                _dateCreated = (DateTime)reader["create_date"];

            if (!reader.IsDBNull(reader.GetOrdinal("update_date")))
                _dateUpdated = (DateTime)reader["update_date"];

            _createdBy = reader["created_by"].ToString();

            _updatedBy = reader["updated_by"].ToString();

            if (!reader.IsDBNull(reader.GetOrdinal("date_tag")))
                _date = (DateTime)reader["date_tag"];

            if (!reader.IsDBNull(reader.GetOrdinal("client_id")))
                _clientId = (int)reader["client_id"];

            if (!reader.IsDBNull(reader.GetOrdinal("help_id")))
                _helpId = (int)reader["help_id"];

            if (!reader.IsDBNull(reader.GetOrdinal("organization_id")))
                _orgId = (int)reader["organization_id"];

            _note = reader["note"].ToString();
        }

        #endregion

        #region Static Methods
        #endregion

        #region Constructors

        public ResourceCenterNote()
        {
        }

        public ResourceCenterNote(int Id)
        {
            SqlDataReader reader = new ResourceCenterNoteData().GetResourceCenterNoteByID(Id);
            if (reader.Read())
                LoadNote(reader);
            reader.Close();
        }

        public ResourceCenterNote(SqlDataReader reader)
        {
            LoadNote(reader);
        }
        #endregion
    }
}