using System;
using System.Data.SqlClient;
using Arena.Core;
using Arena.Custom.SALC.ResourceCenter.DataLayer;

namespace Arena.Custom.SALC.ResourceCenter.Entity
{
    [Serializable]
    public class ResourceCenterHelp : ArenaObjectBase
    {
        #region Private Members
        private int _Id = -1;                                   //General
        private DateTime _date = DateTime.MinValue;             //General
        private int _type = 0;                                  //General
        private decimal _amount = 0;                            //Value
        private int _size = 0;                                  //Value
        private string _description = string.Empty;             //General
        private int _subsidized = 0;                            //Sub
        private decimal _subAmountReceived = 0;                 //Sub
        private string _subSource = String.Empty;               //Sub
        private string _vendor = string.Empty;                  //Value
        private string _complete = string.Empty;                //General
        private string _assistant = string.Empty;               //General
        private DateTime _completedDate = DateTime.MinValue;    //General
        private string _resolution = string.Empty;              //General
        private int _subType = 0;                               //General
        private string _notes = string.Empty;                   //Specifics
        private DateTime _dateCreated = DateTime.MinValue;      //General
        private DateTime _dateUpdated = DateTime.MinValue;      //General
        private string _createdBy = string.Empty;               //General
        private string _updatedBy = string.Empty;               //General

        private string _address = string.Empty;
        private string _city = string.Empty;
        private string _zip = string.Empty;
        private string _state = string.Empty;
        private string _county = string.Empty;

        private DateTime _followupDate = Arena.DataLib.SqlData.DateTimeMinValue;
        private string _followupNote = string.Empty;
        private int _followupExperience = 0;
        private int _followupHousingStatus = 0;
          
        private bool _erased = false;

        #endregion

        #region Public Properties

        public int Id
        {
            get
            {
                return _Id;
            }
            //set { _Id = value; }
        }

        public DateTime DateCreated
        {
            get
            {
                return _dateCreated;
            }
            //set { _dateCreated = value; }
        }

        public DateTime DateUpdated
        {
            get
            {
                return _dateUpdated;
            }
            //set { _dateUpdated = value; }
        }

        public string CreatedBy
        {
            get
            {
                return _createdBy;
            }
            //set { _createdBy = value; }
        }

        public string UpdatedBy
        {
            get
            {
                return _updatedBy;
            }
            //set { _updatedBy = value; }
        }

        public DateTime Date
        {
            get
            {
                return _date;
            }
            set
            {
                _date = value;
            }
        }

        public int Type
        {
            get
            {
                return _type;
            }
            set
            {
                _type = value;
            }
        }

        public decimal Amount
        {
            get
            {
                return _amount;
            }
            set
            {
                _amount = value;
            }
        }

        public int Size
        {
            get
            {
                return _size;
            }
            set
            {
                _size = value;
            }
        }

        public string Description
        {
            get
            {
                return _description;
            }
            set
            {
                _description = value;
            }
        }

        public int Subsidized
        {
            get
            {
                return _subsidized;
            }
            set
            {
                _subsidized = value;
            }
        }

        public decimal SubAmountReceived
        {
            get
            {
                return _subAmountReceived;
            }
            set
            {
                _subAmountReceived = value;
            }
        }

        public string SubSource
        {
            get
            {
                return _subSource;
            }
            set
            {
                _subSource = value;
            }
        }

        public string Vendor
        {
            get
            {
                return _vendor;
            }
            set
            {
                _vendor = value;
            }
        }

        public string Complete
        {
            get
            {
                return _complete;
            }
            set
            {
                _complete = value;
            }
        }

        public string Assistant
        {
            get
            {
                return _assistant;
            }
            set
            {
                _assistant = value;
            }
        }

        public DateTime DateCompleted
        {
            get
            {
                return _completedDate;
            }
            set
            {
                _completedDate = value;
            }
        }

        public string Resolution
        {
            get
            {
                return _resolution;
            }
            set
            {
                _resolution = value;
            }
        }

        public int SubType
        {
            get
            {
                return _subType;
            }
            set
            {
                _subType = value;
            }
        }

        public string Notes
        {
            get
            {
                return _notes;
            }
            set
            {
                _notes = value;
            }
        }

        public string Street
        {
            get
            {
                return _address;
            }
            set
            {
                _address = value;
            }
        }

        public string City
        {
            get
            {
                return _city;
            }
            set
            {
                _city = value;
            }
        }

        public string Zip
        {
            get
            {
                return _zip;
            }
            set
            {
                _zip = value;
            }
        }

        public string State
        {
            get
            {
                return _state;
            }
            set
            {
                _state = value;
            }
        }

        public string County
        {
            get
            {
                return _county;
            }
            set
            {
                _county = value;
            }
        }

        public string FollowupNotes
        {
            get
            {
                return _followupNote;
            }
            set
            {
                _followupNote = value;
            }
        }

        public DateTime FollowupDate
        {
            get
            {
                return _followupDate;
            }
            set
            {
                _followupDate = value;
            }
        }

        public int FollowupExperience
        {
            get
            {
                return _followupExperience;
            }
            set
            {
                _followupExperience = value;
            }
        }

        public int FollowupHousingStatus
        {
            get
            {
                return _followupHousingStatus;
            }
            set
            {
                _followupHousingStatus = value;
            }
        }

        public bool Erased
        {
            get
            {
                return _erased;
            }
        }

        #endregion

        #region Public Methods

        public void Save(string userId, int prototypeId)
        {
            SaveHelp(userId, prototypeId);
        }

        public void Delete(int helpId, int personId)
        {
            ResourceCenterHelpData help = new ResourceCenterHelpData();
            if (help.DeleteResourceCenterHelp(helpId, personId) == 0)
            {
                _erased = true;
            }
            else
            {
                _erased = false;
            }
        }

        public void Delete(int personId)
        {
            // delete record
            ResourceCenterHelpData HelpData = new ResourceCenterHelpData();
            if (HelpData.DeleteResourceCenterHelp(_Id, personId) == 0)
            {
                _erased = true;
            }
            else
            {
                _erased = false;
            }

            _Id = -1;
        }

        public void AddLink(int helpId, int personId)
        {
            new ResourceCenterHelpData().AddNewLink(helpId, personId);
        }

        #endregion

        #region Private Methods

        private void SaveHelp(string userId, int prototypeId)
        {
            _Id = new ResourceCenterHelpData().SaveResourceCenterHelp(_Id, _date, _type, _amount, _size, _description, _subsidized,
                _subAmountReceived, _subSource, _vendor, _complete, _assistant, _completedDate, _resolution, _subType, _notes, userId,
                _address, _city, _zip, _state, _county, prototypeId, _followupNote, _followupDate, _followupExperience, _followupHousingStatus);
        }

        private void LoadHelp(SqlDataReader reader)
        {
            if (!reader.IsDBNull(reader.GetOrdinal("id")))
                _Id = (int)reader["id"];

            if (!reader.IsDBNull(reader.GetOrdinal("date_created")))
                _dateCreated = (DateTime)reader["date_created"];

            if (!reader.IsDBNull(reader.GetOrdinal("date_updated")))
                _dateUpdated = (DateTime)reader["date_updated"];

            _createdBy = reader["created_by"].ToString();

            _updatedBy = reader["updated_by"].ToString();

            if (!reader.IsDBNull(reader.GetOrdinal("date")))
                _date = (DateTime)reader["date"];

            if (!reader.IsDBNull(reader.GetOrdinal("type")))
                _type = (int)reader["type"];

            if (!reader.IsDBNull(reader.GetOrdinal("size")))
                _size = (int)reader["size"];

            if (!reader.IsDBNull(reader.GetOrdinal("amount")))
                _amount = (decimal)reader["amount"];

            _description = reader["description"].ToString();

            if (!reader.IsDBNull(reader.GetOrdinal("sub")))
                _subsidized = (int)reader["sub"];

            if (!reader.IsDBNull(reader.GetOrdinal("sub_recieved")))
                _subAmountReceived = (decimal)reader["sub_recieved"];

            _subSource = reader["sub_source"].ToString();

            _vendor = reader["vendor"].ToString();

            _complete = reader["complete"].ToString();

            _assistant = reader["assistant"].ToString();

            if (!reader.IsDBNull(reader.GetOrdinal("completed_on")))
                _completedDate = (DateTime)reader["completed_on"];

            _resolution = reader["resolution"].ToString();

            if (!reader.IsDBNull(reader.GetOrdinal("sub_type")))
                _subType = (int)reader["sub_type"];

            _notes = reader["notes"].ToString();

            _address = reader["address"].ToString();
            _city = reader["city"].ToString();
            _zip = reader["zip"].ToString();
            _state = reader["state"].ToString();
            _county = reader["county"].ToString();

            _followupNote = reader["followup_notes"].ToString();
            if (!reader.IsDBNull(reader.GetOrdinal("followup_date")))
                _followupDate = (DateTime)reader["followup_date"];
            if (!reader.IsDBNull(reader.GetOrdinal("followup_housing_status")))
                _followupHousingStatus = (int)reader["followup_housing_status"];
            if (!reader.IsDBNull(reader.GetOrdinal("followup_experience")))
                _followupExperience = (int)reader["followup_experience"];
        }

        #endregion

        #region Static Methods

        public static string GetTypeNameById(int typeId)
        {
            string s = string.Empty;
            switch (typeId)
            {
                case 1:
                    s = "Computer";
                    break;
                case 2:
                    s = "Food";
                    break;
                case 4:
                    s = "Holiday";
                    break;
                case 8:
                    s = "Housing";
                    break;
                case 16:
                    s = "Internet";
                    break;
                case 32:
                    s = "Job Related";
                    break;
                case 64:
                    s = "Other";
                    break;
                case 128:
                    s = "Basic Needs";
                    break;
                case 256:
                    s = "Tax";
                    break;
                case 512:
                    s = "School Supplies";
                    break;
                case 1024:
                    s = "Coat/Jacket";
                    break;
                case 2048:
                    s = "Shelter";
                    break;
                default:
                    s = "Unknown";
                    break;
            }
            return s;
        }

        public static string GetSubtypeNameById(int subtypeId)
        {
            return GetSubtypeDisplayById(subtypeId).Name;
        }

        public static ResourceCenterHelpSubType GetSubtypeDisplayById(int subtypeId)
        {
            return new ResourceCenterHelpSubType(subtypeId);
            /*string n = string.Empty;
            string st = string.Empty;
            bool q = false;
            bool v = false;
            switch (subtypeId)
            {
            case 1:
            n = "Household Basic";
            st = "of Items"; //Household Basic
            q = true;
            v = false;
            break;
            case 2:
            n = "Furniture";
            st = "of Items"; //Furniture
            q = true;
            v = false;
            break;
            case 3:
            n = "Transportation";
            st = ""; //Transportation
            q = false;
            v = false;
            break;
            case 4:
            n = "Gas Card";
            st = "of Gas Card"; //Gas Card
            q = false;
            v = true;
            break;
            case 5:
            n = "Clothing";
            st = "of Items"; //Clothing
            q = true;
            v = false;
            break;
            case 6:
            n = "Legal Fees";
            st = "of Check"; //Legal Fees
            q = false;
            v = true;
            break;
            case 7:
            n = "Child Care";
            st = "";  //Child Care
            q = true;
            v = true;
            break;
            case 8:
            n = "Food";
            st = "of Pounds"; //Food
            q = true;
            v = false;
            break;
            case 9:
            n = "Negotation";
            st = "of Minutes"; //"Negotation";
            q = true;
            v = false;
            break;
            case 10:
            n = "Coat/Jacket";
            st = "of Coats/Jackets"; //"Coat/Jacket";
            q = true;
            v = false;
            break;
            case 11:
            n = "Computer Use";
            st = ""; //"Computer Use";
            q = false;
            v = false;
            break;
            case 12:
            n = "Personal Care Items";
            st = "of Personal Care Kits"; //"Personal Care Items";
            q = true;
            v = false;
            break;
            case 13:
            n = "Other";
            st = ""; //"Other";
            q = true;
            v = true;
            break;
            case 14:
            n = "Shelter";
            st = ""; //"Shelter";
            q = false;
            v = false;
            break;
            case 15:
            n = "Rental Assistance";
            st = "of Check"; //"Rental Assistance";
            q = false;
            v = true;
            break;
            case 16:
            n = "Shelter Kit";
            st = "of Kits"; //"Shelter Kit";
            q = true;
            v = false;
            break;
            case 17:
            n = "Bedding Items";
            st = "of Bedding Items"; //"Bedding";
            q = true;
            v = false;
            break;
            case 18:
            n = "Voucher";
            st = "of Voucher"; //"Voucher";
            q = false;
            v = true;
            break;
            case 19:
            n = "School Supplies";
            st = ""; //"School Supplies";
            q = false;
            v = false;
            break;
            case 20:
            n = "Holiday Help";
            st = ""; //"Holiday Help";
            q = false;
            v = false;
            break;
            case 21:
            n = "Case Management";
            st = "of minutes"; //"Case Management";
            q = true;
            v = false;
            break;
            case 22:
            n = "\"Welcome Home\" Kit";
            st = "of Kits"; //"\"Welcome Home\" Kit";
            q = true;
            v = false;
            break;
            case 23:
            n = "Bikes";
            st = "of Bikes"; //"Bikes";
            q = true;
            v = false;
            break;
            case 24:
            n = "Seasonal Food Program";
            st = "of Pounds"; //"Seasonal Food Program";
            q = true;
            v = false;
            break;
            case 25:
            n = "Utility";
            st = "of Check"; //"Utility";
            q = false;
            v = true;
            break;
            case 26:
            n = "Church Ride Request";
            st = "";
            q = false;
            v = false;
            break;
            default:
            n = "Unknown (" + subtypeId.ToString() + ")";
            st = "";
            q = true;
            v = true;
            break;
            }
            ResourceCenterHelpSubType id = new ResourceCenterHelpSubType(1, n, st, q, v);
            return id;*/
        }

        #endregion

        #region Constructors

        public ResourceCenterHelp()
        {
        }

        public ResourceCenterHelp(int Id)
        {
            SqlDataReader reader = new ResourceCenterHelpData().GetResourceCenterHelpByID(Id);
            if (reader.Read())
                LoadHelp(reader);
            reader.Close();
        }

        public ResourceCenterHelp(SqlDataReader reader)
        {
            LoadHelp(reader);
        }
        #endregion
    }
}