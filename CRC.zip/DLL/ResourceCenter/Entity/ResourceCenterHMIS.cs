using System;
using System.Data.SqlClient;
using Arena.Core;
using Arena.Custom.SALC.ResourceCenter.DataLayer;

namespace Arena.Custom.SALC.ResourceCenter.Entity
{
    [Serializable]
    public class ResourceCenterHMIS : ArenaObjectBase
    {
        #region Private Members
        private int _id = -1;
        private DateTime _date = DateTime.MinValue;
        private int _helpId = -1;
        private int _orgId = 1;
        private int _destination = 0;
        private int _reason = 0;
        private DateTime _entered = Arena.DataLib.SqlData.DateTimeMinValue;

        private DateTime _dateCreated = DateTime.MinValue;      //General
        private DateTime _dateUpdated = DateTime.MinValue;      //General
        private string _createdBy = string.Empty;               //General
        private string _updatedBy = string.Empty;               //General

        #endregion

        #region Public Properties

        public int Id
        {
            get
            {
                return _id;
            }
            //set { _Id = value; }
        }

        public DateTime DateCreated
        {
            get
            {
                return _dateCreated;
            }
            //set { _dateCreated = value; }
        }

        public DateTime DateUpdated
        {
            get
            {
                return _dateUpdated;
            }
            //set { _dateUpdated = value; }
        }

        public string CreatedBy
        {
            get
            {
                return _createdBy;
            }
            //set { _createdBy = value; }
        }

        public string UpdatedBy
        {
            get
            {
                return _updatedBy;
            }
            //set { _updatedBy = value; }
        }

        public DateTime TagDate
        {
            get
            {
                return _date;
            }
            set
            {
                _date = value;
            }
        }

        public DateTime EnteredDate
        {
            get
            {
                return _entered;
            }
            set
            {
                _entered = value;
            }
        }

        public int HelpId
        {
            get
            {
                return _helpId;
            }
            set
            {
                _helpId = value;
            }
        }

        public int ReasonForLeaving
        {
            get
            {
                return _reason;
            }
            set
            {
                _reason = value;
            }
        }

        public int Destination
        {
            get
            {
                return _destination;
            }
            set
            {
                _destination = value;
            }
        }

        #endregion

        #region Public Methods

        public void Save(string userId)
        {
            SaveHMIS(userId);
        }

        public static void Delete(int Id)
        {
            new ResourceCenterHMISData().DeleteResourceCenterHMIS(Id);
        }

        public void Delete()
        {
            // delete record
            ResourceCenterHMISData hmisData = new ResourceCenterHMISData();
            hmisData.DeleteResourceCenterHMIS(_id);

            _id = -1;
        }

        #endregion

        #region Private Methods

        private void SaveHMIS(string userId)
        {
            _id = new ResourceCenterHMISData().SaveResourceCenterHMIS(_orgId, _id, _helpId, _date, _entered, _reason, _destination, userId);
        }

        private void LoadHMIS(SqlDataReader reader)
        {
            if (!reader.IsDBNull(reader.GetOrdinal("hmis_id")))
                _id = (int)reader["hmis_id"];

            if (!reader.IsDBNull(reader.GetOrdinal("date_created")))
                _dateCreated = (DateTime)reader["date_created"];

            if (!reader.IsDBNull(reader.GetOrdinal("date_updated")))
                _dateUpdated = (DateTime)reader["date_updated"];

            if (!reader.IsDBNull(reader.GetOrdinal("entered_date")))
                _entered = (DateTime)reader["entered_date"];

            _createdBy = reader["created_by"].ToString();

            _updatedBy = reader["updated_by"].ToString();

            if (!reader.IsDBNull(reader.GetOrdinal("tag_date")))
                _date = (DateTime)reader["tag_date"];

            if (!reader.IsDBNull(reader.GetOrdinal("reason_for_leaving")))
                _reason = (int)reader["reason_for_leaving"];

            if (!reader.IsDBNull(reader.GetOrdinal("destination")))
                _destination = (int)reader["destination"];

            if (!reader.IsDBNull(reader.GetOrdinal("help_id")))
                _helpId = (int)reader["help_id"];

            if (!reader.IsDBNull(reader.GetOrdinal("organization_id")))
                _orgId = (int)reader["organization_id"];
        }

        #endregion

        #region Static Methods
        #endregion

        #region Constructors

        public ResourceCenterHMIS()
        {
        }

        public ResourceCenterHMIS(int Id)
        {
            SqlDataReader reader = new ResourceCenterHMISData().GetResourceCenterHMISByID(Id);
            if (reader.Read())
                LoadHMIS(reader);
            reader.Close();
        }

        public ResourceCenterHMIS(SqlDataReader reader)
        {
            LoadHMIS(reader);
        }
        #endregion
    }
}