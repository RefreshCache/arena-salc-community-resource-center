using System;
using System.Data.SqlClient;
using Arena.Core;
using Arena.Custom.SALC.ResourceCenter.DataLayer;

namespace Arena.Custom.SALC.ResourceCenter.Entity
{
    [Serializable]
    public class ResourceCenterHelpCollection : ArenaCollectionBase
    {
        #region Class Indexers
        public new ResourceCenterHelp this[int index]
        {
            get
            {
                if (this.List.Count > 0)
                {
                    return (ResourceCenterHelp)this.List[index];
                }
                else
                {
                    return null;
                }
            }
            set
            {
                this.List[index] = value;
            }
        }

        #endregion

        #region Constructors

        public ResourceCenterHelpCollection()
        {
        }

        public ResourceCenterHelpCollection(int orgId, int personId)
        {
            SqlDataReader reader = new ResourceCenterHelpData().GetAllResourceCenterHelps(orgId, personId);
            while (reader.Read())
                this.Add(new ResourceCenterHelp(reader));
            reader.Close();
        }

        #endregion

        #region Public Methods

        public void Add(ResourceCenterHelp item)
        {
            this.List.Add(item);
        }

        public void Insert(int index, ResourceCenterHelp item)
        {
            this.List.Insert(index, item);
        }

        #endregion

        #region Static Methods

        public static ResourceCenterHelpCollection LoadAll(int orgId, int personId)
        {
            SqlDataReader reader = new ResourceCenterHelpData().GetAllResourceCenterHelps(orgId, personId);
            ResourceCenterHelpCollection collection = new ResourceCenterHelpCollection();
            while (reader.Read())
            {
                collection.Add(new ResourceCenterHelp(reader));
            }
            reader.Close();
            return collection;
        }
        #endregion
    }
}