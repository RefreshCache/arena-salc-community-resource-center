using System;
using System.Data.SqlClient;
using Arena.Core;
using Arena.Custom.SALC.ResourceCenter.DataLayer;

namespace Arena.Custom.SALC.ResourceCenter.Entity
{
    [Serializable]
    public class ResourceCenterHMISCollection : ArenaCollectionBase
    {
        #region Class Indexers
        public new ResourceCenterHMIS this[int index]
        {
            get
            {
                if (this.List.Count > 0)
                {
                    return (ResourceCenterHMIS)this.List[index];
                }
                else
                {
                    return null;
                }
            }
            set
            {
                this.List[index] = value;
            }
        }

        #endregion

        #region Constructors

        public ResourceCenterHMISCollection()
        {
        }

        public ResourceCenterHMISCollection(int hmisId)
        {
            SqlDataReader reader = new ResourceCenterHMISData().GetResourceCenterHMISByID(hmisId);
            while (reader.Read())
                this.Add(new ResourceCenterHMIS(reader));
            reader.Close();
        }

        #endregion

        #region Public Methods

        public void Add(ResourceCenterHMIS item)
        {
            this.List.Add(item);
        }

        public void Insert(int index, ResourceCenterHMIS item)
        {
            this.List.Insert(index, item);
        }

        #endregion

        #region Static Methods

        public static ResourceCenterHMISCollection LoadAll(int orgId, int helpId)
        {
            SqlDataReader reader = new ResourceCenterHMISData().GetAllResourceCenterHMIS(orgId, helpId);
            ResourceCenterHMISCollection collection = new ResourceCenterHMISCollection();
            while (reader.Read())
            {
                collection.Add(new ResourceCenterHMIS(reader));
            }
            reader.Close();
            return collection;
        }
        #endregion
    }
}