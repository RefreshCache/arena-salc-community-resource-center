using System;
using System.Data.SqlClient;
using Arena.Core;
using Arena.Custom.SALC.ResourceCenter.DataLayer;

namespace Arena.Custom.SALC.ResourceCenter.Entity
{
    [Serializable]
    public class ResourceCenterDocument : ArenaObjectBase
    {
        #region Private Members
        private int _Id = -1;
        private int _parent = 0;
        private int _parentId = 0;
        private string _name = string.Empty;
        private string _mime = string.Empty;
        private int _size = 0;
        private byte[] _data;

        private DateTime _dateCreated = DateTime.MinValue;      //General
        private DateTime _dateUpdated = DateTime.MinValue;      //General
        private string _createdBy = string.Empty;               //General
        private string _updatedBy = string.Empty;               //General

        #endregion

        #region Public Properties

        public int Id
        {
            get
            {
                return _Id;
            }
            //set { _Id = value; }
        }

        public DateTime DateCreated
        {
            get
            {
                return _dateCreated;
            }
            //set { _dateCreated = value; }
        }

        public DateTime DateUpdated
        {
            get
            {
                return _dateUpdated;
            }
            //set { _dateUpdated = value; }
        }

        public string CreatedBy
        {
            get
            {
                return _createdBy;
            }
            //set { _createdBy = value; }
        }

        public string UpdatedBy
        {
            get
            {
                return _updatedBy;
            }
            //set { _updatedBy = value; }
        }

        public int Parent
        {
            get
            {
                return _parent;
            }
            set
            {
                _parent = value;
            }
        }

        public int ParentId
        {
            get
            {
                return _parentId;
            }
            set
            {
                _parentId = value;
            }
        }

        public string Name
        {
            get
            {
                return _name;
            }
            set
            {
                _name = value;
            }
        }

        public string Mime
        {
            get
            {
                return _mime;
            }
            set
            {
                _mime = value;
            }
        }

        public int Size
        {
            get
            {
                return _size;
            }
            set
            {
                _size = value;
            }
        }

        public byte[] Data
        {
            get
            {
                return _data;
            }
            set
            {
                _data = value;
            }
        }

        #endregion

        #region Public Methods

        public void Save(int orgId, string userId, bool family)
        {
            SaveDocument(orgId, userId, family);
        }

        public static void Delete(int Id)
        {
            new ResourceCenterDocumentData().DeleteResourceCenterDocument(Id);
        }

        public void Delete()
        {
            // delete record
            ResourceCenterDocumentData DocumentData = new ResourceCenterDocumentData();
            DocumentData.DeleteResourceCenterDocument(_Id);

            _Id = -1;
        }

        #endregion

        #region Private Methods

        private void SaveDocument(int orgId, string userId, bool family)
        {
            _Id = new ResourceCenterDocumentData().SaveResourceCenterDocument(orgId, _Id, userId, _parent, _parentId, _name, _mime, _size, _data, family);
        }

        private void LoadDocument(SqlDataReader reader, bool readData)
        {
            _Id = (int)reader["id"];
            _dateCreated = (DateTime)reader["date_created"];
            _dateUpdated = (DateTime)reader["date_updated"];
            _createdBy = reader["created_by"].ToString();
            _updatedBy = reader["updated_by"].ToString();
            _parent = (int)reader["parent"];
            _parentId = (int)reader["parent_id"];
            _name = reader["name"].ToString();
            _size = (int)reader["size"];
            _mime = reader["mime"].ToString();

            if (readData)
            {
                if (!reader.IsDBNull(reader.GetOrdinal("data")))
                {
                    _data = new byte[_size];
                    reader.GetBytes(reader.GetOrdinal("data"), 0, _data, 0, _size);
                }
            }
        }

        #endregion

        #region Static Methods
        #endregion

        #region Constructors

        public ResourceCenterDocument()
        {
        }

        public ResourceCenterDocument(int Id)
        {
            SqlDataReader reader = new ResourceCenterDocumentData().GetResourceCenterDocumentByID(Id);
            if (reader.Read())
                LoadDocument(reader, true);
            reader.Close();
        }

        public ResourceCenterDocument(SqlDataReader reader)
        {
            LoadDocument(reader, false);
        }
        #endregion
    }
}