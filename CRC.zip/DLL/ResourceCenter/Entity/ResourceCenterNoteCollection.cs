using System;
using System.Data.SqlClient;
using Arena.Core;
using Arena.Custom.SALC.ResourceCenter.DataLayer;

namespace Arena.Custom.SALC.ResourceCenter.Entity
{
    [Serializable]
    public class ResourceCenterNoteCollection : ArenaCollectionBase
    {
        #region Class Indexers
        public new ResourceCenterNote this[int index]
        {
            get
            {
                if (this.List.Count > 0)
                {
                    return (ResourceCenterNote)this.List[index];
                }
                else
                {
                    return null;
                }
            }
            set
            {
                this.List[index] = value;
            }
        }

        #endregion

        #region Constructors

        public ResourceCenterNoteCollection()
        {
        }

        public ResourceCenterNoteCollection(int noteId)
        {
            SqlDataReader reader = new ResourceCenterNoteData().GetResourceCenterNoteByID(noteId);
            while (reader.Read())
                this.Add(new ResourceCenterNote(reader));
            reader.Close();
        }

        #endregion

        #region Public Methods

        public void Add(ResourceCenterNote item)
        {
            this.List.Add(item);
        }

        public void Insert(int index, ResourceCenterNote item)
        {
            this.List.Insert(index, item);
        }

        #endregion

        #region Static Methods

        public static ResourceCenterNoteCollection LoadAll(int orgId, DateTime startDate, DateTime endDate, int helpId, int clientId)
        {
            SqlDataReader reader = new ResourceCenterNoteData().GetAllResourceCenterNotes(orgId, startDate, endDate, helpId, clientId);
            ResourceCenterNoteCollection collection = new ResourceCenterNoteCollection();
            while (reader.Read())
            {
                collection.Add(new ResourceCenterNote(reader));
            }
            reader.Close();
            return collection;
        }

        public static ResourceCenterNoteCollection LoadAll(DateTime startDate, DateTime endDate, int orgId)
        {
            SqlDataReader reader = new ResourceCenterNoteData().GetAllResourceCenterNotes(startDate, endDate, orgId);
            ResourceCenterNoteCollection collection = new ResourceCenterNoteCollection();
            while (reader.Read())
            {
                collection.Add(new ResourceCenterNote(reader));
            }
            reader.Close();
            return collection;
        }
        #endregion
    }
}