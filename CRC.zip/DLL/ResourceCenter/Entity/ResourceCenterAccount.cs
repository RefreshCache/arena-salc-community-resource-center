using System;
using System.Data.SqlClient;
using Arena.Core;
using Arena.Custom.SALC.ResourceCenter.DataLayer;

namespace Arena.Custom.SALC.ResourceCenter.Entity
{
    [Serializable]
    public class ResourceCenterAccount : ArenaObjectBase
    {
        #region Private Members
        private int piId = -1;
        private int piHelpId = 0;
        private decimal pdAmount = 0;
        private DateTime pdtDate = DateTime.MinValue;
        private string psNote = string.Empty;
        private int piOrganizationId = 1;

        #endregion

        #region Public Properties

        public int Id
        {
            get
            {
                return piId;
            }
            //set { _Id = value; }
        }

        public int HelpId
        {
            get
            {
                return piHelpId;
            }
            set
            {
                piHelpId = value;
            }
        }

        public decimal Amount
        {
            get
            {
                return pdAmount;
            }
            set
            {
                pdAmount = value;
            }
        }

        public string Note
        {
            get
            {
                return psNote;
            }
            set
            {
                psNote = value;
            }
        }

        public int OrganizationId
        {
            get
            {
                return piOrganizationId;
            }
            set
            {
                piOrganizationId = value;
            }
        }
        public DateTime Date
        {
            get
            {
                return pdtDate;
            }
            set
            {
                pdtDate = value;
            }
        }

        #endregion

        #region Public Methods

        public void Save()
        {
            SaveAccount();
        }

        public static void Delete(int id)
        {
            new ResourceCenterAccountData().DeleteResourceCenterAccount(id);
        }

        public void Delete()
        {
            // delete record
            ResourceCenterAccountData accountData = new ResourceCenterAccountData();
            accountData.DeleteResourceCenterAccount(piId);

            piId = -1;
        }

        #endregion

        #region Private Methods

        private void SaveAccount()
        {
            piId = new ResourceCenterAccountData().SaveResourceCenterAccount(piOrganizationId, piId, piHelpId, pdAmount, pdtDate, psNote);
        }

        private void LoadAccount(SqlDataReader reader)
        {
            piId = (int)reader["id"];
            piHelpId = (int)reader["help_id"];
            pdAmount = (decimal)reader["amount"];
            pdtDate = (DateTime)reader["date"];
            psNote = reader["note"].ToString();
            piOrganizationId = (int)reader["organization_id"];
        }

        #endregion

        #region Static Methods
        #endregion

        #region Constructors

        public ResourceCenterAccount()
        {
        }

        public ResourceCenterAccount(int id)
        {
            SqlDataReader reader = new ResourceCenterAccountData().GetResourceCenterAccountByID(id);
            if (reader.Read())
                LoadAccount(reader);
            reader.Close();
        }

        public ResourceCenterAccount(SqlDataReader reader)
        {
            LoadAccount(reader);
        }
        #endregion
    }
}