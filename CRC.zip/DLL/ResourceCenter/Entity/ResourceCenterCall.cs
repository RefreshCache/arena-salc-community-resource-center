using System;
using System.Data.SqlClient;
using Arena.Core;
using Arena.Custom.SALC.ResourceCenter.DataLayer;

namespace Arena.Custom.SALC.ResourceCenter.Entity
{
    [Serializable]
    public class ResourceCenterCall : ArenaObjectBase
    {
        #region Private Members
        private int _Id = -1;
        private DateTime _date = DateTime.MinValue;
        private string _name = string.Empty;
        private string _phone = string.Empty;
        private string _county = string.Empty;
        private string _msgFor = string.Empty;
        private int _hh = 1;
        private int _recieve = 0;
        private int _callType = 0;
        private int _reqFood = 0;
        private int _reqShelter = 0;
        private int _reqRent = 0;
        private int _reqUtility = 0;
        private int _reqFurn = 0;
        private int _reqOther = 0;
        private string _notes = string.Empty;
        private int _completed = 0;
        private int _personId = 0;
        private int _orgId = 1;

        private DateTime _dateCreated = DateTime.MinValue;      //General
        private DateTime _dateUpdated = DateTime.MinValue;      //General
        private string _createdBy = string.Empty;               //General
        private string _updatedBy = string.Empty;               //General

        #endregion

        #region Public Properties

        public int Id
        {
            get
            {
                return _Id;
            }
            //set { _Id = value; }
        }

        public DateTime DateCreated
        {
            get
            {
                return _dateCreated;
            }
            //set { _dateCreated = value; }
        }

        public DateTime DateUpdated
        {
            get
            {
                return _dateUpdated;
            }
            //set { _dateUpdated = value; }
        }

        public string CreatedBy
        {
            get
            {
                return _createdBy;
            }
            //set { _createdBy = value; }
        }

        public string UpdatedBy
        {
            get
            {
                return _updatedBy;
            }
            //set { _updatedBy = value; }
        }

        public DateTime Date
        {
            get
            {
                return _date;
            }
            set
            {
                _date = value;
            }
        }

        public String Name
        {
            get
            {
                return _name;
            }
            set
            {
                _name = value;
            }
        }

        public String phone
        {
            get
            {
                return _phone;
            }
            set
            {
                _phone = value;
            }
        }

        public String County
        {
            get
            {
                return _county;
            }
            set
            {
                _county = value;
            }
        }

        public String MessageFor
        {
            get
            {
                return _msgFor;
            }
            set
            {
                _msgFor = value;
            }
        }

        public int HH
        {
            get
            {
                return _hh;
            }
            set
            {
                _hh = value;
            }
        }

        public int Recieve
        {
            get
            {
                return _recieve;
            }
            set
            {
                _recieve = value;
            }
        }

        public int CallType
        {
            get
            {
                return _callType;
            }
            set
            {
                _callType = value;
            }
        }

        public int ReqFood
        {
            get
            {
                return _reqFood;
            }
            set
            {
                _reqFood = value;
            }
        }

        public int ReqShelter
        {
            get
            {
                return _reqShelter;
            }
            set
            {
                _reqShelter = value;
            }
        }

        public int ReqRent
        {
            get
            {
                return _reqRent;
            }
            set
            {
                _reqRent = value;
            }
        }

        public int ReqUtility
        {
            get
            {
                return _reqUtility;
            }
            set
            {
                _reqUtility = value;
            }
        }

        public int ReqFurn
        {
            get
            {
                return _reqFurn;
            }
            set
            {
                _reqFurn = value;
            }
        }

        public int ReqOther
        {
            get
            {
                return _reqOther;
            }
            set
            {
                _reqOther = value;
            }
        }

        public string Notes
        {
            get
            {
                return _notes;
            }
            set
            {
                _notes = value;
            }
        }

        public int Completed
        {
            get
            {
                return _completed;
            }
            set
            {
                _completed = value;
            }
        }

        public int PersonId
        {
            get
            {
                return _personId;
            }
            set
            {
                _personId = value;
            }
        }

        public int OrganizationId
        {
            get
            {
                return _orgId;
            }
            set
            {
                _orgId = value;
            }
        }

        public string FullName
        {
            get
            {
                if (_personId > 0)
                {
                    ResourceCenterPerson p = new ResourceCenterPerson(_personId);
                    return p.FirstName + " " + p.LastName;
                }
                else
                {
                    return _name;
                }
            }
        }

        #endregion

        #region Public Methods

        public void Save(string userId)
        {
            SaveCall(userId);
        }

        public static void Delete(int Id)
        {
            new ResourceCenterCallData().DeleteResourceCenterCall(Id);
        }

        public void Delete()
        {
            // delete record
            ResourceCenterCallData CallData = new ResourceCenterCallData();
            CallData.DeleteResourceCenterCall(_Id);

            _Id = -1;
        }

        #endregion

        #region Private Methods

        private void SaveCall(string userId)
        {
            _Id = new ResourceCenterCallData().SaveResourceCenterCall(_orgId, _Id, userId, _date, _name, _phone, _county, _msgFor, _hh, _recieve, _callType,
                _reqFood, _reqShelter, _reqRent, _reqUtility, _reqFurn, _reqOther, _notes, _completed, _personId);
        }

        private void LoadCall(SqlDataReader reader)
        {
            if (!reader.IsDBNull(reader.GetOrdinal("id")))
                _Id = (int)reader["id"];

            if (!reader.IsDBNull(reader.GetOrdinal("date_created")))
                _dateCreated = (DateTime)reader["date_created"];

            if (!reader.IsDBNull(reader.GetOrdinal("date_updated")))
                _dateUpdated = (DateTime)reader["date_updated"];

            _createdBy = reader["created_by"].ToString();

            _updatedBy = reader["updated_by"].ToString();

            if (!reader.IsDBNull(reader.GetOrdinal("date")))
                _date = (DateTime)reader["date"];

            _name = reader["name"].ToString();
            _phone = reader["phone"].ToString();
            _county = reader["county"].ToString();
            _msgFor = reader["msg_for"].ToString();
            _hh = (int)reader["hh"];
            _recieve = (int)reader["recieve"];
            _callType = (int)reader["call_type"];
            _reqFood = (int)reader["req_food"];
            _reqShelter = (int)reader["req_shelter"];
            _reqRent = (int)reader["req_rent"];
            _reqUtility = (int)reader["req_utility"];
            _reqFurn = (int)reader["req_furn"];
            _reqOther = (int)reader["req_other"];
            _notes = reader["notes"].ToString();
            _completed = (int)reader["completed"];

            if (!reader.IsDBNull(reader.GetOrdinal("person_id")))
                _personId = (int)reader["person_id"];

            if (!reader.IsDBNull(reader.GetOrdinal("organization_id")))
                _orgId = (int)reader["organization_id"];
        }

        #endregion

        #region Static Methods
        #endregion

        #region Constructors

        public ResourceCenterCall()
        {
        }

        public ResourceCenterCall(int Id)
        {
            SqlDataReader reader = new ResourceCenterCallData().GetResourceCenterCallByID(Id);
            if (reader.Read())
                LoadCall(reader);
            reader.Close();
        }

        public ResourceCenterCall(SqlDataReader reader)
        {
            LoadCall(reader);
        }
        #endregion
    }
}