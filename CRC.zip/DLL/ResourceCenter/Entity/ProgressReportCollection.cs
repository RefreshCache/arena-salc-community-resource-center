using System;
using System.Data.SqlClient;
using Arena.Core;
using Arena.Custom.SALC.ResourceCenter.DataLayer;

namespace Arena.Custom.SALC.ResourceCenter.Entity
{
    [Serializable]
    public class ProgressReportCollection : ArenaCollectionBase
    {
        #region Class Indexers
        public new ProgressReport this[int index]
        {
            get
            {
                if (this.List.Count > 0)
                {
                    return (ProgressReport)this.List[index];
                }
                else
                {
                    return null;
                }
            }
            set
            {
                this.List[index] = value;
            }
        }

        #endregion

        #region Constructors

        public ProgressReportCollection()
        {
        }

        public ProgressReportCollection(int progrprtId)
        {
            SqlDataReader reader = new ProgressReportData().GetProgressReportByID(progrprtId);
            while (reader.Read())
                this.Add(new ProgressReport(reader));
            reader.Close();
        }

        #endregion

        #region Public Methods

        public void Add(ProgressReport item)
        {
            this.List.Add(item);
        }

        public void Insert(int index, ProgressReport item)
        {
            this.List.Insert(index, item);
        }

        #endregion

        #region Static Methods

        public static ProgressReportCollection LoadAll(int goalId, int orgId)
        {
            SqlDataReader reader = new ProgressReportData().GetAllProgressReports(goalId, orgId);
            ProgressReportCollection collection = new ProgressReportCollection();
            while (reader.Read())
            {
                collection.Add(new ProgressReport(reader));
            }
            reader.Close();
            return collection;
        }

        public static ProgressReportCollection LoadAll(DateTime startDate, DateTime endDate, int goalId, int orgId)
        {
            SqlDataReader reader = new ProgressReportData().GetAllProgressReports(startDate, endDate, goalId, orgId);
            ProgressReportCollection collection = new ProgressReportCollection();
            while (reader.Read())
            {
                collection.Add(new ProgressReport(reader));
            }
            reader.Close();
            return collection;
        } 

        #endregion
    }
}