using System;
using System.Data.SqlClient;
using Arena.Core;
using Arena.Custom.SALC.ResourceCenter.DataLayer;

namespace Arena.Custom.SALC.ResourceCenter.Entity
{
    [Serializable]
    public class ResourceCenterPerson : ArenaObjectBase
    {
        #region Private Members
        private int _Id = -1;
        //private Person _person = null;
        private int _personId = -1;
        private int _numAdults = 0;
        private int _numChildren = 0;
        private string _county = string.Empty;
        private int _helpRequested = 0;
        private string _notes = string.Empty;
        private DateTime _dateCreated = DateTime.MinValue;
        private DateTime _dateUpdated = DateTime.MinValue;
        private string _createdBy = string.Empty;
        private string _updatedBy = string.Empty;

        private string _nickName = string.Empty;
        private string _firstName = string.Empty;
        private string _middleName = string.Empty;
        private string _lastName = string.Empty;
        private string _suffix = string.Empty;
        private DateTime _birthday = DateTime.MinValue;
        private string _gender = "U";
        private string _email = string.Empty;
        private string _streetAddress = string.Empty;
        private string _city = string.Empty;
        private string _state = string.Empty;
        private string _postalCode = string.Empty;
        private string _ssn = string.Empty;

        private string _schoolDistrict = string.Empty;
        private decimal _incomeEmployment = 0;
        private decimal _incomeMFIP = 0;
        private decimal _incomeMA = 0;
        private decimal _incomeChildSupport = 0;
        private decimal _incomeUnemployment = 0;
        private decimal _incomeSSISSDI = 0;
        private decimal _incomeOther = 0;
        private decimal _cashOnHand = 0;
        private int _issuesOfNote = 0;
        private DateTime _lastDateWorked = DateTime.MinValue;

        private int _mstatus = 0;
        private int _dlicense = 0;
        private int _ebt = 0;
        private decimal _foodSupport = 0;
        private DateTime _assistanceApplied = DateTime.MinValue;
        private string _foodShelf = string.Empty;
        private DateTime _foodShelfVisit = DateTime.MinValue;
        private string _casemgr1Name = string.Empty;
        private string _casemgr1Agency = string.Empty;
        private string _casemgr1Phone = string.Empty;
        private string _casemgr1notes = string.Empty;
        private string _casemgr2Name = string.Empty;
        private string _casemgr2Agency = string.Empty;
        private string _casemgr2Phone = string.Empty;
        private string _casemgr2notes = string.Empty;
        private string _emgassist1Angency = string.Empty;
        private string _emgassist1Casemgr = string.Empty;
        private string _emgassist1Phone = string.Empty;
        private DateTime _emgassist1Date = DateTime.MinValue;
        private decimal _emgassist1Amount = 0;
        private int _emgassist1Status = 0;
        private string _emgassist2Angency = string.Empty;
        private string _emgassist2Casemgr = string.Empty;
        private string _emgassist2Phone = string.Empty;
        private DateTime _emgassist2Date = DateTime.MinValue;
        private decimal _emgassist2Amount = 0;
        private int _emgassist2Status = 0;
        private int _pastShelter = 0;
        private DateTime _pastShelterDate = DateTime.MinValue;
        private int _pastUnsheltered = 0;
        private DateTime _pastUnshelteredDate = DateTime.MinValue;
        private int _pastChemical = 0;
        private DateTime _pastChemicalDate = DateTime.MinValue;
        private int _pastTransitional = 0;
        private DateTime _pastTransitionalDate = DateTime.MinValue;
        private int _pastDoubled = 0;
        private DateTime _pastDoubledDate = DateTime.MinValue;
        private int _pastEviction = 0;
        private DateTime _pastEvictionDate = DateTime.MinValue;
        private int _pastForeclosure = 0;
        private DateTime _pastForeclosureDate = DateTime.MinValue;
        private string _phoneHome = string.Empty;
        private string _phoneWork = string.Empty;
        private string _phoneMobile = string.Empty;
        private string _phoneOther = string.Empty;
        private int _empFreq = 7;
        private DateTime _empDate = DateTime.MinValue;
        private int _mfipDay = 1;
        private DateTime _childsupportDate = DateTime.MinValue;
        private DateTime _otherincomeDate = DateTime.MinValue;
        private string _message = string.Empty;
        private int _flag = 0;

        private DateTime _lastShelter = DateTime.MinValue;
        private DateTime _lastShelterExit = DateTime.MinValue;

        #endregion

        #region Public Properties

        public int Id
        {
            get
            {
                return _Id;
            }
            //set { _Id = value; }
        }

        public DateTime DateCreated
        {
            get
            {
                return _dateCreated;
            }
            //set { _dateCreated = value; }
        }

        public DateTime DateUpdated
        {
            get
            {
                return _dateUpdated;
            }
            //set { _dateUpdated = value; }
        }

        public string CreatedBy
        {
            get
            {
                return _createdBy;
            }
            //set { _createdBy = value; }
        }

        public string UpdatedBy
        {
            get
            {
                return _updatedBy;
            }
            //set { _updatedBy = value; }
        }

        public int PersonId
        {
            get
            {
                return _personId;
            }
            set
            {
                _personId = value;
            }
        }

        /*public Person Person
        {
        get { if (_person == null) { _person = new Person(_personId); } return _person; }
        set { _personId = value.PersonID; _person = null; }
        }*/

        public int NumAdults
        {
            get
            {
                return _numAdults;
            }
            set
            {
                _numAdults = value;
            }
        }

        public int NumChildren
        {
            get
            {
                return _numChildren;
            }
            set
            {
                _numChildren = value;
            }
        }

        public string County
        {
            get
            {
                return _county;
            }
            set
            {
                _county = value;
            }
        }

        public int HelpRequested
        {
            get
            {
                return _helpRequested;
            }
            set
            {
                _helpRequested = value;
            }
        }

        public string Notes
        {
            get
            {
                return _notes;
            }
            set
            {
                _notes = value;
            }
        }

        public string NickName
        {
            get
            {
                return _nickName;
            }
            set
            {
                _nickName = value;
            }
        }

        public string FirstName
        {
            get
            {
                return _firstName;
            }
            set
            {
                _firstName = value;
            }
        }

        public string MiddleName
        {
            get
            {
                return _middleName;
            }
            set
            {
                _middleName = value;
            }
        }

        public string LastName
        {
            get
            {
                return _lastName;
            }
            set
            {
                _lastName = value;
            }
        }

        public string Suffix
        {
            get
            {
                return _suffix;
            }
            set
            {
                _suffix = value;
            }
        }

        public DateTime Birthday
        {
            get
            {
                return _birthday;
            }
            set
            {
                _birthday = value;
            }
        }

        public string Gender
        {
            get
            {
                return _gender;
            }
            set
            {
                _gender = value;
            }
        }

        public string Email
        {
            get
            {
                return _email;
            }
            set
            {
                _email = value;
            }
        }

        public string StreetAddress
        {
            get
            {
                return _streetAddress;
            }
            set
            {
                _streetAddress = value;
            }
        }

        public string City
        {
            get
            {
                return _city;
            }
            set
            {
                _city = value;
            }
        }

        public string State
        {
            get
            {
                return _state;
            }
            set
            {
                _state = value;
            }
        }

        public string PostalCode
        {
            get
            {
                return _postalCode;
            }
            set
            {
                _postalCode = value;
            }
        }

        public string SSN
        {
            get
            {
                return _ssn;
            }
            set
            {
                _ssn = value;
            }
        }

        public string SchoolDistrict
        {
            get
            {
                return _schoolDistrict;
            }
            set
            {
                _schoolDistrict = value;
            }
        }

        public decimal IncomeEmployment
        {
            get
            {
                return _incomeEmployment;
            }
            set
            {
                _incomeEmployment = value;
            }
        }

        public decimal IncomeMFIP
        {
            get
            {
                return _incomeMFIP;
            }
            set
            {
                _incomeMFIP = value;
            }
        }

        public decimal IncomeMA
        {
            get
            {
                return _incomeMA;
            }
            set
            {
                _incomeMA = value;
            }
        }

        public decimal IncomeChildSupport
        {
            get
            {
                return _incomeChildSupport;
            }
            set
            {
                _incomeChildSupport = value;
            }
        }

        public decimal IncomeUnemployment
        {
            get
            {
                return _incomeUnemployment;
            }
            set
            {
                _incomeUnemployment = value;
            }
        }

        public decimal IncomeSSISSDI
        {
            get
            {
                return _incomeSSISSDI;
            }
            set
            {
                _incomeSSISSDI = value;
            }
        }

        public decimal IncomeOther
        {
            get
            {
                return _incomeOther;
            }
            set
            {
                _incomeOther = value;
            }
        }

        public decimal CashOnHand
        {
            get
            {
                return _cashOnHand;
            }
            set
            {
                _cashOnHand = value;
            }
        }

        public int IssuesOfNote
        {
            get
            {
                return _issuesOfNote;
            }
            set
            {
                _issuesOfNote = value;
            }
        }

        public DateTime LastDateWorked
        {
            get
            {
                return _lastDateWorked;
            }
            set
            {
                _lastDateWorked = value;
            }
        }

        public int MaritalStatus
        {
            get
            {
                return _mstatus;
            }
            set
            {
                _mstatus = value;
            }
        }

        public int DriversLicense
        {
            get
            {
                return _dlicense;
            }
            set
            {
                _dlicense = value;
            }
        }

        public int EBT
        {
            get
            {
                return _ebt;
            }
            set
            {
                _ebt = value;
            }
        }

        public decimal FoodSupport
        {
            get
            {
                return _foodSupport;
            }
            set
            {
                _foodSupport = value;
            }
        }

        public DateTime AssistanceApplied
        {
            get
            {
                return _assistanceApplied;
            }
            set
            {
                _assistanceApplied = value;
            }
        }

        public string FoodShelf
        {
            get
            {
                return _foodShelf;
            }
            set
            {
                _foodShelf = value;
            }
        }

        public DateTime FoodShelfVisit
        {
            get
            {
                return _foodShelfVisit;
            }
            set
            {
                _foodShelfVisit = value;
            }
        }

        public string CaseMgr1Name
        {
            get
            {
                return _casemgr1Name;
            }
            set
            {
                _casemgr1Name = value;
            }
        }

        public string CaseMgr1Agency
        {
            get
            {
                return _casemgr1Agency;
            }
            set
            {
                _casemgr1Agency = value;
            }
        }

        public string CaseMgr1Phone
        {
            get
            {
                return _casemgr1Phone;
            }
            set
            {
                _casemgr1Phone = value;
            }
        }

        public string CaseMgr1Notes
        {
            get
            {
                return _casemgr1notes;
            }
            set
            {
                _casemgr1notes = value;
            }
        }

        public string CaseMgr2Name
        {
            get
            {
                return _casemgr2Name;
            }
            set
            {
                _casemgr2Name = value;
            }
        }

        public string CaseMgr2Agency
        {
            get
            {
                return _casemgr2Agency;
            }
            set
            {
                _casemgr2Agency = value;
            }
        }

        public string CaseMgr2Phone
        {
            get
            {
                return _casemgr2Phone;
            }
            set
            {
                _casemgr2Phone = value;
            }
        }

        public string CaseMgr2Notes
        {
            get
            {
                return _casemgr2notes;
            }
            set
            {
                _casemgr2notes = value;
            }
        }

        public string EmgAssist1Agency
        {
            get
            {
                return _emgassist1Angency;
            }
            set
            {
                _emgassist1Angency = value;
            }
        }

        public string EmgAssist1CaseMgr
        {
            get
            {
                return _emgassist1Casemgr;
            }
            set
            {
                _emgassist1Casemgr = value;
            }
        }

        public string EmgAssist1Phone
        {
            get
            {
                return _emgassist1Phone;
            }
            set
            {
                _emgassist1Phone = value;
            }
        }

        public DateTime EmgAssist1Date
        {
            get
            {
                return _emgassist1Date;
            }
            set
            {
                _emgassist1Date = value;
            }
        }

        public decimal EmgAssist1Amount
        {
            get
            {
                return _emgassist1Amount;
            }
            set
            {
                _emgassist1Amount = value;
            }
        }

        public int EmgAssist1Status
        {
            get
            {
                return _emgassist1Status;
            }
            set
            {
                _emgassist1Status = value;
            }
        }

        public string EmgAssist2Agency
        {
            get
            {
                return _emgassist2Angency;
            }
            set
            {
                _emgassist2Angency = value;
            }
        }

        public string EmgAssist2CaseMgr
        {
            get
            {
                return _emgassist2Casemgr;
            }
            set
            {
                _emgassist2Casemgr = value;
            }
        }

        public string EmgAssist2Phone
        {
            get
            {
                return _emgassist2Phone;
            }
            set
            {
                _emgassist2Phone = value;
            }
        }

        public DateTime EmgAssist2Date
        {
            get
            {
                return _emgassist2Date;
            }
            set
            {
                _emgassist2Date = value;
            }
        }

        public decimal EmgAssist2Amount
        {
            get
            {
                return _emgassist2Amount;
            }
            set
            {
                _emgassist2Amount = value;
            }
        }

        public int EmgAssist2Status
        {
            get
            {
                return _emgassist2Status;
            }
            set
            {
                _emgassist2Status = value;
            }
        }

        public int PastShelter
        {
            get
            {
                return _pastShelter;
            }
            set
            {
                _pastShelter = value;
            }
        }

        public DateTime PastShelterDate
        {
            get
            {
                return _pastShelterDate;
            }
            set
            {
                _pastShelterDate = value;
            }
        }

        public int PastUnsheltered
        {
            get
            {
                return _pastUnsheltered;
            }
            set
            {
                _pastUnsheltered = value;
            }
        }

        public DateTime PastUnshelteredDate
        {
            get
            {
                return _pastUnshelteredDate;
            }
            set
            {
                _pastUnshelteredDate = value;
            }
        }

        public int PastChemical
        {
            get
            {
                return _pastChemical;
            }
            set
            {
                _pastChemical = value;
            }
        }

        public DateTime PastChemicalDate
        {
            get
            {
                return _pastChemicalDate;
            }
            set
            {
                _pastChemicalDate = value;
            }
        }

        public int PastTransitional
        {
            get
            {
                return _pastTransitional;
            }
            set
            {
                _pastTransitional = value;
            }
        }

        public DateTime PastTransitionalDate
        {
            get
            {
                return _pastTransitionalDate;
            }
            set
            {
                _pastTransitionalDate = value;
            }
        }

        public int PastDoubled
        {
            get
            {
                return _pastDoubled;
            }
            set
            {
                _pastDoubled = value;
            }
        }

        public DateTime PastDoubledDate
        {
            get
            {
                return _pastDoubledDate;
            }
            set
            {
                _pastDoubledDate = value;
            }
        }

        public int PastEviction
        {
            get
            {
                return _pastEviction;
            }
            set
            {
                _pastEviction = value;
            }
        }

        public DateTime PastEvictionDate
        {
            get
            {
                return _pastEvictionDate;
            }
            set
            {
                _pastEvictionDate = value;
            }
        }

        public int PastForeclosure
        {
            get
            {
                return _pastForeclosure;
            }
            set
            {
                _pastForeclosure = value;
            }
        }

        public DateTime PastForeclosureDate
        {
            get
            {
                return _pastForeclosureDate;
            }
            set
            {
                _pastForeclosureDate = value;
            }
        }

        public string PhoneHome
        {
            get
            {
                return _phoneHome;
            }
            set
            {
                _phoneHome = value;
            }
        }

        public string PhoneWork
        {
            get
            {
                return _phoneWork;
            }
            set
            {
                _phoneWork = value;
            }
        }

        public string PhoneMobile
        {
            get
            {
                return _phoneMobile;
            }
            set
            {
                _phoneMobile = value;
            }
        }

        public string PhoneOther
        {
            get
            {
                return _phoneOther;
            }
            set
            {
                _phoneOther = value;
            }
        }

        public DateTime LastShelter
        {
            get
            {
                return _lastShelter;
            }
        }

        public DateTime LastShelterExit
        {
            get
            {
                return _lastShelterExit;
            }
        }

        public int EmploymentFrequency
        {
            get
            {
                return _empFreq;
            }
            set
            {
                _empFreq = value;
            }
        }

        public DateTime EmploymentDate
        {
            get
            {
                return _empDate;
            }
            set
            {
                _empDate = value;
            }
        }

        public int MFIPDay
        {
            get
            {
                return _mfipDay;
            }
            set
            {
                _mfipDay = value;
            }
        }

        public DateTime ChildSupportDate
        {
            get
            {
                return _childsupportDate;
            }
            set
            {
                _childsupportDate = value;
            }
        }

        public DateTime OtherSourcesDate
        {
            get
            {
                return _otherincomeDate;
            }
            set
            {
                _otherincomeDate = value;
            }
        }

        public string Message
        {
            get
            {
                return _message;
            }
            set
            {
                _message = value;
            }
        }

        public int Flag
        {
            get
            {
                return _flag;
            }
            set
            {
                _flag = value;
            }
        }

        #endregion

        #region Public Methods

        public void Save(int orgId, string userId)
        {
            SavePerson(orgId, userId);
        }

        public static void Delete(int Id)
        {
            new ResourceCenterPersonData().DeleteResourceCenterPerson(Id);
        }

        public void Delete()
        {
            // delete record
            ResourceCenterPersonData PersonData = new ResourceCenterPersonData();
            PersonData.DeleteResourceCenterPerson(_Id);

            _Id = -1;
        }

        public void BulkChangeAddress(int personId, string userId)
        {
            new ResourceCenterPersonData().BulkChangeAddress(personId, _streetAddress, _city, _postalCode, _state, _county, userId);
        }

        public int CountSimilars(string firstName, string lastName, string street, string zipCode, int excludeID)
        {
            return new ResourceCenterPersonData().CountSimilars(firstName, lastName, street, zipCode, excludeID);
        }

        #endregion

        #region Private Methods

        private void SavePerson(int orgId, string userId)
        {
            _Id = new ResourceCenterPersonData().SaveResourceCenterPerson(
                orgId,
                _personId,
                _numAdults,
                _numChildren,
                _county,
                _helpRequested,
                _notes,
                userId,
                _nickName,
                _firstName,
                _middleName,
                _lastName,
                _suffix,
                _birthday,
                _gender,
                _email,
                _streetAddress,
                _city,
                _state,
                _postalCode,
                _ssn,
                _schoolDistrict,
                _incomeEmployment,
                _incomeUnemployment,
                _incomeMFIP,
                _incomeChildSupport,
                _incomeMA,
                _incomeSSISSDI,
                _incomeOther,
                _cashOnHand,
                _issuesOfNote,
                _lastDateWorked,
                _mstatus,
                _dlicense,
                _ebt,
                _foodSupport,
                _assistanceApplied,
                _foodShelf,
                _foodShelfVisit,
                _casemgr1Name,
                _casemgr1Agency,
                _casemgr1Phone,
                _casemgr2Name,
                _casemgr2Agency,
                _casemgr2Phone,
                _emgassist1Angency,
                _emgassist1Casemgr,
                _emgassist1Phone,
                _emgassist1Date,
                _emgassist1Amount,
                _emgassist1Status,
                _emgassist2Angency,
                _emgassist2Casemgr,
                _emgassist2Phone,
                _emgassist2Date,
                _emgassist2Amount,
                _emgassist2Status,
                _pastShelter,
                _pastShelterDate,
                _pastUnsheltered,
                _pastUnshelteredDate,
                _pastChemical,
                _pastChemicalDate,
                _pastTransitional,
                _pastTransitionalDate,
                _pastDoubled,
                _pastDoubledDate,
                _pastEviction,
                _pastEvictionDate,
                _pastForeclosure,
                _pastForeclosureDate,
                _phoneHome,
                _phoneWork,
                _phoneMobile,
                _phoneOther,
                _casemgr1notes,
                _casemgr2notes,
                _empFreq,
                _empDate,
                _mfipDay,
                _childsupportDate,
                _otherincomeDate,
                _message,
                _flag);
        }

        private void LoadPerson(SqlDataReader reader)
        {
            if (!reader.IsDBNull(reader.GetOrdinal("Last_Shelter")))
                _lastShelter = (DateTime)reader["Last_Shelter"];

            if (!reader.IsDBNull(reader.GetOrdinal("Last_Shelter_Exit")))
                _lastShelterExit = (DateTime)reader["Last_Shelter_Exit"];

            if (!reader.IsDBNull(reader.GetOrdinal("id")))
                _personId = (int)reader["id"];

            if (!reader.IsDBNull(reader.GetOrdinal("date_created")))
                _dateCreated = (DateTime)reader["date_created"];

            if (!reader.IsDBNull(reader.GetOrdinal("date_updated")))
                _dateUpdated = (DateTime)reader["date_updated"];

            _createdBy = reader["created_by"].ToString();

            _updatedBy = reader["updated_by"].ToString();

            //if (!reader.IsDBNull(reader.GetOrdinal("person_id")))
            //    _personId = (int)reader["person_id"];

            if (!reader.IsDBNull(reader.GetOrdinal("num_adults")))
                _numAdults = (int)reader["num_adults"];

            if (!reader.IsDBNull(reader.GetOrdinal("num_children")))
                _numChildren = (int)reader["num_children"];

            _county = reader["county_of_origin"].ToString();

            if (!reader.IsDBNull(reader.GetOrdinal("help_requested")))
                _helpRequested = (int)reader["help_requested"];

            _notes = reader["notes"].ToString();

            _nickName = reader["nick_name"].ToString();

            _firstName = reader["first_name"].ToString();

            _middleName = reader["middle_name"].ToString();

            _lastName = reader["last_name"].ToString();

            _suffix = reader["suffix"].ToString();

            if (!reader.IsDBNull(reader.GetOrdinal("birthday")))
                _birthday = (DateTime)reader["birthday"];

            _gender = reader["gender"].ToString();

            _email = reader["email"].ToString();

            _streetAddress = reader["street_address"].ToString();

            _city = reader["city"].ToString();

            _state = reader["state"].ToString();

            _postalCode = reader["postal_code"].ToString();

            _ssn = reader["ssn"].ToString();

            _schoolDistrict = reader["school_district"].ToString();

            if (!reader.IsDBNull(reader.GetOrdinal("income_employment")))
                _incomeEmployment = (decimal)reader["income_employment"];

            if (!reader.IsDBNull(reader.GetOrdinal("income_unemployment")))
                _incomeUnemployment = (decimal)reader["income_unemployment"];

            if (!reader.IsDBNull(reader.GetOrdinal("income_mfip")))
                _incomeMFIP = (decimal)reader["income_mfip"];

            if (!reader.IsDBNull(reader.GetOrdinal("income_ma")))
                _incomeMA = (decimal)reader["income_ma"];

            if (!reader.IsDBNull(reader.GetOrdinal("income_childsupport")))
                _incomeChildSupport = (decimal)reader["income_childsupport"];

            if (!reader.IsDBNull(reader.GetOrdinal("income_ssissdi")))
                _incomeSSISSDI = (decimal)reader["income_ssissdi"];

            if (!reader.IsDBNull(reader.GetOrdinal("income_other")))
                _incomeOther = (decimal)reader["income_other"];

            if (!reader.IsDBNull(reader.GetOrdinal("cash_on_hand")))
                _cashOnHand = (decimal)reader["cash_on_hand"];

            if (!reader.IsDBNull(reader.GetOrdinal("issues")))
                _issuesOfNote = (int)reader["issues"];

            if (!reader.IsDBNull(reader.GetOrdinal("last_date_worked")))
                _lastDateWorked = (DateTime)reader["last_date_worked"];

            if (!reader.IsDBNull(reader.GetOrdinal("mstatus")))
                _mstatus = (int)reader["mstatus"];

            if (!reader.IsDBNull(reader.GetOrdinal("dlicense")))
                _dlicense = (int)reader["dlicense"];

            if (!reader.IsDBNull(reader.GetOrdinal("ebt")))
                _ebt = (int)reader["ebt"];

            if (!reader.IsDBNull(reader.GetOrdinal("food_support")))
                _foodSupport = (decimal)reader["food_support"];

            if (!reader.IsDBNull(reader.GetOrdinal("applied_assistance")))
                _assistanceApplied = (DateTime)reader["applied_assistance"];

            _foodShelf = reader["food_shelf"].ToString();

            if (!reader.IsDBNull(reader.GetOrdinal("food_shelf_visit")))
                _foodShelfVisit = (DateTime)reader["food_shelf_visit"];

            _casemgr1Name = reader["casemgr_1_name"].ToString();
            _casemgr1Agency = reader["casemgr_1_agency"].ToString();
            _casemgr1Phone = reader["casemgr_1_phone"].ToString();
            _casemgr1notes = reader["casemgr_1_notes"].ToString();

            _casemgr2Name = reader["casemgr_2_name"].ToString();
            _casemgr2Agency = reader["casemgr_2_agency"].ToString();
            _casemgr2Phone = reader["casemgr_2_phone"].ToString();
            _casemgr2notes = reader["casemgr_2_notes"].ToString();

            _emgassist1Angency = reader["emgassist_1_agency"].ToString();
            _emgassist1Casemgr = reader["emgassist_1_casemgr"].ToString();
            _emgassist1Phone = reader["emgassist_1_phone"].ToString();
            if (!reader.IsDBNull(reader.GetOrdinal("emgassist_1_date")))
                _emgassist1Date = (DateTime)reader["emgassist_1_date"];
            if (!reader.IsDBNull(reader.GetOrdinal("emgassist_1_amount")))
                _emgassist1Amount = (decimal)reader["emgassist_1_amount"];
            if (!reader.IsDBNull(reader.GetOrdinal("emgassist_1_status")))
                _emgassist1Status = (int)reader["emgassist_1_status"];

            _emgassist2Angency = reader["emgassist_2_agency"].ToString();
            _emgassist2Casemgr = reader["emgassist_2_casemgr"].ToString();
            _emgassist2Phone = reader["emgassist_2_phone"].ToString();
            if (!reader.IsDBNull(reader.GetOrdinal("emgassist_2_date")))
                _emgassist2Date = (DateTime)reader["emgassist_2_date"];
            if (!reader.IsDBNull(reader.GetOrdinal("emgassist_2_amount")))
                _emgassist2Amount = (decimal)reader["emgassist_2_amount"];
            if (!reader.IsDBNull(reader.GetOrdinal("emgassist_2_status")))
                _emgassist2Status = (int)reader["emgassist_2_status"];

            if (!reader.IsDBNull(reader.GetOrdinal("past_shelter")))
                _pastShelter = (int)reader["past_shelter"];
            if (!reader.IsDBNull(reader.GetOrdinal("past_shelter_date")))
                _pastShelterDate = (DateTime)reader["past_shelter_date"];

            if (!reader.IsDBNull(reader.GetOrdinal("past_unsheltered")))
                _pastUnsheltered = (int)reader["past_unsheltered"];
            if (!reader.IsDBNull(reader.GetOrdinal("past_unsheltered_date")))
                _pastUnshelteredDate = (DateTime)reader["past_unsheltered_date"];

            if (!reader.IsDBNull(reader.GetOrdinal("past_chemical")))
                _pastChemical = (int)reader["past_chemical"];
            if (!reader.IsDBNull(reader.GetOrdinal("past_chemical_date")))
                _pastChemicalDate = (DateTime)reader["past_chemical_date"];

            if (!reader.IsDBNull(reader.GetOrdinal("past_transitional")))
                _pastTransitional = (int)reader["past_transitional"];
            if (!reader.IsDBNull(reader.GetOrdinal("past_transitional_date")))
                _pastTransitionalDate = (DateTime)reader["past_transitional_date"];

            if (!reader.IsDBNull(reader.GetOrdinal("past_doubled")))
                _pastDoubled = (int)reader["past_doubled"];
            if (!reader.IsDBNull(reader.GetOrdinal("past_doubled_date")))
                _pastDoubledDate = (DateTime)reader["past_doubled_date"];

            if (!reader.IsDBNull(reader.GetOrdinal("past_eviction")))
                _pastEviction = (int)reader["past_eviction"];
            if (!reader.IsDBNull(reader.GetOrdinal("past_eviction_date")))
                _pastEvictionDate = (DateTime)reader["past_eviction_date"];

            if (!reader.IsDBNull(reader.GetOrdinal("past_foreclosure")))
                _pastForeclosure = (int)reader["past_foreclosure"];
            if (!reader.IsDBNull(reader.GetOrdinal("past_foreclosure_date")))
                _pastForeclosureDate = (DateTime)reader["past_foreclosure_date"];

            _phoneHome = reader["phone_home"].ToString();
            _phoneWork = reader["phone_work"].ToString();
            _phoneMobile = reader["phone_mobile"].ToString();
            _phoneOther = reader["phone_other"].ToString();

            if (!reader.IsDBNull(reader.GetOrdinal("employment_frequency")))
                _empFreq = (int)reader["employment_frequency"];

            if (!reader.IsDBNull(reader.GetOrdinal("employment_date")))
                _empDate = (DateTime)reader["employment_date"];

            if (!reader.IsDBNull(reader.GetOrdinal("mfip_day")))
                _mfipDay = (int)reader["mfip_day"];

            if (!reader.IsDBNull(reader.GetOrdinal("childsupport_date")))
                _childsupportDate = (DateTime)reader["childsupport_date"];

            if (!reader.IsDBNull(reader.GetOrdinal("othersources_date")))
                _otherincomeDate = (DateTime)reader["othersources_date"];

            _message = reader["message"].ToString();
            if (!reader.IsDBNull(reader.GetOrdinal("flag")))
                _flag = (int)reader["flag"];
        }

        #endregion

        #region Static Methods
        #endregion

        #region Constructors

        public ResourceCenterPerson()
        {
        }

        public ResourceCenterPerson(int personId)
        {
            SqlDataReader reader = new ResourceCenterPersonData().GetResourceCenterPersonByID(personId);
            if (reader.Read())
                LoadPerson(reader);
            reader.Close();
        }

        public ResourceCenterPerson(SqlDataReader reader)
        {
            LoadPerson(reader);
        }
        #endregion
    }
}