using System;
using System.Data.SqlClient;
using Arena.Core;
using Arena.Custom.SALC.ResourceCenter.DataLayer;

namespace Arena.Custom.SALC.ResourceCenter.Entity
{
    [Serializable]
    public class ResourceCenterMeal : ArenaObjectBase
    {
        #region Private Members
        private int _Id = -1;
        private DateTime _date = DateTime.MinValue;
        private int _served = 0;
        private int _meals = 0;
        private int _dist = 0;
        private int _pounds = 0;

        private DateTime _dateCreated = DateTime.MinValue;      //General
        private DateTime _dateUpdated = DateTime.MinValue;      //General
        private string _createdBy = string.Empty;               //General
        private string _updatedBy = string.Empty;               //General

        #endregion

        #region Public Properties

        public int Id
        {
            get
            {
                return _Id;
            }
            //set { _Id = value; }
        }

        public DateTime DateCreated
        {
            get
            {
                return _dateCreated;
            }
            //set { _dateCreated = value; }
        }

        public DateTime DateUpdated
        {
            get
            {
                return _dateUpdated;
            }
            //set { _dateUpdated = value; }
        }

        public string CreatedBy
        {
            get
            {
                return _createdBy;
            }
            //set { _createdBy = value; }
        }

        public string UpdatedBy
        {
            get
            {
                return _updatedBy;
            }
            //set { _updatedBy = value; }
        }

        public DateTime Date
        {
            get
            {
                return _date;
            }
            set
            {
                _date = value;
            }
        }

        public int Served
        {
            get
            {
                return _served;
            }
            set
            {
                _served = value;
            }
        }

        public int Meals
        {
            get
            {
                return _meals;
            }
            set
            {
                _meals = value;
            }
        }

        public int Dist
        {
            get
            {
                return _dist;
            }
            set
            {
                _dist = value;
            }
        }

        public int Pounds
        {
            get
            {
                return _pounds;
            }
            set
            {
                _pounds = value;
            }
        }

        #endregion

        #region Public Methods

        public void Save(string userId)
        {
            SaveMeal(userId);
        }

        public static void Delete(int Id)
        {
            new ResourceCenterMealData().DeleteResourceCenterMeal(Id);
        }

        public void Delete()
        {
            // delete record
            ResourceCenterMealData MealData = new ResourceCenterMealData();
            MealData.DeleteResourceCenterMeal(_Id);

            _Id = -1;
        }

        #endregion

        #region Private Methods

        private void SaveMeal(string userId)
        {
            _Id = new ResourceCenterMealData().SaveResourceCenterMeal(_Id, userId, _date, _served, _meals, _dist, _pounds);
        }

        private void LoadMeal(SqlDataReader reader)
        {
            if (!reader.IsDBNull(reader.GetOrdinal("id")))
                _Id = (int)reader["id"];

            if (!reader.IsDBNull(reader.GetOrdinal("date_created")))
                _dateCreated = (DateTime)reader["date_created"];

            if (!reader.IsDBNull(reader.GetOrdinal("date_updated")))
                _dateUpdated = (DateTime)reader["date_updated"];

            _createdBy = reader["created_by"].ToString();

            _updatedBy = reader["updated_by"].ToString();

            if (!reader.IsDBNull(reader.GetOrdinal("date")))
                _date = (DateTime)reader["date"];

            if (!reader.IsDBNull(reader.GetOrdinal("served")))
                _served = (int)reader["served"];

            if (!reader.IsDBNull(reader.GetOrdinal("meals")))
                _meals = (int)reader["meals"];

            if (!reader.IsDBNull(reader.GetOrdinal("dist")))
                _dist = (int)reader["dist"];

            if (!reader.IsDBNull(reader.GetOrdinal("pounds")))
                _pounds = (int)reader["pounds"];
        }

        #endregion

        #region Static Methods
        #endregion

        #region Constructors

        public ResourceCenterMeal()
        {
        }

        public ResourceCenterMeal(int Id)
        {
            SqlDataReader reader = new ResourceCenterMealData().GetResourceCenterMealByID(Id);
            if (reader.Read())
                LoadMeal(reader);
            reader.Close();
        }

        public ResourceCenterMeal(SqlDataReader reader)
        {
            LoadMeal(reader);
        }
        #endregion
    }
}