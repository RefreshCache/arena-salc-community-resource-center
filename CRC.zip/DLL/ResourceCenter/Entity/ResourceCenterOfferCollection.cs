using System;
using System.Data.SqlClient;
using Arena.Core;
using Arena.Custom.SALC.ResourceCenter.DataLayer;

namespace Arena.Custom.SALC.ResourceCenter.Entity
{
    [Serializable]
    public class ResourceCenterOfferCollection : ArenaCollectionBase
    {
        #region Class Indexers
        public new ResourceCenterOffer this[int index]
        {
            get
            {
                if (this.List.Count > 0)
                {
                    return (ResourceCenterOffer)this.List[index];
                }
                else
                {
                    return null;
                }
            }
            set
            {
                this.List[index] = value;
            }
        }

        #endregion

        #region Constructors

        public ResourceCenterOfferCollection()
        {
        }

        public ResourceCenterOfferCollection(int Id)
        {
            SqlDataReader reader = new ResourceCenterOfferData().GetResourceCenterOfferByID(Id);
            while (reader.Read())
                this.Add(new ResourceCenterOffer(reader));
            reader.Close();
        }

        #endregion

        #region Public Methods

        public void Add(ResourceCenterOffer item)
        {
            this.List.Add(item);
        }

        public void Insert(int index, ResourceCenterOffer item)
        {
            this.List.Insert(index, item);
        }

        #endregion

        #region Static Methods

        public static ResourceCenterOfferCollection LoadAll(int orgId, int personId)
        {
            SqlDataReader reader = new ResourceCenterOfferData().GetAllResourceCenterOffers(orgId, new DateTime(1901, 1, 1), new DateTime(2199, 12, 31), "%", "%", -1, personId, 0, 0);
            ResourceCenterOfferCollection collection = new ResourceCenterOfferCollection();
            while (reader.Read())
            {
                collection.Add(new ResourceCenterOffer(reader));
            }
            reader.Close();
            return collection;
        }

        public static ResourceCenterOfferCollection LoadAll(int orgId, DateTime startDate, DateTime endDate, string firstName, string lastName, int type, int status)
        {
            SqlDataReader reader = new ResourceCenterOfferData().GetAllResourceCenterOffers(orgId, startDate, endDate, firstName, lastName, type, 0, 0, status);
            ResourceCenterOfferCollection collection = new ResourceCenterOfferCollection();
            while (reader.Read())
            {
                collection.Add(new ResourceCenterOffer(reader));
            }
            reader.Close();
            return collection;
        }

        public static ResourceCenterOfferCollection LoadAll(int orgId)
        {
            SqlDataReader reader = new ResourceCenterOfferData().GetAllResourceCenterOffers(orgId, Convert.ToDateTime("1/1/1901"), Convert.ToDateTime("12/31/2199"), "%", "%", 0, 0, 0, 0);
            ResourceCenterOfferCollection collection = new ResourceCenterOfferCollection();
            while (reader.Read())
            {
                collection.Add(new ResourceCenterOffer(reader));
            }
            reader.Close();
            return collection;
        }
        #endregion
    }
}