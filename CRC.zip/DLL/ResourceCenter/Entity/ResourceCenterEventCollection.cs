using System;
using System.Data.SqlClient;
using Arena.Core;
using Arena.Custom.SALC.ResourceCenter.DataLayer;

namespace Arena.Custom.SALC.ResourceCenter.Entity
{
    [Serializable]
    public class ResourceCenterEventCollection : ArenaCollectionBase
    {
        #region Class Indexers
        public new ResourceCenterEvent this[int index]
        {
            get
            {
                if (this.List.Count > 0)
                {
                    return (ResourceCenterEvent)this.List[index];
                }
                else
                {
                    return null;
                }
            }
            set
            {
                this.List[index] = value;
            }
        }

        #endregion

        #region Constructors

        public ResourceCenterEventCollection()
        {
        }

        #endregion

        #region Public Methods

        public void Add(ResourceCenterEvent item)
        {
            this.List.Add(item);
        }

        public void Insert(int index, ResourceCenterEvent item)
        {
            this.List.Insert(index, item);
        }

        #endregion

        #region Static Methods

        public static ResourceCenterEventCollection LoadAll(int orgId, DateTime startDate, DateTime endDate, int personId, int helpId)
        {
            SqlDataReader reader = new ResourceCenterEventData().GetAllResourceCenterEvents(orgId, startDate, endDate, personId, helpId);
            ResourceCenterEventCollection collection = new ResourceCenterEventCollection();
            while (reader.Read())
            {
                collection.Add(new ResourceCenterEvent(reader));
            }
            reader.Close();
            return collection;
        }
        #endregion
    }
}