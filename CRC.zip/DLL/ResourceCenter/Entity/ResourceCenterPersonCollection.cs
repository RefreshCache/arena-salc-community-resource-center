using System;
using System.Data.SqlClient;
using Arena.Core;
using Arena.Custom.SALC.ResourceCenter.DataLayer;

namespace Arena.Custom.SALC.ResourceCenter.Entity
{
    [Serializable]
    public class ResourceCenterPersonCollection : ArenaCollectionBase
    {
        #region Class Indexers
        public new ResourceCenterPerson this[int index]
        {
            get
            {
                if (this.List.Count > 0)
                {
                    return (ResourceCenterPerson)this.List[index];
                }
                else
                {
                    return null;
                }
            }
            set
            {
                this.List[index] = value;
            }
        }

        #endregion

        #region Constructors

        public ResourceCenterPersonCollection()
        {
        }

        public ResourceCenterPersonCollection(int personId)
        {
            SqlDataReader reader = new ResourceCenterPersonData().GetResourceCenterPersonByID(personId);
            while (reader.Read())
                this.Add(new ResourceCenterPerson(reader));
            reader.Close();
        }

        public ResourceCenterPersonCollection(int orgId, int personId)
        {
            SqlDataReader reader = new ResourceCenterPersonData().GetFamily(orgId, personId);
            while (reader.Read())
                this.Add(new ResourceCenterPerson(reader));
            reader.Close();
        }

        #endregion

        #region Public Methods

        public void Add(ResourceCenterPerson item)
        {
            this.List.Add(item);
        }

        public void Insert(int index, ResourceCenterPerson item)
        {
            this.List.Insert(index, item);
        }

        #endregion

        #region Static Methods
        public static ResourceCenterPersonCollection LoadAll(int orgId, bool all)
        {
            SqlDataReader reader = new ResourceCenterPersonData().GetAllResourceCenterPersons(orgId);
            ResourceCenterPersonCollection collection = new ResourceCenterPersonCollection();
            while (reader.Read())
            {
                collection.Add(new ResourceCenterPerson(reader));
            }
            reader.Close();
            return collection;
        }

        public static ResourceCenterPersonCollection LoadAll(int orgId, string firstName, string lastName, string phone)
        {
            SqlDataReader reader = new ResourceCenterPersonData().GetAllResourceCenterPersons(orgId, firstName, lastName, phone, "", "");
            ResourceCenterPersonCollection collection = new ResourceCenterPersonCollection();
            while (reader.Read())
            {
                collection.Add(new ResourceCenterPerson(reader));
            }
            reader.Close();
            return collection;
        }

        public static ResourceCenterPersonCollection LoadAll(int orgId, string firstName, string lastName, string phone, string street, string zipCode)
        {
            SqlDataReader reader = new ResourceCenterPersonData().GetAllResourceCenterPersons(orgId, firstName, lastName, phone, street, zipCode);
            ResourceCenterPersonCollection collection = new ResourceCenterPersonCollection();
            while (reader.Read())
            {
                collection.Add(new ResourceCenterPerson(reader));
            }
            reader.Close();
            return collection;
        }

        public static ResourceCenterPersonCollection LoadAll(int orgId, string firstName, string lastName, string phone, string street, string zipCode, int helpIdExclude)
        {
            SqlDataReader reader = new ResourceCenterPersonData().GetAllResourceCenterPersons(orgId, firstName, lastName, phone, street, zipCode, helpIdExclude);
            ResourceCenterPersonCollection collection = new ResourceCenterPersonCollection();
            while (reader.Read())
            {
                collection.Add(new ResourceCenterPerson(reader));
            }
            reader.Close();
            return collection;
        }

        public static ResourceCenterPersonCollection LoadAll(int orgId, int personId)
        {
            SqlDataReader reader = new ResourceCenterPersonData().GetFamily(orgId, personId);
            ResourceCenterPersonCollection collection = new ResourceCenterPersonCollection();
            while (reader.Read())
            {
                collection.Add(new ResourceCenterPerson(reader));
            }
            reader.Close();
            return collection;
        }

        public static ResourceCenterPersonCollection LoadAll(int helpId)
        {
            SqlDataReader reader = new ResourceCenterPersonData().GetHelpList(helpId);
            ResourceCenterPersonCollection collection = new ResourceCenterPersonCollection();
            while (reader.Read())
            {
                collection.Add(new ResourceCenterPerson(reader));
            }
            reader.Close();
            return collection;
        }
        #endregion
    }
}