using System;
using System.Data.SqlClient;
using Arena.Core;
using Arena.Custom.SALC.ResourceCenter.DataLayer;

namespace Arena.Custom.SALC.ResourceCenter.Entity
{
    [Serializable]
    public class ResourceCenterCallCollection : ArenaCollectionBase
    {
        #region Class Indexers
        public new ResourceCenterCall this[int index]
        {
            get
            {
                if (this.List.Count > 0)
                {
                    return (ResourceCenterCall)this.List[index];
                }
                else
                {
                    return null;
                }
            }
            set
            {
                this.List[index] = value;
            }
        }

        #endregion

        #region Constructors

        public ResourceCenterCallCollection()
        {
        }

        public ResourceCenterCallCollection(int personId)
        {
            SqlDataReader reader = new ResourceCenterCallData().GetAllResourceCenterCalls(personId);
            while (reader.Read())
                this.Add(new ResourceCenterCall(reader));
            reader.Close();
        }

        #endregion

        #region Public Methods

        public void Add(ResourceCenterCall item)
        {
            this.List.Add(item);
        }

        public void Insert(int index, ResourceCenterCall item)
        {
            this.List.Insert(index, item);
        }

        #endregion

        #region Static Methods

        public static ResourceCenterCallCollection LoadAll(int status, int orgId)
        {
            SqlDataReader reader = new ResourceCenterCallData().GetAllResourceCenterCalls(Convert.ToDateTime("1/1/1901"), Convert.ToDateTime("12/31/2199"),
                "%", "%", status, orgId);
            ResourceCenterCallCollection collection = new ResourceCenterCallCollection();
            while (reader.Read())
            {
                collection.Add(new ResourceCenterCall(reader));
            }
            reader.Close();
            return collection;
        }

        public static ResourceCenterCallCollection LoadAll(DateTime startDate, DateTime endDate, string messageFor, string search, int status, int orgId)
        {
            DateTime newEndDate = DateTime.MinValue;
            if (startDate == endDate)
            {
                newEndDate = startDate.AddHours(23.9);
            }
            else
            {
                newEndDate = endDate;
            }
            string newSearch = string.Empty;
            if (search == "")
            {
                newSearch = "%";
            }
            else
            {
                newSearch = search;
            }
            SqlDataReader reader = new ResourceCenterCallData().GetAllResourceCenterCalls(startDate, newEndDate, messageFor, newSearch, status, orgId);
            ResourceCenterCallCollection collection = new ResourceCenterCallCollection();
            while (reader.Read())
            {
                collection.Add(new ResourceCenterCall(reader));
            }
            reader.Close();
            return collection;
        }

        public static ResourceCenterCallCollection LoadAll(DateTime startDate, DateTime endDate, string messageFor, int request, string search, int status, int orgId)
        {
            DateTime newEndDate = DateTime.MinValue;
            if (startDate == endDate)
            {
                newEndDate = startDate.AddHours(23.9);
            }
            else
            {
                newEndDate = endDate;
            }
            string newSearch = string.Empty;
            if (search == "")
            {
                newSearch = "%";
            }
            else
            {
                newSearch = search;
            }
            SqlDataReader reader = new ResourceCenterCallData().GetAllResourceCenterCalls(startDate, newEndDate, messageFor, request, newSearch, status, orgId);
            ResourceCenterCallCollection collection = new ResourceCenterCallCollection();
            while (reader.Read())
            {
                collection.Add(new ResourceCenterCall(reader));
            }
            reader.Close();
            return collection;
        }
        #endregion
    }
}