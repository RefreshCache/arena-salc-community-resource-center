using System;
using System.Data.SqlClient;
using Arena.Core;
using Arena.Custom.SALC.ResourceCenter.DataLayer;

namespace Arena.Custom.SALC.ResourceCenter.Entity
{
    [Serializable]
    public class ResourceCenterAddress : ArenaObjectBase
    {
        #region Private Members
        private int piId = -1;                                   //General

        #endregion

        #region Public Properties

        public int Id
        {
            get
            {
                return piId;
            }
            //set { _Id = value; }
        }

        #endregion

        #region Public Methods

        public void Save()
        {
            SaveAddress();
        }

        public static void Delete(int Id)
        {
            new ResourceCenterAddressData().DeleteResourceCenterAddress(Id);
        }

        public void Delete()
        {
            // delete record
            ResourceCenterAddressData AddressData = new ResourceCenterAddressData();
            AddressData.DeleteResourceCenterAddress(piId);

            piId = -1;
        }

        #endregion

        #region Private Methods

        private void SaveAddress()
        {
            piId = new ResourceCenterAddressData().SaveResourceCenterAddress(piId);
        }

        private void LoadAddress(SqlDataReader reader)
        {
            if (!reader.IsDBNull(reader.GetOrdinal("id")))
                piId = (int)reader["id"];
        }

        #endregion

        #region Static Methods
        /*public static ResourceCenterPerson GetFirstByPersonId(int personId)
        {
        ResourceCenterPerson person = new ResourceCenterPerson();
        SqlDataReader reader = new ResouceCenterPersonData().GetFirstResourceCenterPersonByPersonId(personId);
        if (reader.Read())
        {
        person.LoadPerson(reader);
        }
        reader.Close();
        return person;
        }

        public static ResourceCenterPerson GetLastByPersonId(int personId)
        {
        ResourceCenterPerson foodbag = new ResourceCenterPerson();
        SqlDataReader reader = new ResouceCenterPersonData().GetLastResourceCenterPersonByPersonId(personId);
        if ( reader.Read() )
        {
        foodbag.LoadPerson(reader);
        }				
        reader.Close();
        return foodbag;
        }*/
        #endregion

        #region Constructors

        public ResourceCenterAddress()
        {
        }

        public ResourceCenterAddress(int Id)
        {
            SqlDataReader reader = new ResourceCenterHelpData().GetResourceCenterHelpByID(Id);
            if (reader.Read())
                LoadAddress(reader);
            reader.Close();
        }

        public ResourceCenterAddress(SqlDataReader reader)
        {
            LoadAddress(reader);
        }
        #endregion
    }
}