using System;
using System.Data.SqlClient;
using Arena.Core;
using Arena.Custom.SALC.ResourceCenter.DataLayer;

namespace Arena.Custom.SALC.ResourceCenter.Entity
{
    [Serializable]
    public class ResourceCenterMealCollection : ArenaCollectionBase
    {
        #region Class Indexers
        public new ResourceCenterMeal this[int index]
        {
            get
            {
                if (this.List.Count > 0)
                {
                    return (ResourceCenterMeal)this.List[index];
                }
                else
                {
                    return null;
                }
            }
            set
            {
                this.List[index] = value;
            }
        }

        #endregion

        #region Constructors

        public ResourceCenterMealCollection()
        {
        }

        public ResourceCenterMealCollection(int mealId)
        {
            SqlDataReader reader = new ResourceCenterMealData().GetResourceCenterMealByID(mealId);
            while (reader.Read())
                this.Add(new ResourceCenterMeal(reader));
            reader.Close();
        }

        #endregion

        #region Public Methods

        public void Add(ResourceCenterMeal item)
        {
            this.List.Add(item);
        }

        public void Insert(int index, ResourceCenterMeal item)
        {
            this.List.Insert(index, item);
        }

        #endregion

        #region Static Methods

        public static ResourceCenterMealCollection LoadAll(int orgId)
        {
            SqlDataReader reader = new ResourceCenterMealData().GetAllResourceCenterMeals(orgId);
            ResourceCenterMealCollection collection = new ResourceCenterMealCollection();
            while (reader.Read())
            {
                collection.Add(new ResourceCenterMeal(reader));
            }
            reader.Close();
            return collection;
        }

        public static ResourceCenterMealCollection LoadAll(DateTime startDate, DateTime endDate, int orgId)
        {
            SqlDataReader reader = new ResourceCenterMealData().GetAllResourceCenterMeals(startDate, endDate, orgId);
            ResourceCenterMealCollection collection = new ResourceCenterMealCollection();
            while (reader.Read())
            {
                collection.Add(new ResourceCenterMeal(reader));
            }
            reader.Close();
            return collection;
        }
        #endregion
    }
}