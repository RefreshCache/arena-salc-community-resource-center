using System;
using System.Data.SqlClient;
using Arena.Core;
using Arena.Custom.SALC.ResourceCenter.DataLayer;

namespace Arena.Custom.SALC.ResourceCenter.Entity
{
    [Serializable]
    public class Goal : ArenaObjectBase
    {
        #region Private Members
        private int _id = -1;
        private int _helpId = -1;
        private int _orgId = 1;
        private string _name = string.Empty;
        private string _description = string.Empty;
        private bool _isClosed = false;
        private int _type = 0;
        private bool _userClosable = false;
        private DateTime _closeDate = new DateTime(1901, 1, 1);
        private bool initClosed = false;

        private DateTime _dateCreated = DateTime.MinValue;      //General
        private DateTime _dateUpdated = DateTime.MinValue;      //General
        private string _createdBy = string.Empty;               //General
        private string _updatedBy = string.Empty;               //General

        #endregion

        #region Public Properties

        public DateTime CloseDate
        {
            get
            {
                return this._closeDate;
            }
            set
            {
                this._closeDate = value;
            }
        }

        public bool UserClosable
        {
            get
            {
                return this._userClosable;
            }
            set
            {
                this._userClosable = value;
            }
        }

        public int Type
        {
            get
            {
                return this._type;
            }
            set
            {
                this._type = value;
            }
        }

        public string Name
        {
            get
            {
                return this._name;
            }
            set
            {
                this._name = value;
            }
        }

        public string Description
        {
            get
            {
                return this._description;
            }
            set
            {
                this._description = value;
            }
        }

        public bool IsClosed
        {
            get
            {
                return this._isClosed;
            }
            set
            {
                this._isClosed = value;
            }
        }

        public int Id
        {
            get
            {
                return _id;
            }
            //set { _Id = value; }
        }

        public DateTime DateCreated
        {
            get
            {
                return _dateCreated;
            }
            //set { _dateCreated = value; }
        }

        public DateTime DateUpdated
        {
            get
            {
                return _dateUpdated;
            }
            //set { _dateUpdated = value; }
        }

        public string CreatedBy
        {
            get
            {
                return _createdBy;
            }
            //set { _createdBy = value; }
        }

        public string UpdatedBy
        {
            get
            {
                return _updatedBy;
            }
            //set { _updatedBy = value; }
        }

        public int HelpId
        {
            get
            {
                return _helpId;
            }
            set
            {
                _helpId = value;
            }
        }

        #endregion

        #region Public Methods

        public void Save(string userId)
        {
            SaveGoal(userId);
        }

        public static void Delete(int id)
        {
            new GoalData().DeleteGoal(id);
        }

        public void Delete()
        {
            // delete record
            GoalData goalData = new GoalData();
            goalData.DeleteGoal(_id);

            _id = -1;
        }

        #endregion

        #region Private Methods

        private void SaveGoal(string userId)
        {
            if (!initClosed && _isClosed) _closeDate = DateTime.Now;
            _id = new GoalData().SaveGoal(_id, userId, _helpId, _name, _description, _isClosed, _type, _userClosable, _closeDate, _orgId);
            initClosed = true;
        }

        private void LoadGoal(SqlDataReader reader)
        {
            if (!reader.IsDBNull(reader.GetOrdinal("goal_id")))
                _id = (int)reader["goal_id"];

            if (!reader.IsDBNull(reader.GetOrdinal("create_date")))
                _dateCreated = (DateTime)reader["create_date"];

            if (!reader.IsDBNull(reader.GetOrdinal("update_date")))
                _dateUpdated = (DateTime)reader["update_date"];

            _createdBy = reader["created_by"].ToString();

            _updatedBy = reader["updated_by"].ToString();

            if (!reader.IsDBNull(reader.GetOrdinal("help_id")))
                _helpId = (int)reader["help_id"];

            if (!reader.IsDBNull(reader.GetOrdinal("organization_id")))
                _orgId = (int)reader["organization_id"];

            _name = reader["name"].ToString();
            _description = reader["description"].ToString();

            if (!reader.IsDBNull(reader.GetOrdinal("is_closed")))
                _isClosed = (bool)reader["is_closed"];

            if (!reader.IsDBNull(reader.GetOrdinal("user_closable")))
                _userClosable = (bool)reader["user_closable"];

            if (!reader.IsDBNull(reader.GetOrdinal("type")))
                _type = (int)reader["type"];

            if (!reader.IsDBNull(reader.GetOrdinal("close_date")))
                _closeDate = (DateTime)reader["close_date"];

            initClosed = _isClosed;

        }

        #endregion

        #region Static Methods
        #endregion

        #region Constructors

        public Goal()
        {
        }

        public Goal(int id)
        {
            SqlDataReader reader = new GoalData().GetGoalByID(id);
            if (reader.Read())
                LoadGoal(reader);
            reader.Close();
        }

        public Goal(SqlDataReader reader)
        {
            LoadGoal(reader);
        }
        #endregion
    }
}