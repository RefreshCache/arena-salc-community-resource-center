using System;
using System.Data.SqlClient;
using Arena.Core;

namespace Arena.Custom.SALC.ResourceCenter.Entity
{
    [Serializable]
    public class ResourceCenterEvent : ArenaObjectBase
    {
        #region Private Members
        private int ipersonId = -1;
        private DateTime dtDate = DateTime.MinValue;
        private string sName = string.Empty;
        private decimal dAmount = 0;
        private string sSource = string.Empty;

        #endregion

        #region Public Properties

        public int PersonID
        {
            get
            {
                return ipersonId;
            }
        }

        public DateTime Date
        {
            get
            {
                return dtDate;
            }
        }

        public string Name
        {
            get
            {
                return sName;
            }
        }

        public decimal Amount
        {
            get
            {
                return dAmount;
            }
        }

        public string Source
        {
            get
            {
                return sSource;
            }
        }

        #endregion

        #region Public Methods

        #endregion

        #region Private Methods

        private void LoadEvent(SqlDataReader reader)
        {
            ipersonId = (int)reader["person_id"];
            dtDate = (DateTime)reader["Date"];
            sName = reader["Name"].ToString();
            dAmount = (decimal)reader["Amount"];
            sSource = reader["Type"].ToString();
        }

        #endregion

        #region Static Methods
        #endregion

        #region Constructors

        public ResourceCenterEvent()
        {
        }

        public ResourceCenterEvent(int personId, DateTime date, string name, decimal amount, string source)
        {
            ipersonId = personId;
            dtDate = date;
            sName = name;
            dAmount = amount;
            sSource = source;
        }

        public ResourceCenterEvent(SqlDataReader reader)
        {
            LoadEvent(reader);
        }
        #endregion
    }
}