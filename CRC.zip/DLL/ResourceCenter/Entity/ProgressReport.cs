using System;
using System.Data.SqlClient;
using Arena.Core;
using Arena.Custom.SALC.ResourceCenter.DataLayer;

namespace Arena.Custom.SALC.ResourceCenter.Entity
{
    [Serializable]
    public class ProgressReport : ArenaObjectBase
    {
        #region Private Members
        private int _id = -1;
        private int _goalId = -1;
        private int _orgId = 1;
        private string _description = string.Empty;
        private int _type = 0;

        private DateTime _dateCreated = DateTime.MinValue;      //General
        private DateTime _dateUpdated = DateTime.MinValue;      //General
        private string _createdBy = string.Empty;               //General
        private string _updatedBy = string.Empty;               //General

        #endregion

        #region Public Properties

        public int GoalId
        {
            get
            {
                return this._goalId;
            }
            set
            {
                this._goalId = value;
            }
        }

        public int Type
        {
            get
            {
                return this._type;
            }
            set
            {
                this._type = value;
            }
        }

        public string Description
        {
            get
            {
                return this._description;
            }
            set
            {
                this._description = value;
            }
        }

        public int Id
        {
            get
            {
                return _id;
            }
            //set { _Id = value; }
        }

        public DateTime DateCreated
        {
            get
            {
                return _dateCreated;
            }
            //set { _dateCreated = value; }
        }

        public DateTime DateUpdated
        {
            get
            {
                return _dateUpdated;
            }
            //set { _dateUpdated = value; }
        }

        public string CreatedBy
        {
            get
            {
                return _createdBy;
            }
            //set { _createdBy = value; }
        }

        public string UpdatedBy
        {
            get
            {
                return _updatedBy;
            }
            //set { _updatedBy = value; }
        }

        public int ProgressReportId
        {
            get
            {
                return _goalId;
            }
            set
            {
                _goalId = value;
            }
        }

        #endregion

        #region Public Methods

        public void Save(string userId)
        {
            SaveProgressReport(userId);
        }

        public static void Delete(int id)
        {
            new ProgressReportData().DeleteProgressReport(id);
        }

        public void Delete()
        {
            // delete record
            ProgressReportData goalData = new ProgressReportData();
            goalData.DeleteProgressReport(_id);

            _id = -1;
        }

        #endregion

        #region Private Methods

        private void SaveProgressReport(string userId)
        {
            _id = new ProgressReportData().SaveProgressReport(_id, userId, _goalId, _description, _type, _orgId);
        }

        private void LoadProgressReport(SqlDataReader reader)
        {
            if (!reader.IsDBNull(reader.GetOrdinal("progrprt_id")))
                _id = (int)reader["progrprt_id"];

            if (!reader.IsDBNull(reader.GetOrdinal("create_date")))
                _dateCreated = (DateTime)reader["create_date"];

            if (!reader.IsDBNull(reader.GetOrdinal("update_date")))
                _dateUpdated = (DateTime)reader["update_date"];

            _createdBy = reader["created_by"].ToString();

            _updatedBy = reader["updated_by"].ToString();

            if (!reader.IsDBNull(reader.GetOrdinal("goal_id")))
                _goalId = (int)reader["goal_id"];

            if (!reader.IsDBNull(reader.GetOrdinal("organization_id")))
                _orgId = (int)reader["organization_id"];

            if (!reader.IsDBNull(reader.GetOrdinal("type")))
                _type = (int)reader["type"];

            _description = reader["description"].ToString();

        }

        #endregion

        #region Static Methods
        #endregion

        #region Constructors

        public ProgressReport()
        {
        }

        public ProgressReport(int id)
        {
            SqlDataReader reader = new ProgressReportData().GetProgressReportByID(id);
            if (reader.Read())
                LoadProgressReport(reader);
            reader.Close();
        }

        public ProgressReport(SqlDataReader reader)
        {
            LoadProgressReport(reader);
        }
        #endregion
    }
}