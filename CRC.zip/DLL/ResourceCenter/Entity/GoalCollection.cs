using System;
using System.Data.SqlClient;
using Arena.Core;
using Arena.Custom.SALC.ResourceCenter.DataLayer;

namespace Arena.Custom.SALC.ResourceCenter.Entity
{
    [Serializable]
    public class GoalCollection : ArenaCollectionBase
    {
        #region Class Indexers
        public new Goal this[int index]
        {
            get
            {
                if (this.List.Count > 0)
                {
                    return (Goal)this.List[index];
                }
                else
                {
                    return null;
                }
            }
            set
            {
                this.List[index] = value;
            }
        }

        #endregion

        #region Constructors

        public GoalCollection()
        {
        }

        public GoalCollection(int GoalId)
        {
            SqlDataReader reader = new GoalData().GetGoalByID(GoalId);
            while (reader.Read())
                this.Add(new Goal(reader));
            reader.Close();
        }

        #endregion

        #region Public Methods

        public void Add(Goal item)
        {
            this.List.Add(item);
        }

        public void Insert(int index, Goal item)
        {
            this.List.Insert(index, item);
        }

        #endregion

        #region Static Methods

        public static GoalCollection LoadAll(int orgId, DateTime startDate, DateTime endDate, int helpId, int clientId)
        {
            SqlDataReader reader = new GoalData().GetAllGoals(startDate, endDate, helpId, orgId);
            GoalCollection collection = new GoalCollection();
            while (reader.Read())
            {
                collection.Add(new Goal(reader));
            }
            reader.Close();
            return collection;
        }

        public static GoalCollection LoadAll(int helpId, int orgId)
        {
            SqlDataReader reader = new GoalData().GetAllGoals(new DateTime(1901, 1, 1), new DateTime(2099, 12, 31), helpId, orgId);
            GoalCollection collection = new GoalCollection();
            while (reader.Read())
            {
                collection.Add(new Goal(reader));
            }
            reader.Close();
            return collection;
        }
        #endregion
    }
}