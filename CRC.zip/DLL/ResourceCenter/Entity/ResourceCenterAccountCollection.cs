using System;
using System.Data.SqlClient;
using Arena.Core;
using Arena.Custom.SALC.ResourceCenter.DataLayer;

namespace Arena.Custom.SALC.ResourceCenter.Entity
{
    [Serializable]
    public class ResourceCenterAccountCollection : ArenaCollectionBase
    {
        #region Class Indexers
        public new ResourceCenterAccount this[int index]
        {
            get
            {
                if (this.List.Count > 0)
                {
                    return (ResourceCenterAccount)this.List[index];
                }
                else
                {
                    return null;
                }
            }
            set
            {
                this.List[index] = value;
            }
        }

        #endregion

        #region Constructors

        public ResourceCenterAccountCollection()
        {
        }

        public ResourceCenterAccountCollection(int id)
        {
            SqlDataReader reader = new ResourceCenterAccountData().GetResourceCenterAccountByID(id);
            while (reader.Read())
                this.Add(new ResourceCenterAccount(reader));
            reader.Close();
        }

        #endregion

        #region Public Methods

        public void Add(ResourceCenterAccount item)
        {
            this.List.Add(item);
        }

        public void Insert(int index, ResourceCenterAccount item)
        {
            this.List.Insert(index, item);
        }

        #endregion

        #region Static Methods

        public static ResourceCenterAccountCollection LoadAll(int helpId)
        {
            SqlDataReader reader = new ResourceCenterAccountData().GetAllResourceCenterAccounts(helpId);
            ResourceCenterAccountCollection collection = new ResourceCenterAccountCollection();
            while (reader.Read())
            {
                collection.Add(new ResourceCenterAccount(reader));
            }
            reader.Close();
            return collection;
        }
        #endregion
    }
}