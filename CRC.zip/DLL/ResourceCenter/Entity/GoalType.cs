using System;
using System.Data.SqlClient;
using Arena.Core;
using Arena.Custom.SALC.ResourceCenter.DataLayer;

namespace Arena.Custom.SALC.ResourceCenter.Entity
{
    [Serializable]
    public class GoalType : ArenaObjectBase
    {
        #region Private Members
        private int _Id = -1;
        private string _name = string.Empty;
        private bool _enabled = false;
        private int _organizationId = 1;

        #endregion

        #region Public Properties

        public int Id
        {
            get
            {
                return _Id;
            }
            //set { _Id = value; }
        }

        public string Name
        {
            get
            {
                return _name;
            }
            set
            {
                _name = value;
            }
        }

        public int OrganizationId
        {
            get
            {
                return _organizationId;
            }
            set
            {
                _organizationId = value;
            }
        }

        public bool Enabled
        {
            get
            {
                return _enabled;
            }
            set
            {
                _enabled = value;
            }
        }

        #endregion

        #region Public Methods

        public void Save()
        {
            SaveGoalType();
        }

        public static void Delete(int id)
        {
            new GoalTypeData().DeleteResourceCenterGoalType(id);
        }

        public void Delete()
        {
            // delete record
            GoalTypeData goalTypeData = new GoalTypeData();
            goalTypeData.DeleteResourceCenterGoalType(_Id);

            _Id = -1;
        }

        #endregion

        #region Private Methods

        private void SaveGoalType()
        {
            _Id = new GoalTypeData().SaveResourceCenterGoalType(_organizationId, _Id, _name, _enabled);
        }

        private void LoadGoalType(SqlDataReader reader)
        {
            if (!reader.IsDBNull(reader.GetOrdinal("goaltype_id")))
                _Id = (int)reader["goaltype_id"];

            _name = reader["name"].ToString();

            if (!reader.IsDBNull(reader.GetOrdinal("enabled")))
                _enabled = (bool)reader["enabled"];

            _organizationId = (int)reader["organization_id"];
        }

        #endregion

        #region Static Methods
        #endregion

        #region Constructors

        public GoalType()
        {
        }

        public GoalType(int orgId, int id, string name, bool enabled)
        {
            _Id = id;
            _organizationId = orgId;
            _name = name;
            _enabled = enabled;
        }

        public GoalType(int id)
        {
            SqlDataReader reader = new GoalTypeData().GetResourceCenterGoalTypeByID(id);
            if (reader.Read())
                LoadGoalType(reader);
            reader.Close();
        }

        public GoalType(SqlDataReader reader)
        {
            LoadGoalType(reader);
        }
        #endregion
    }
}