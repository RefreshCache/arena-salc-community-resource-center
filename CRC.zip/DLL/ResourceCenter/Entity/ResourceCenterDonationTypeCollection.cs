using System;
using System.Data.SqlClient;
using Arena.Core;
using Arena.Custom.SALC.ResourceCenter.DataLayer;

namespace Arena.Custom.SALC.ResourceCenter.Entity
{
    [Serializable]
    public class ResourceCenterDonationTypeCollection : ArenaCollectionBase
    {
        #region Class Indexers
        public new ResourceCenterHelpSubType this[int index]
        {
            get
            {
                if (this.List.Count > 0)
                {
                    return (ResourceCenterHelpSubType)this.List[index];
                }
                else
                {
                    return null;
                }
            }
            set
            {
                this.List[index] = value;
            }
        }

        #endregion

        #region Constructors

        public ResourceCenterDonationTypeCollection()
        {
        }

        public ResourceCenterDonationTypeCollection(int orgId)
        {
            this.Add(new ResourceCenterHelpSubType(orgId, 0, "Monitary", "", false, true));
            SqlDataReader reader = new ResourceCenterHelpSubTypeData().GetAllResourceCenterHelpSubTypes(orgId);
            while (reader.Read())
                this.Add(new ResourceCenterHelpSubType(reader));
            reader.Close();
        }

        #endregion

        #region Public Methods

        public void Add(ResourceCenterHelpSubType item)
        {
            this.List.Add(item);
        }

        public void Insert(int index, ResourceCenterHelpSubType item)
        {
            this.List.Insert(index, item);
        }

        #endregion

        #region Static Methods

        public static ResourceCenterDonationTypeCollection LoadAll(int orgId)
        {
            SqlDataReader reader = new ResourceCenterHelpSubTypeData().GetAllResourceCenterHelpSubTypes(orgId);
            ResourceCenterDonationTypeCollection collection = new ResourceCenterDonationTypeCollection();
            collection.Add(new ResourceCenterHelpSubType(orgId, 0, "Monitary", "", false, true));
            while (reader.Read())
            {
                collection.Add(new ResourceCenterHelpSubType(reader));
            }
            reader.Close();
            return collection;
        }

        public static ResourceCenterDonationTypeCollection LoadAllWithBlank(int orgId)
        {
            SqlDataReader reader = new ResourceCenterHelpSubTypeData().GetAllResourceCenterHelpSubTypes(orgId);
            ResourceCenterDonationTypeCollection collection = new ResourceCenterDonationTypeCollection();
            collection.Add(new ResourceCenterHelpSubType(orgId, -1, "", "", false, false));
            collection.Add(new ResourceCenterHelpSubType(orgId, 0, "Monitary", "", false, true));
            while (reader.Read())
            {
                collection.Add(new ResourceCenterHelpSubType(reader));
            }
            reader.Close();
            return collection;
        }
        #endregion
    }
}