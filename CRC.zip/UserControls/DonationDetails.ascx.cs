﻿namespace Arena.UserControls.Custom.SALC.ResourceCenter
{
    using System;
    using System.Linq;
    using System.Text;
    using Arena.Core;
    using Arena.Portal;
    using Arena.Security;
    using Arena.Custom.SALC.ResourceCenter.Entity;

    public partial class Donation : PortalControl
    {
        [PageSetting("Donation Search Page", "The Donation Search page", true)]
        public string DonationSearchPageSetting
        {
            get
            {
                return Setting("DonationSearchPage", "", true);
            }
        }

        private int iDonationId = 0;
        private ResourceCenterDonation rcDonation = new ResourceCenterDonation();

        protected void Page_Load(object sender, EventArgs e)
        {
            RegisterScripts();
            if (Request.QueryString["donationid"] != null)
            {
                iDonationId = Convert.ToInt32(Request.QueryString["donationid"]);
            }

            if (iDonationId > 0)
            {
                rcDonation = new ResourceCenterDonation(iDonationId);
            }

            if (!IsPostBack)
            {
                if (CanEdit)
                {
                    lbEditLink.Visible = true;
                }
                else
                {
                    lbEditLink.Visible = false;
                }

                ddlEType.DataSource = ResourceCenterDonationTypeCollection.LoadAll(CurrentOrganization.OrganizationID).DataTable();
                ddlEType.DataTextField = "Name";
                ddlEType.DataValueField = "Id";
                ddlEType.DataBind();
                ddlEType.SelectedValue = "0";

                if (iDonationId > 0)
                {
                    BindViewData(rcDonation);
                }
                else
                {
                    rcDonation.Date = DateTime.Today;
                    BindEditData(rcDonation);
                    lbEditLink_Click(null, null);
                }
            }
        }

        protected void BindViewData(ResourceCenterDonation data)
        {
            lblVAmount.Text = String.Format("{0:0.00}", data.Amount);
            lblVDate.Text = data.Date.ToShortDateString();
            lblVDescription.Text = data.Description;

            if (data.PersonId > 0)
            {
                lblVName.Text = new Person(Convert.ToInt32(data.PersonId)).FullName;
            }
            else
            {
                lblVName.Text = "Anonymous";
            }

            lblVNotes.Text = data.Notes;
            lblVSize.Text = data.Size.ToString();

            foreach (ResourceCenterHelpSubType t in ResourceCenterDonationTypeCollection.LoadAll(CurrentOrganization.OrganizationID))
            {
                if (t.Id == data.Type)
                    lblVType.Text = t.Name;
            }
        }

        protected void BindEditData(ResourceCenterDonation data)
        {
            if (data.PersonId > 0)
            {
                Person p = new Person(Convert.ToInt32(data.PersonId));
                lbFindPerson.Text = p.FullName;
                PersonIdTextBox.Text = p.PersonID.ToString();
                ihPersonList.Value = data.PersonId.ToString();
            }
            else
            {
                lbFindPerson.Text = "Anonymous";
                PersonIdTextBox.Text = "";
                ihPersonList.Value = "";
            }

            dtbEDate.Text = data.Date.ToShortDateString();
            ddlEType.SelectedValue = data.Type.ToString();
            tbEDescription.Text = data.Description;
            tbGeneralInfoESize.Text = data.Size.ToString();
            tbGeneralInfoEAmount.Text = String.Format("{0:0.00}", data.Amount);
            tbENotes.Text = data.Notes;

            ddlEType_SelectedIndexChanged(null, null);
        }

        protected void SaveEditData(ResourceCenterDonation data)
        {
            if (PersonIdTextBox.Text != "")
            {
                data.PersonId = Convert.ToInt32(PersonIdTextBox.Text);
            }
            else
            {
                data.PersonId = 0;
            }
            data.Date = dtbEDate.SelectedDate;
            data.Type = Convert.ToInt32(ddlEType.SelectedValue);
            data.Description = tbEDescription.Text;
            data.Size = Convert.ToInt32(tbGeneralInfoESize.Text);
            data.Amount = Convert.ToDecimal(tbGeneralInfoEAmount.Text);
            data.Notes = tbENotes.Text;
            data.Save(CurrentOrganization.OrganizationID, CurrentUser.Identity.Name);
        }

        protected void btnRefresh_Click(object sender, EventArgs e)
        {
            // The search can possibly return multiple ids based on the module setting.
            if (ihPersonList.Value != "")
            {
                string[] personIds = ihPersonList.Value.Split(',');
                foreach (string id in personIds)
                {
                    Person p = new Person(Convert.ToInt32(id));
                    lbFindPerson.Text = p.FullName;
                    PersonIdTextBox.Text = p.PersonID.ToString();
                }
                ihPersonList.Value = "";
            }
        }

        private void RegisterScripts()
        {
            StringBuilder sbScript = new StringBuilder();
            sbScript.Append("\n\n<script language=\"javascript\">\n");
            sbScript.Append("\tfunction openSearchWindow()\n");
            sbScript.Append("\t{\n");
            sbScript.Append("\t\tvar tPos = window.screenTop + 100;\n");
            sbScript.Append("\t\tvar lPos = window.screenLeft + 100;\n");
            sbScript.AppendFormat("\t\tdocument.frmMain.ihPersonListID.value = '{0}';\n", ihPersonList.ClientID);
            sbScript.AppendFormat("\t\tdocument.frmMain.ihRefreshButtonID.value = '{0}';\n", btnRefresh.ClientID);
            sbScript.Append("\t\tvar searchWindow = window.open('Default.aspx?page=16','Search','height=400,width=600,resizable=yes,scrollbars=yes,toolbar=no,location=no,directories=no,status=no,menubar=no,top=' + tPos + ',left=' + lPos);\n");
            sbScript.Append("\t\tsearchWindow.focus();\n");
            sbScript.Append("\t}\n");
            sbScript.Append("</script>\n\n");
            Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "OpenSearchWindow", sbScript.ToString());
        }

        protected void lbEditLink_Click(object sender, EventArgs e)
        {
            pEdit.Visible = true;
            pView.Visible = false;
            BindEditData(rcDonation);
        }

        protected void lbSave_Click(object sender, EventArgs e)
        {
            if (Page.IsValid)
            {
                SaveEditData(rcDonation);
                BindViewData(rcDonation);
                pEdit.Visible = false;
                pView.Visible = true;
            }
        }

        protected void lbCancel_Click(object sender, EventArgs e)
        {
            if (rcDonation.Id > 0)
            {
                pEdit.Visible = false;
                pView.Visible = true;
            }
            else
            {
                Response.Redirect("default.aspx?page=" + DonationSearchPageSetting);
            }
        }

        protected void lbDonationList_Click(object sender, EventArgs e)
        {
            Response.Redirect("default.aspx?page=" + DonationSearchPageSetting);
        }

        protected void lbNewDonation_Click(object sender, EventArgs e)
        {
            Response.Redirect("default.aspx?page=" + Request.QueryString["page"]);
        }

        protected void ddlEType_SelectedIndexChanged(object sender, EventArgs e)
        {
            ResourceCenterHelpSubType f = null;
            foreach (ResourceCenterHelpSubType t in ResourceCenterDonationTypeCollection.LoadAll(CurrentOrganization.OrganizationID))
            {
                if (t.Id.ToString() == ddlEType.SelectedValue)
                    f = t;
            }

            if (f != null)
            {
                if (f.IsAmount)
                {
                    lblValue.Text = f.Text;
                    tbGeneralInfoEAmount.Enabled = true;
                }
                else
                {
                    lblValue.Text = "";
                    tbGeneralInfoEAmount.Enabled = false;
                }

                if (f.IsQuantity)
                {
                    lblQuantity.Text = f.Text;
                    tbGeneralInfoESize.Enabled = true;
                }
                else
                {
                    lblQuantity.Text = "";
                    tbGeneralInfoESize.Enabled = false;
                }
            }
            else
            {
                lblQuantity.Text = "";
                tbGeneralInfoESize.Enabled = true;
                lblValue.Text = "";
                tbGeneralInfoEAmount.Enabled = true;
            }

            upPartial.Update();
        }

        protected bool CanEdit
        {
            get
            {
                return CurrentModule.Permissions.Allowed(OperationType.Edit, CurrentUser);
            }
        }
    }
}