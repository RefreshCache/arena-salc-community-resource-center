﻿namespace Arena.UserControls.Custom.SALC.ResourceCenter
{
    using System;
    using System.Linq;
    using System.Text;
    using Arena.Core;
    using Arena.Portal;
    using Arena.Security;
    using Arena.Custom.SALC.ResourceCenter.Entity;

    public partial class Offer : PortalControl
    {
        [PageSetting("Offer Search Page", "The Offer Search page", true)]
        public string OfferSearchPageSetting
        {
            get
            {
                return Setting("OfferSearchPage", "", true);
            }
        }

        [PageSetting("Call Details Page", "The Call Details page", true)]
        public string CallDetailsPageSetting { get { return Setting("CallDetailsPage", "", true); } }

        [PageSetting("Client Details Page", "The Client Details page", true)]
        public string ClientDetailsPageSetting { get { return Setting("ClientDetailsPage", "", true); } }

        [PageSetting("Client Search Popup Page", "The Client Search Popup page", true)]
        public string ClientSearchPopupPageSetting { get { return Setting("ClientSearchPopupPage", "", true); } }

        [PageSetting("Member Details Page", "The Member Details page", true)]
        public string MemberDetailsPageSetting { get { return Setting("MemberDetailsPage", "", true); } }

        private int iOfferId = 0;
        private ResourceCenterOffer rcOffer = new ResourceCenterOffer();

        protected void Page_Load(object sender, EventArgs e)
        {
            RegisterScripts();
            if (Request.QueryString["offerid"] != null)
            {
                iOfferId = Convert.ToInt32(Request.QueryString["offerid"]);
            }

            if (iOfferId > 0)
            {
                rcOffer = new ResourceCenterOffer(iOfferId);
            }

            if (!IsPostBack)
            {
                if (CanEdit)
                {
                    lbEditLink.Visible = true;
                }
                else
                {
                    lbEditLink.Visible = false;
                }

                ddlEType.DataSource = ResourceCenterDonationTypeCollection.LoadAll(CurrentOrganization.OrganizationID).DataTable();
                ddlEType.DataTextField = "Name";
                ddlEType.DataValueField = "Id";
                ddlEType.DataBind();
                ddlEType.SelectedValue = "0";

                if (iOfferId > 0)
                {
                    BindViewData(rcOffer);
                }
                else
                {
                    if (Request.QueryString["callid"] != null)
                    {
                        ResourceCenterCall callData = new ResourceCenterCall(Convert.ToInt32(Request.QueryString["callid"]));
                        rcOffer.Notes = callData.Notes;
                        rcOffer.Name = callData.Name;
                        rcOffer.Phone = callData.phone;
                        rcOffer.Date = callData.Date;
                        rcOffer.CallId = callData.Id;
                    }
                    else
                    {
                        rcOffer.Date = DateTime.Today;
                    }
                    BindEditData(rcOffer);
                    lbEditLink_Click(null, null);
                }
            }
        }

        protected void BindViewData(ResourceCenterOffer data)
        {
            lblVAmount.Text = String.Format("{0:0.00}", data.Amount);
            lblVDate.Text = data.Date.ToShortDateString();
            lblVDescription.Text = data.Description;

            if (data.PersonId > 0)
            {
                Person p = new Person(data.PersonId);
                lblVName.Text = "<a href=\"default.aspx?page=" + MemberDetailsPageSetting + "&guid=" + p.Guid.ToString() + "\">" + p.FullName + "</a>";
            }
            else
            {
                lblVName.Text = data.Name;
            }

            if (data.ClientId > 0)
            {
                ResourceCenterPerson p = new ResourceCenterPerson(data.ClientId);
                lVClient.Text = "<a href=\"default.aspx?page=" + ClientDetailsPageSetting + "&personid=" + p.PersonId + "\">" + p.FirstName + " " + p.LastName + "</a>";
            }
            else
            {
                lVClient.Text = "Not Set";
            }

            lblVNotes.Text = data.Notes;
            lblVSize.Text = data.Size.ToString();

            foreach (ResourceCenterHelpSubType t in ResourceCenterDonationTypeCollection.LoadAll(CurrentOrganization.OrganizationID))
            {
                if (t.Id == data.Type)
                    lblVType.Text = t.Name;
            }

            switch (data.Status)
            {
                case 1:
                    lblVStatus.Text = "Available";
                    break;
                case 2:
                    lblVStatus.Text = "Recieved";
                    break;
                case 3:
                    lblVStatus.Text = "In-Process";
                    break;
                case 4:
                    lblVStatus.Text = "Unknown";
                    break;
                case 5:
                    lblVStatus.Text = "Declined";
                    break;
                default:
                    lblVStatus.Text = "Error: " + data.Status.ToString();
                    break;
            }

            if (data.CallId > 0)
                lVCall.Text = "<a href=\"default.aspx?page=" + CallDetailsPageSetting + "&callid=" + data.CallId.ToString() + "\">(" + data.CallId.ToString() + ") View/Edit</a>";
            else
                lVCall.Text = "(none)";

            lblVPhone.Text = data.Phone;
        }

        protected void BindEditData(ResourceCenterOffer data)
        {
            if (data.PersonId > 0)
            {
                Person p = new Person(Convert.ToInt32(data.PersonId));
                lbFindPerson.Text = p.FullName;
                PersonIdTextBox.Text = p.PersonID.ToString();
                //ihPersonList.Value = data.PersonId.ToString();
                tbDonator.Visible = false;
                ibDonatorDelete.Visible = true;
            }
            else
            {
                lbFindPerson.Text = "Find...";
                PersonIdTextBox.Text = "";
                //ihPersonList.Value = "";
                tbDonator.Visible = true;
                ibDonatorDelete.Visible = false;
            }
            tbDonator.Text = data.Name;

            if (data.ClientId > 0)
            {
                ResourceCenterPerson clientData = new ResourceCenterPerson(data.ClientId);
                lbFindClient.Text = clientData.FirstName + " " + clientData.LastName;
                hfClientId.Value = clientData.PersonId.ToString();
                ibDelete.Visible = true;
            }
            else
            {
                lbFindClient.Text = "Find...";
                ibDelete.Visible = false;
            }

            dtbEDate.Text = data.Date.ToShortDateString();
            ddlEType.SelectedValue = data.Type.ToString();
            tbEDescription.Text = data.Description;
            tbGeneralInfoESize.Text = data.Size.ToString();
            tbGeneralInfoEAmount.Text = String.Format("{0:0.00}", data.Amount);
            tbENotes.Text = data.Notes;

            ddlEType_SelectedIndexChanged(null, null);

            ddlEStatus.SelectedValue = data.Status.ToString();
            if (data.CallId > 0)
                lECall.Text = data.CallId.ToString();
            else
                lECall.Text = "(none)";

            tbEPhone.Text = data.Phone;
        }

        protected void SaveEditData(ResourceCenterOffer data)
        {
            if (PersonIdTextBox.Text != "")
            {
                data.PersonId = Convert.ToInt32(PersonIdTextBox.Text);
            }
            else
            {
                data.PersonId = 0;
            }
            if (hfClientId.Value != "")
            {
                data.ClientId = Convert.ToInt32(hfClientId.Value);
            }
            else
            {
                data.ClientId = 0;
            }
            data.Phone = tbEPhone.Text;
            data.Name = tbDonator.Text;
            data.Status = Convert.ToInt32(ddlEStatus.SelectedValue);
            data.Date = dtbEDate.SelectedDate;
            data.Type = Convert.ToInt32(ddlEType.SelectedValue);
            data.Description = tbEDescription.Text;
            data.Size = Convert.ToInt32(tbGeneralInfoESize.Text);
            data.Amount = Convert.ToDecimal(tbGeneralInfoEAmount.Text);
            data.Notes = tbENotes.Text;
            data.Save(CurrentOrganization.OrganizationID, CurrentUser.Identity.Name);
        }

        protected void btnRefresh_Click(object sender, EventArgs e)
        {
            // The search can possibly return multiple ids based on the module setting.
            if (ihPersonList.Value != "")
            {
                string[] personIds = ihPersonList.Value.Split(',');
                foreach (string id in personIds)
                {
                    Person p = new Person(Convert.ToInt32(id));
                    lbFindPerson.Text = p.FullName;
                    PersonIdTextBox.Text = p.PersonID.ToString();
                    tbDonator.Visible = false;
                    ibDonatorDelete.Visible = true;
                }
                ihPersonList.Value = "";
            }
        }

        protected void btnClientRefresh_Click(object sender, EventArgs e)
        {
            // The search can possibly return multiple ids based on the module setting.
            if (ihClientList.Value != "")
            {
                ResourceCenterPerson rcClient = new ResourceCenterPerson(Convert.ToInt32(ihClientList.Value.Trim()));
                lbFindClient.Text = rcClient.FirstName + " " + rcClient.LastName;
                hfClientId.Value = ihClientList.Value.Trim();
                ibDelete.Visible = true;
            }
            ihClientList.Value = "";
        }

        private void RegisterScripts()
        {
            StringBuilder sbScript = new StringBuilder();
            sbScript.Append("\n\n<script language=\"javascript\">\n");
            sbScript.Append("\tfunction openSearchWindow()\n");
            sbScript.Append("\t{\n");
            sbScript.Append("\t\tvar tPos = window.screenTop + 100;\n");
            sbScript.Append("\t\tvar lPos = window.screenLeft + 100;\n");
            sbScript.AppendFormat("\t\tdocument.frmMain.ihPersonListID.value = '{0}';\n", ihPersonList.ClientID);
            sbScript.AppendFormat("\t\tdocument.frmMain.ihRefreshButtonID.value = '{0}';\n", btnRefresh.ClientID);
            sbScript.Append("\t\tvar searchWindow = window.open('Default.aspx?page=16','Search','height=400,width=600,resizable=yes,scrollbars=yes,toolbar=no,location=no,directories=no,status=no,menubar=no,top=' + tPos + ',left=' + lPos);\n");
            sbScript.Append("\t\tsearchWindow.focus();\n");
            sbScript.Append("\t}\n");
            sbScript.Append("\tfunction openSearchClientWindow()\n");
            sbScript.Append("\t{\n");
            sbScript.Append("\t\tvar tPos = window.screenTop + 100;\n");
            sbScript.Append("\t\tvar lPos = window.screenLeft + 100;\n");
            sbScript.AppendFormat("\t\tdocument.frmMain.ihPersonListID.value = '{0}';\n", ihClientList.ClientID);
            sbScript.AppendFormat("\t\tdocument.frmMain.ihRefreshButtonID.value = '{0}';\n", btnClientRefresh.ClientID);
            sbScript.AppendFormat("\t\tvar searchWindow = window.open('Default.aspx?page={2}&plID={0}&rbID={1}','Search','height=400,width=600,resizable=yes,scrollbars=yes,toolbar=no,location=no,directories=no,status=no,menubar=no,top=' + tPos + ',left=' + lPos);\n", ihClientList.ClientID, btnClientRefresh.ClientID, ClientSearchPopupPageSetting);
            sbScript.Append("\t\tsearchWindow.focus();\n");
            sbScript.Append("\t}\n");
            sbScript.Append("</script>\n\n");
            Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "OpenSearchWindow", sbScript.ToString());
        }

        protected void lbEditLink_Click(object sender, EventArgs e)
        {
            pEdit.Visible = true;
            pView.Visible = false;
            BindEditData(rcOffer);
        }

        protected void lbSave_Click(object sender, EventArgs e)
        {
            if (Page.IsValid)
            {
                int oldId = rcOffer.Id;
                SaveEditData(rcOffer);
                BindViewData(rcOffer);
                pEdit.Visible = false;
                pView.Visible = true;

                if (oldId != rcOffer.Id)
                    Response.Redirect("default.aspx?page=" + Request.QueryString["page"] + "&offerid=" + rcOffer.Id.ToString());
            }
        }

        protected void lbCancel_Click(object sender, EventArgs e)
        {
            if (rcOffer.Id > 0)
            {
                pEdit.Visible = false;
                pView.Visible = true;
            }
            else
            {
                Response.Redirect("default.aspx?page=" + OfferSearchPageSetting);
            }
        }

        protected void lbDonationList_Click(object sender, EventArgs e)
        {
            Response.Redirect("default.aspx?page=" + OfferSearchPageSetting);
        }

        protected void lbNewDonation_Click(object sender, EventArgs e)
        {
            Response.Redirect("default.aspx?page=" + Request.QueryString["page"]);
        }

        protected void ddlEType_SelectedIndexChanged(object sender, EventArgs e)
        {
            ResourceCenterHelpSubType f = null;
            foreach (ResourceCenterHelpSubType t in ResourceCenterDonationTypeCollection.LoadAll(CurrentOrganization.OrganizationID))
            {
                if (t.Id.ToString() == ddlEType.SelectedValue)
                    f = t;
            }

            if (f != null)
            {
                if (f.IsAmount)
                {
                    lblValue.Text = f.Text;
                    tbGeneralInfoEAmount.Enabled = true;
                }
                else
                {
                    lblValue.Text = "";
                    tbGeneralInfoEAmount.Enabled = false;
                }

                if (f.IsQuantity)
                {
                    lblQuantity.Text = f.Text;
                    tbGeneralInfoESize.Enabled = true;
                }
                else
                {
                    lblQuantity.Text = "";
                    tbGeneralInfoESize.Enabled = false;
                }
            }
            else
            {
                lblQuantity.Text = "";
                tbGeneralInfoESize.Enabled = true;
                lblValue.Text = "";
                tbGeneralInfoEAmount.Enabled = true;
            }

            upPartial.Update();
        }

        protected bool CanEdit
        {
            get
            {
                return CurrentModule.Permissions.Allowed(OperationType.Edit, CurrentUser);
            }
        }

        protected void DeleteClient_Click(object sender, EventArgs e)
        {
            ibDelete.Visible = false;
            lbFindClient.Text = "Find...";
            hfClientId.Value = "";
        }

        protected void DeleteDonator_Click(object sender, EventArgs e)
        {
            ibDonatorDelete.Visible = false;
            lbFindPerson.Text = "Find...";
            PersonIdTextBox.Text = "";
            tbDonator.Visible = true;
        }

    }
}