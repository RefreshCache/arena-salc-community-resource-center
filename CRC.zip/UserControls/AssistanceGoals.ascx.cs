namespace ArenaWeb.UserControls.Custom.SALC.ResourceCenter
{
    using System;
    using System.Data;
    using System.Linq;
    using System.Web.UI;
    using System.Web.UI.WebControls;
    using Arena.Core;
    using Arena.Organization;
    using Arena.Portal;
    using Arena.Security;
    using Arena.Custom.SALC.ResourceCenter.Entity;

    public partial class AssistanceGoals : PortalControl
    {

        [PageSetting("Client Details Page", "The Client Details page", true)]
        public string ClientDetailsPageSetting { get { return Setting("ClientDetailsPage", "", true); } }

        public enum PAGESTATES
        {
            VIEWTYPE = 0,
            VIEWGOAL = 1,
            VIEWREPORT = 2,
            EDITGOAL = 3,
            NONE = 4,
        }

        private int helpId = -1;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!CanEdit)
                lbEditLink.Visible = false;
            else
                lbEditLink.Visible = true;

            helpId = Convert.ToInt32(Request.QueryString["helpid"]);

            if (!IsPostBack)
            {
                PageState = PAGESTATES.NONE;
                lPageName.Text = "Goals Management";
                iHeaderImage.ImageUrl = "~/Images/whitepages/profile.jpg";

                BuildTreeView();
                UpdateGeneralInfo();
            }
            else
            {
            }
        }

        protected void BuildTreeView()
        {

            GoalCollection goals = GoalCollection.LoadAll(helpId, CurrentArenaContext.Organization.OrganizationID);

            rtvGoals.Nodes.Clear();

            foreach (GoalType at in new GoalTypeCollection(ArenaContext.Current.Organization.OrganizationID))
            {
                Telerik.Web.UI.RadTreeNode node = new Telerik.Web.UI.RadTreeNode(at.Name, "T" + at.Id.ToString());
                rtvGoals.Nodes.Add(node);

                foreach (Goal goal in goals)
                {
                    if (goal.Type == at.Id)
                    {
                        Telerik.Web.UI.RadTreeNode gode = new Telerik.Web.UI.RadTreeNode(goal.Name, "G" + goal.Id.ToString());
                        if (goal.IsClosed)
                        {
                            gode.ImageUrl = "~/Images/greenbutton.gif";
                        }
                        else
                        {
                            if (ProgressReportCollection.LoadAll(goal.Id, CurrentArenaContext.Organization.OrganizationID).Count > 0)
                            {
                                gode.ImageUrl = "~/Images/yellowbutton.gif";
                            }
                            else
                            {
                                gode.ImageUrl = "~/Images/redbutton.gif";
                            }
                        }
                        node.Nodes.Add(gode);

                        foreach (ProgressReport pr in ProgressReportCollection.LoadAll(goal.Id, CurrentArenaContext.Organization.OrganizationID))
                        {
                            Telerik.Web.UI.RadTreeNode rode = new Telerik.Web.UI.RadTreeNode(pr.DateCreated.ToShortDateTimeString(), "R" + pr.Id.ToString());
                            rode.ImageUrl = "~/Images/file.gif";
                            gode.Nodes.Add(rode);
                        }

                    }
                }
                node.ImageUrl = TypeAllClosed(at.Id);
            }
        }

        protected void CreateMessageAlert(string message)
        {
            Page.ClientScript.RegisterStartupScript(this.GetType(), Guid.NewGuid().ToString(), "alert('" + message + "');");
        }

        protected void SetPageDescription(string description)
        {
            if (description == "")
            {
                lblCurrentInfo.Text = "";
            }
            else
            {
                lblCurrentInfo.Text = description + "<br /><br />";
            }
        }

        protected PAGESTATES PageState
        {
            get 
            {
                if (pEditGoal.Visible)
                    return PAGESTATES.EDITGOAL;
                else if (pViewType.Visible)
                    return PAGESTATES.VIEWTYPE;
                else if (pViewGoal.Visible)
                    return PAGESTATES.VIEWGOAL;
                else if (pViewReport.Visible)
                    return PAGESTATES.VIEWREPORT;
                else return PAGESTATES.NONE;
            }
            set
            {
                switch (value)
                {
                    case PAGESTATES.VIEWGOAL:
                        pEditGoal.Visible = false;
                        pViewGoal.Visible = true;
                        pViewReport.Visible = false;
                        pViewType.Visible = false;
                        break;
                    case PAGESTATES.VIEWREPORT:
                        pEditGoal.Visible = false;
                        pViewGoal.Visible = false;
                        pViewReport.Visible = true;
                        pViewType.Visible = false;
                        break;
                    case PAGESTATES.VIEWTYPE:
                        pEditGoal.Visible = false;
                        pViewGoal.Visible = false;
                        pViewReport.Visible = false;
                        pViewType.Visible = true;
                        break;
                    case PAGESTATES.EDITGOAL:
                        if (CanEdit)
                        {
                            pEditGoal.Visible = true;
                            pViewGoal.Visible = false;
                            pViewReport.Visible = false;
                            pViewType.Visible = false;
                        }
                        break;
                    case PAGESTATES.NONE:
                        pEditGoal.Visible = false;
                        pViewGoal.Visible = false;
                        pViewReport.Visible = false;
                        pViewType.Visible = false;
                        break;
                    default:
                        break;
                }
            }
        }

        protected bool CanEdit
        {
            get
            {
                return CurrentModule.Permissions.Allowed(OperationType.Edit, CurrentUser);
            }
        }

        protected void lbEditLink_Click(object sender, EventArgs e)
        {
            PageState = PAGESTATES.EDITGOAL;
            BindEditData("G" + hfCurrentId.Value);
            upPartial.Update();
        }

        protected void lbSave_Click(object sender, EventArgs e)
        {
            if (Page.IsValid)
            {
                //save stuff
                int currentId = Convert.ToInt32(hfCurrentId.Value);
                Goal goal = new Goal(currentId);
                int oldType = goal.Type;
                goal.Name = tbName.Text;
                goal.Description = tbDescription.Text;
                goal.Type = Convert.ToInt32(ddlType.SelectedValue);
                if (ddlStatus.SelectedValue == "1")
                {
                    goal.IsClosed = true;
                }
                else
                {
                    goal.IsClosed = false;
                }
                goal.UserClosable = (ddlUserClosable.SelectedValue == "1");
                goal.HelpId = helpId;
                goal.Save(CurrentUser.Identity.Name);

                if (currentId < 0)
                {
                    //new thing here
                    Telerik.Web.UI.RadTreeNode node = new Telerik.Web.UI.RadTreeNode(goal.Name, "G" + goal.Id.ToString());
                    rtvGoals.Nodes.FindNodeByValue("T" + goal.Type.ToString()).Nodes.Add(node);
                    node.Expanded = true;
                    if (goal.IsClosed)
                    {
                        node.ImageUrl = "~/Images/greenbutton.gif";
                    }
                    else
                    {
                        node.ImageUrl = "~/Images/redbutton.gif";
                    }
                    rtvGoals.Nodes.FindNodeByValue("T" + goal.Type.ToString()).ImageUrl = TypeAllClosed(goal.Type);
                }
                else
                {
                    //it's old
                    Telerik.Web.UI.RadTreeNode pode = rtvGoals.Nodes.FindNodeByValue("T" + oldType.ToString());
                    Telerik.Web.UI.RadTreeNode gode = pode.Nodes.FindNodeByValue("G" + goal.Id);
                    if (oldType != goal.Type)
                    {
                        gode.Remove();
                        gode.Text = goal.Name;
                        Telerik.Web.UI.RadTreeNode pnode = rtvGoals.Nodes.FindNodeByValue("T" + goal.Type.ToString());
                        pnode.Nodes.Add(gode);
                        pnode.Expanded = true;
                        pnode.ImageUrl = TypeAllClosed(goal.Type);

                        pode.ImageUrl = TypeAllClosed(oldType);
                    } else {
                        gode.Text = goal.Name;
                        pode.Expanded = true;
                        pode.ImageUrl = TypeAllClosed(oldType);
                    }

                    if (goal.IsClosed)
                    {
                        gode.ImageUrl = "~/Images/greebutton.gif";
                    }
                    else
                    {
                        if (ProgressReportCollection.LoadAll(goal.Id, CurrentArenaContext.Organization.OrganizationID).Count > 0)
                        {
                            gode.ImageUrl = "~/Images/yellowbutton.gif";
                        }
                        else
                        {
                            gode.ImageUrl = "~/Images/redbutton.gif";
                        }
                    }
                }
                //BuildTreeView();
                UpdateGeneralInfo();
                upTreeView.Update();
                upPartial.Update();
                BindViewData("G" + goal.Id.ToString());

            }
        }

        protected string TypeAllClosed(int typeId)
        {
            bool allClosed = true;
            bool noReports = false;
            bool emptyType = true;
            GoalCollection goals = GoalCollection.LoadAll(helpId, CurrentArenaContext.Organization.OrganizationID);
            //Telerik.Web.UI.RadTreeNode node = rtvGoals.FindNodeByValue("T" + typeId.ToString());

            foreach (Goal goal in goals)
            //foreach (Telerik.Web.UI.RadTreeNode n in node.Nodes)
            {
                if (!goal.IsClosed && (goal.Type == typeId))
                //if (n.ImageUrl == "~/Images/redbutton.gif")
                {
                    allClosed = false;

                    if (ProgressReportCollection.LoadAll(goal.Id, CurrentArenaContext.Organization.OrganizationID).Count == 0)
                    {
                        noReports = true;
                    }
                }
                if (goal.Type == typeId)
                {
                    emptyType = false;
                }
            }
            if (allClosed)
            {
                if (emptyType)
                {
                    return "~/Images/Public/check.gif";
                }
                else
                {
                    return "~/Images/greenbutton.gif";
                }
            }
            else
            {
                if (noReports)
                {
                    return "~/Images/redbutton.gif";
                }
                else
                {
                    return "~/Images/yellowbutton.gif";
                }
            }
        }

        protected void UpdateGeneralInfo()
        {
            int total = 0;
            int open = 0;
            int reports = 0;
            DateTime earliest = DateTime.MaxValue;
            DateTime latest = DateTime.MinValue;

            foreach (Goal goal in GoalCollection.LoadAll(helpId, CurrentArenaContext.Organization.OrganizationID))
            {
                total++;
                if (!goal.IsClosed) open++;
                foreach (ProgressReport pr in ProgressReportCollection.LoadAll(goal.Id, CurrentArenaContext.Organization.OrganizationID))
                {
                    reports++;
                    if (pr.DateCreated > latest) latest = pr.DateCreated;
                    if (pr.DateCreated < earliest) earliest = pr.DateCreated;
                }
            }

            lbGeneralTotalGoals.Text = (total - open).ToString() + " / " + total.ToString() + " (" + string.Format("{0:0.0%}", (double)(total - open) / total) + ")";
            lbGeneralTotalReports.Text = reports.ToString();
            lbGeneralAvgReportsPerGoal.Text = string.Format("{0:0.0}", (double)reports / total);
            if (reports > 0)
            {
                lbGeneralLastReport.Text = latest.ToShortDateTimeString() + " (" + (DateTime.Now - latest).Hours.ToString() + " hours ago)";
            }
            else
            {
                lbGeneralLastReport.Text = "N/A";
            }
            if (reports > 1)
            {
                lbGeneralAvgTimeBetweenReports.Text = string.Format("{0:0.0} hours", (double)(latest - earliest).Hours / reports);
            }
            else
            {
                lbGeneralAvgTimeBetweenReports.Text = "N/A";
            }
        }

        protected void lbCancel_Click(object sender, EventArgs e)
        {
            PageState = PAGESTATES.NONE;
        }

        protected void BindViewData(string nodeId)
        {
            if (nodeId.Length > 0)
            {
                int id = Convert.ToInt32(nodeId.Substring(1, nodeId.Length - 1));
                int reports = 0;
                DateTime earliest = DateTime.MaxValue;
                DateTime latest = DateTime.MinValue;
                switch (nodeId.Substring(0, 1).ToUpper())
                {
                    case "T":
                        PageState = PAGESTATES.VIEWTYPE;
                        lTypeName.Text = new GoalType(id).Name;

                        reports = 0;
                        int total = 0;
                        int open = 0;
                        earliest = DateTime.MaxValue;
                        latest = DateTime.MinValue;

                        foreach (Goal cgoal in GoalCollection.LoadAll(helpId, CurrentArenaContext.Organization.OrganizationID))
                        {
                            if (cgoal.Type == id)
                            {
                                total++;
                                if (!cgoal.IsClosed) open++;
                                foreach (ProgressReport pr in ProgressReportCollection.LoadAll(cgoal.Id, CurrentArenaContext.Organization.OrganizationID))
                                {
                                    reports++;
                                    if (pr.DateCreated > latest) latest = pr.DateCreated;
                                    if (pr.DateCreated < earliest) earliest = pr.DateCreated;
                                }
                            }
                        }

                        lTypeNumReports.Text = reports.ToString();
                        lTypeNumGoals.Text = total.ToString();
                        if (reports > 0)
                        {
                            lTypeLastReport.Text = latest.ToShortDateTimeString() + " (" + (DateTime.Now - latest).Hours.ToString() + " hours ago)";
                        }
                        else
                        {
                            lTypeLastReport.Text = "N/A";
                        }
                        break;
                    case "G":
                        PageState = PAGESTATES.VIEWGOAL;
                        Goal goal = new Goal(id);
                        lGoalDescription.Text = goal.Description;
                        lGoalName.Text = goal.Name;
                        if (goal.IsClosed)
                        {
                            lGoalStatus.Text = "Closed (" + goal.CloseDate.ToShortDateTimeString() + ")";
                        }
                        else
                        {
                            lGoalStatus.Text = "Open";
                        }
                        lGoalType.Text = new GoalType(goal.Type).Name;
                        if (goal.UserClosable)
                        {
                            lGoalUserClosable.Text = "Yes";
                        }
                        else
                        {
                            lGoalUserClosable.Text = "No";
                        }

                        reports = 0;
                        foreach (ProgressReport pr in ProgressReportCollection.LoadAll(goal.Id, CurrentArenaContext.Organization.OrganizationID))
                        {
                            reports++;
                            if (pr.DateCreated > latest) latest = pr.DateCreated;
                            if (pr.DateCreated < earliest) earliest = pr.DateCreated;
                        }

                        lbGoalTotalReports.Text = reports.ToString();
                        if (reports > 0)
                        {
                            lbGoalLastReport.Text = latest.ToShortDateTimeString() + " (" + (DateTime.Now - latest).Hours.ToString() + " hours ago)";
                        }
                        else
                        {
                            lbGoalLastReport.Text = "N/A";
                        }

                        BindReportGrid();

                        break;
                    case "R":
                        PageState = PAGESTATES.VIEWREPORT;
                        ProgressReport tpr = new ProgressReport(id);

                        ResourceCenterPerson p = new ResourceCenterPerson(Convert.ToInt32(tpr.CreatedBy));
                        lbReportCreatedBy.Text = "<a href=\"default.aspx?page=" + ClientDetailsPageSetting + "&personid=" + p.PersonId.ToString() + "\">" + p.FirstName + " " + p.LastName + "</a>";
                        lbReportTimestamp.Text = tpr.DateCreated.ToShortDateTimeString();
                        lbReportDescription.Text = tpr.Description;
                        break;
                    default:
                        break;
                }
            }
            else
            {
                PageState = PAGESTATES.NONE;
            }
        }

        protected void BindEditData(string nodeId)
        {
            if (nodeId.Length > 0)
            {
                int id = Convert.ToInt32(nodeId.Substring(1, nodeId.Length - 1));
                switch (nodeId.Substring(0, 1).ToUpper())
                {
                    case "T":
                        break;
                    case "G":
                        Goal goal = new Goal(id);
                        tbName.Text = goal.Name;
                        tbDescription.Text = goal.Description;
                        if (goal.IsClosed)
                        {
                            ddlStatus.SelectedValue = "1";
                        }
                        else
                        {
                            ddlStatus.SelectedValue = "0";
                        }
                        if (goal.UserClosable)
                        {
                            ddlUserClosable.SelectedValue = "1";
                        }
                        else
                        {
                            ddlUserClosable.SelectedValue = "0";
                        }
                        ddlType.Items.Clear();
                        foreach (GoalType gt in new GoalTypeCollection(CurrentArenaContext.Organization.OrganizationID))
                        {
                            ddlType.Items.Add(new ListItem(gt.Name, gt.Id.ToString()));
                        }
                        if (id > 0)
                        {
                            ddlType.SelectedValue = goal.Type.ToString();
                            //TemplateControl.Page.Title = goal.Type.ToString();
                        }
                        else
                        {
                            if (hfTypeId.Value.Length > 0)
                            {
                                ddlType.SelectedValue = hfTypeId.Value.Substring(1, hfTypeId.Value.Length - 1);
                            }
                        }
                        hfCurrentId.Value = id.ToString();
                        break;
                    default:
                        break;
                }
            }
            else
            {
                PageState = PAGESTATES.NONE;
            }
        }

        protected void rtvGoals_NodeClick(object sender, Telerik.Web.UI.RadTreeNodeEventArgs e)
        {
            if (e.Node.Value != "")
            {
                //CurrentPortalPage.TemplateControl.Title = "\"" + e.Node.Value + "\"";
                switch (e.Node.Value.Substring(0, 1).ToUpper())
                {
                    case "T":
                        hfTypeId.Value = e.Node.Value;
                        hfCurrentId.Value = string.Empty;
                        hfReportId.Value = string.Empty;
                        break;
                    case "G":
                        Goal goal = new Goal(Convert.ToInt32(e.Node.Value.Substring(1, e.Node.Value.Length - 1)));
                        hfTypeId.Value = "T" + goal.Type.ToString();
                        hfCurrentId.Value = goal.Id.ToString();
                        hfReportId.Value = string.Empty;
                        break;
                    case "R":
                        ProgressReport pr = new ProgressReport(Convert.ToInt32(e.Node.Value.Substring(1, e.Node.Value.Length - 1)));
                        Goal pgoal = new Goal(pr.GoalId);
                        hfTypeId.Value = "T" + pgoal.Type.ToString();
                        hfCurrentId.Value = pgoal.Id.ToString();
                        hfReportId.Value = pr.Id.ToString();
                        break;
                    default:
                        break;
                }
                e.Node.Expanded = true;
                BindViewData(e.Node.Value);
            }
            else
            {
                PageState = PAGESTATES.NONE;
            }
        }

        protected void rtvGoals_MenuClick(object sender, Telerik.Web.UI.RadTreeViewContextMenuEventArgs e)
        {
            switch (e.MenuItem.Value)
            {
                case "Create":
                    CreateGoal();
                    break;
                case "Delete":
                    if (e.Node.Value.Substring(0, 1).ToUpper() == "G")
                    {
                        {
                            Telerik.Web.UI.RadTreeNode pode = e.Node.ParentNode;
                            e.Node.ParentNode.Nodes.Remove(e.Node);
                            //delete the node and update, ask for confirmation?
                            Goal.Delete(Convert.ToInt32(e.Node.Value.Substring(1, e.Node.Value.Length - 1)));
                            UpdateGeneralInfo();
                            pode.ImageUrl = TypeAllClosed(Convert.ToInt32(e.Node.Value.Substring(1, e.Node.Value.Length - 1)));
                            upTreeView.Update();
                            upPartial.Update();
                            PageState = PAGESTATES.NONE;
                        }
                    }
                    break;
                default:
                    PageState = PAGESTATES.NONE;
                    upPartial.Update();
                    break;
            }
        }

        protected void CreateGoal()
        {
            //hfParentId.Value = (new Asset(Convert.ToInt32(hfAssetId.Value)).ParentId).ToString();
            PageState = PAGESTATES.EDITGOAL;
            BindEditData("G-1");
            upPartial.Update();
        }

        protected void lbCreateGoal_Click(object sender, EventArgs e)
        {
            CreateGoal();
        }

        protected void Reports_ReBind(object sender, EventArgs e)
        {
            BindReportGrid();
        }

        public string CreateNameExpression(string personId)
        {
            ResourceCenterPerson p = new ResourceCenterPerson(Convert.ToInt32(personId));
            return "<a href=\"default.aspx?page=" + ClientDetailsPageSetting + "&personid=" + personId.ToString() + "\">" + p.FirstName + " " + p.LastName + "</a>";
        }

        protected void BindReportGrid()
        {
            //Page.Title = hfCurrentId.Value;
            ProgressReportCollection prg = ProgressReportCollection.LoadAll(Convert.ToInt32(hfCurrentId.Value), CurrentArenaContext.Organization.OrganizationID);
            dgReports.DataSource = prg.DataTable();
            dgReports.DataBind();
        }

        public void Note_Click(object sender, CommandEventArgs e)
        {
            int rprtId = Convert.ToInt32(e.CommandArgument);
            ProgressReport pg = new ProgressReport(rprtId);

            Goal g = new Goal(pg.GoalId);

            ResourceCenterNote note = new ResourceCenterNote();
            note.HelpId = g.HelpId;
            note.Note = pg.Description;
            note.TagDate = pg.DateCreated;

            note.Save(CurrentUser.Identity.Name);
            //e.CommandArgument
        }

        public void ReportDataGrid_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            e.Row.ID = Guid.NewGuid().ToString();
        }

        public void lnkNote_Click(object sender, EventArgs e)
        {
            int rprtId = Convert.ToInt32(hfReportId.Value);
            ProgressReport pg = new ProgressReport(rprtId);

            Goal g = new Goal(pg.GoalId);

            ResourceCenterNote note = new ResourceCenterNote();
            note.HelpId = g.HelpId;
            note.Note = pg.Description;
            note.TagDate = pg.DateCreated;

            note.Save(CurrentUser.Identity.Name);
        }

    }
}