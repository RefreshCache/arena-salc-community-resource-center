﻿namespace ArenaWeb.UserControls.Custom.SALC.ResourceCenter
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Web;
    using System.Web.UI;
    using System.Web.UI.WebControls;
    using Arena.Core;
    using Arena.Portal;
    using Arena.Portal.UI;
    using Arena.Security;
    using Arena.Custom.SALC.ResourceCenter.Entity;

    public partial class AssistanceProgressReports : PortalControl
    {

        [PageSetting("Client Details Page", "The Client Details page", true)]
        public string ClientDetailsPageSetting { get { return Setting("ClientDetailsPage", "", true); } }

        [BooleanSetting("Search For HelpId", "Whether or not to search for the helpid query string", true, true)]
        public bool SearchForHelpIdSetting { get { return Convert.ToBoolean(Setting("SearchForHelpId", "", true)); } }

        private int helpId = -1;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (SearchForHelpIdSetting)
            {
                helpId = Convert.ToInt32(Request.QueryString["helpid"]);
            }
            else
            {
                helpId = 0;
            }
            if (!IsPostBack)
            {
                dtbSearchDate.SelectedDate = DateTime.Today;
                BindGrid();
            }
        }

        protected void Page_Init(object sender, System.EventArgs e)
        {
            ReportDataGrid.ReBind += new DataGridReBindEventHandler(ReportDataGrid_ReBind);
        }

        void ReportDataGrid_ReBind(object sender, EventArgs e)
        {
            BindGrid();
        }

        private void BindGrid()
        {
            DateTime newStartDate = Convert.ToDateTime("1/1/1901");
            DateTime newEndDate = Convert.ToDateTime("12/31/2199");

            //newEndDate = dtbSearchDate.SelectedDate.AddDays(1);

            ProgressReportCollection reports = null;
            switch (Convert.ToInt32(ddlDateFrame.SelectedValue))
            {
                case 0:
                    newStartDate = dtbSearchDate.SelectedDate;
                    newEndDate = dtbSearchDate.SelectedDate.AddDays(1);
                    dtbSearchDate.Enabled = true;
                    break;
                case 1:
                    newStartDate = dtbSearchDate.SelectedDate;
                    dtbSearchDate.Enabled = true;
                    break;
                case 2:
                    newEndDate = dtbSearchDate.SelectedDate.AddDays(1);
                    dtbSearchDate.Enabled = true;
                    break;
                case 3:
                    dtbSearchDate.Enabled = false;
                    break;
                default:
                    //do nothing
                    break;
            }
            reports = ProgressReportCollection.LoadAll(newStartDate, newEndDate, helpId, 0);
            ReportDataGrid.DataSource = reports.DataTable();
            ReportDataGrid.DataBind();
            upPartial.Update();
        }

        protected void ReportGrid_ReBind(object sender, EventArgs e)
        {
            BindGrid();
        }

        public string CreateNameExpression(string personId)
        {
            ResourceCenterPerson p = new ResourceCenterPerson(Convert.ToInt32(personId));
            return "<a href=\"default.aspx?page=" + ClientDetailsPageSetting + "&personid=" + personId.ToString() + "\">" + p.FirstName + " " + p.LastName + "</a>";
        }

        public void Note_Click(object sender, CommandEventArgs e)
        {
            int rprtId = Convert.ToInt32(e.CommandArgument);
            ProgressReport pg = new ProgressReport(rprtId);

            Goal g = new Goal(pg.GoalId);

            ResourceCenterNote note = new ResourceCenterNote();
            note.HelpId = g.HelpId;
            note.Note = pg.Description;
            note.TagDate = pg.DateCreated;

            note.Save(CurrentUser.Identity.Name);
            //e.CommandArgument
            BindGrid();
        }

        public void ReportDataGrid_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            e.Row.ID = Guid.NewGuid().ToString();
        }

        public void Search_Changed(object sender, EventArgs e)
        {
            BindGrid();
        }
    }
}
