﻿namespace ArenaWeb.UserControls.Cutsom.SALC.ResourceCenter
{
    using System;
    using System.Linq;
    using Arena.Portal;
    using Arena.Security;
    using Arena.Custom.SALC.ResourceCenter.Entity;

    public partial class AssistanceAddClient : PortalControl
    {

        [PageSetting("Assistance Details Page", "The Assistance Details page", true)]
        public string AssistanceDetailsPageSetting { get { return Setting("AssistanceDetailsPage", "", true); } }

        private ResourceCenterPersonCollection clients;
        public int helpId = 0;

        protected void Page_Load(object sender, EventArgs e)
        {
            helpId = Convert.ToInt32(Request.QueryString["helpid"]);
            if (IsPostBack)
            {
                clients = ResourceCenterPersonCollection.LoadAll(CurrentOrganization.OrganizationID, tbFirstName.Text, tbLastName.Text, tbPhone.Text, "", "", helpId);
                ClientDataGrid.NoResultText = "There are no results to display.";
                Clients_Rebind();
            }
            else
            {
                lPageName.Text = "Add Client to Existing Assistance";
                iHeaderImage.ImageUrl = "~/Images/whitepages/profile.jpg";
                clients = new ResourceCenterPersonCollection();
                ClientDataGrid.NoResultText = "Please enter a search parameter.";
                Clients_Rebind();
            }
        }

        protected void Clients_Rebind()
        {
            ClientDataGrid.DataSource = clients.DataTable();
            ClientDataGrid.DataBind();
            upPartial.Update();
        }

        protected void Clients_ReBind(object sender, EventArgs e)
        {
            clients = ResourceCenterPersonCollection.LoadAll(CurrentOrganization.OrganizationID, tbFirstName.Text, tbLastName.Text, tbPhone.Text, "", "", helpId);
            Clients_Rebind();
        }

        protected bool CanEdit
        {
            get
            {
                return CurrentModule.Permissions.Allowed(OperationType.Edit, CurrentUser);
            }
        }

        protected void lbCancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("default.aspx?page=" + AssistanceDetailsPageSetting + "&helpid=" + helpId.ToString());
        }

    }
}