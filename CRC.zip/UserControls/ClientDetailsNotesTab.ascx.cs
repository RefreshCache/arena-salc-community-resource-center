using Arena.Custom.SALC.ResourceCenter.Entity;

namespace Arena.UserControls.Custom.SALC.ResourceCenter
{
    using System;
    using System.Linq;
    using System.Web.UI.WebControls;
    using Arena.Portal;
    using Arena.Security;

    public partial class ClientDetailsNotesTab : PortalControl
    {

        [PageSetting("Assistance Details Page", "The Assistance Details page", true)]
        public string AssistanceDetailsPage
        {
            get
            {
                return Setting("AssistanceDetailsPage", "", true);
            }
        }

        private int piPersonId = -1;
        private int piHelpId = -1;
        private ResourceCenterPerson prcData;

        protected void Page_Load(object sender, EventArgs e)
        {
            //if (!CanEdit)
                //lbEditLink.Visible = false;
            //else
                //lbEditLink.Visible = true;

            if (Request.QueryString["personid"] != null)
            {
                try
                {
                    piPersonId = Convert.ToInt32(Request.QueryString["personid"]);
                    prcData = new ResourceCenterPerson(piPersonId);
                    CurrentPortalPage.TemplateControl.Title = prcData.FirstName + " " + prcData.LastName;
                    lPageName.Text = "Client Notes";
                }
                catch
                {
                    piPersonId = -1;
                }
            }
            else
            {
                piPersonId = -1;

                if (Request.QueryString["helpid"] != null)
                {
                    try
                    {
                        piHelpId = Convert.ToInt32(Request.QueryString["helpid"]);
                        lPageName.Text = "Assistance Notes";
                    }
                    catch
                    {
                        piHelpId = -1;
                    }
                }
                else
                {
                    piHelpId = -1;
                }
            }


            if (!IsPostBack)
            {
                BindNotes();
            }
            else
            {
            }
        }

        protected void CreateMessageAlert(string message)
        {
            Page.ClientScript.RegisterStartupScript(this.GetType(), Guid.NewGuid().ToString(), "alert('" + message + "');");
        }

        protected void SetPageDescription(string description)
        {
            if (description == "")
            {
                lblCurrentInfo.Text = "";
            }
            else
            {
                lblCurrentInfo.Text = description + "<br /><br />";
            }
        }

        protected bool CanEdit
        {
            get
            {
                return CurrentModule.Permissions.Allowed(OperationType.Edit, CurrentUser);
            }
        }

        protected void lbEditLink_Click(object sender, EventArgs e)
        {
            
        }

        protected void lbSave_Click(object sender, EventArgs e)
        {
            if (Page.IsValid)
            {
                //save stuff
                
            }
        }

        protected void lbCancel_Click(object sender, EventArgs e)
        {
            
        }

        protected void BindNotes()
        {
            ResourceCenterNoteCollection notes = null;
            if (piPersonId > 0)
            {
                notes = ResourceCenterNoteCollection.LoadAll(CurrentOrganization.OrganizationID, Convert.ToDateTime("1/1/1901"), Convert.ToDateTime("12/31/2099"), -1, piPersonId);
            }
            else if (piHelpId > 0)
            {
                notes = ResourceCenterNoteCollection.LoadAll(CurrentOrganization.OrganizationID, Convert.ToDateTime("1/1/1901"), Convert.ToDateTime("12/31/2099"), piHelpId, -1);
            }
            GridNotes.DataSource = notes.DataTable();
            GridNotes.DataBind();
        }

        protected void AddNote_Click(object sender, EventArgs e)
        {
            ResourceCenterNote noteData = new ResourceCenterNote();
            //noteData.OrganizationId = CurrentArenaContext.Organization.OrganizationID;
            if (piPersonId > 0) noteData.ClientId = piPersonId;
            if (piHelpId > 0) noteData.HelpId = piHelpId;
            noteData.Note = "[New Note]";
            noteData.TagDate = DateTime.Now;
            noteData.Save(CurrentUser.Identity.Name);
            BindNotes();
        }

        protected void EditNote_Click(object sender, DataGridCommandEventArgs e)
        {
            bool hasIssue = false;
            ResourceCenterNote noteData = new ResourceCenterNote(Convert.ToInt32(e.Item.Cells[0].Text));
            
            try
            {
                noteData.TagDate = Convert.ToDateTime(((TextBox)e.Item.Cells[1].Controls[0]).Text); //((TextBox)e.Item.Controls[1].Controls[0]).Text;
            }
            catch
            {
                hasIssue = true;
            }
            try
            {
                noteData.Note = ((TextBox)e.Item.Cells[2].Controls[1]).Text;
            }
            catch
            {
                hasIssue = true;
            }
            //noteData.Note = ((TextBox)e.Item.Controls[3].Controls[0]).Text;
            if (!hasIssue)
            {
                GridNotes.EditItemIndex = -1;
                noteData.Save(CurrentUser.Identity.Name);
            }
            BindNotes();
        }

        protected void DeleteNote_Click(object sender, DataGridCommandEventArgs e)
        {
            if (GridNotes.EditItemIndex > -1)
            {
                //GridAccount.CancelCommand(sender, e);
                GridNotes.EditItemIndex = -1;
            }
            TableCell itemCell = e.Item.Cells[0];
            int noteId = 0;
            try
            {
                noteId = Convert.ToInt32(itemCell.Text);
            }
            catch
            {
                noteId = 0;
            }
            if (noteId > 0)
            {
                ResourceCenterNote.Delete(noteId);
                BindNotes();
            }
        }

        protected void GridNotes_Rebind(object sender, EventArgs e)
        {
            BindNotes();
        }

        protected string GenerateLink(int helpId)
        {
            if ((helpId > 0) && (piPersonId > 0))
            {
                ResourceCenterHelp help = new ResourceCenterHelp(helpId);
                ResourceCenterHelpSubTypeCollection types = ResourceCenterHelpSubTypeCollection.LoadAll(CurrentOrganization.OrganizationID);
                string name = string.Empty;

                foreach (ResourceCenterHelpSubType r in types)
                {
                    if (r.Id == help.SubType)
                    {
                        name = r.Name;
                    }
                }
                return "<a href=\"default.aspx?page=" + AssistanceDetailsPage + "&helpid=" + helpId.ToString() + "\">" + name + "</a>";
            }
            else
            {
                return string.Empty;
            }
        }

        protected string DisplayHTMLNote(string note)
        {
            return note.Replace("\n", "<br />");
        }

    }
}