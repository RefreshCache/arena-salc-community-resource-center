namespace Arena.UserControls.Custom.SALC.ResourceCenter
{
    using System;
    using System.Data;
    using System.Linq;
    using System.Web.UI;
    using System.Web.UI.WebControls;
    using Arena.Portal;
    using Arena.Security;
    using Arena.Custom.SALC.ResourceCenter.Entity;

    public partial class AssistanceHMIS : PortalControl
    {

        private int piHelpId = -1;
        private ResourceCenterHelp phHelpData = null;
        private ResourceCenterHMISCollection phHMISData = null;

        private const string whiteSpace = "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
        private const string nextLine = "<br />";

        protected void Page_Load(object sender, EventArgs e)
        {
            if ((Request.QueryString["helpid"]) != null)
            {
                piHelpId = Convert.ToInt32(Request.QueryString["helpid"]);
                phHelpData = new ResourceCenterHelp(piHelpId);

                if (phHelpData.SubType == 14)
                {
                    BindSurveyList();
                }
                else
                {
                    pAll.Visible = false;
                    pWrongType.Visible = true;
                }
            }

            if (!CanEdit)
                lbExitEditLink.Visible = false;
            else
                lbExitEditLink.Visible = true;

        }

        protected void BindSurveyList()
        {
            phHMISData = ResourceCenterHMISCollection.LoadAll(CurrentOrganization.OrganizationID, piHelpId);
            repHMIS.DataSource = phHMISData.DataTable();
            repHMIS.DataBind();
        }

        protected void CreateMessageAlert(string message)
        {
            Page.ClientScript.RegisterStartupScript(this.GetType(), Guid.NewGuid().ToString(), "alert('" + message + "');");
        }

        protected void SetPageDescription(string description)
        {
            if (description == "")
            {
                lblCurrentInfo.Text = "";
            }
            else
            {
                lblCurrentInfo.Text = description + "<br /><br />";
            }
        }

        protected bool CanEdit
        {
            get
            {
                return CurrentModule.Permissions.Allowed(OperationType.Edit, CurrentUser);
            }
        }

        protected void ExitEditLink_Click(object sender, EventArgs e)
        {
            ExitBindEditData(Convert.ToInt32(hidLastClickId.Value));
        }

        protected void ExitSaveButton_Click(object sender, EventArgs e)
        {
            if (Page.IsValid)
            {
                //save stuff
                ResourceCenterHMIS hSid = new ResourceCenterHMIS(Convert.ToInt32(hidLastClickId.Value));
                if (dtbExitDate.Text.Length > 0)
                {
                    hSid.TagDate = dtbExitDate.SelectedDate;
                }
                else
                {
                    hSid.TagDate = Arena.DataLib.SqlData.DateTimeMinValue;
                }
                int iReason = 0;
                if (chkExitR01.Checked) iReason += (1 << (1 - 1));
                if (chkExitR02.Checked) iReason += (1 << (2 - 1));
                if (chkExitR03.Checked) iReason += (1 << (3 - 1));
                if (chkExitR04.Checked) iReason += (1 << (4 - 1));
                if (chkExitR05.Checked) iReason += (1 << (5 - 1));
                if (chkExitR06.Checked) iReason += (1 << (6 - 1));
                if (chkExitR07.Checked) iReason += (1 << (7 - 1));
                if (chkExitR08.Checked) iReason += (1 << (8 - 1));
                if (chkExitR09.Checked) iReason += (1 << (9 - 1));
                if (chkExitR10.Checked) iReason += (1 << (10 - 1));
                if (chkExitR11.Checked) iReason += (1 << (11 - 1));
                hSid.ReasonForLeaving = iReason;

                int iDestination = 0;
                if (chkExitD01.Checked) iDestination += (1 << (1 - 1));
                if (chkExitD02.Checked) iDestination += (1 << (2 - 1));
                if (chkExitD03.Checked) iDestination += (1 << (3 - 1));
                if (chkExitD04.Checked) iDestination += (1 << (4 - 1));
                if (chkExitD05.Checked) iDestination += (1 << (5 - 1));
                if (chkExitD06.Checked) iDestination += (1 << (6 - 1));
                if (chkExitD07.Checked) iDestination += (1 << (7 - 1));
                if (chkExitD08.Checked) iDestination += (1 << (8 - 1));
                if (chkExitD09.Checked) iDestination += (1 << (9 - 1));
                if (chkExitD10.Checked) iDestination += (1 << (10 - 1));
                if (chkExitD11.Checked) iDestination += (1 << (11 - 1));
                if (chkExitD12.Checked) iDestination += (1 << (12 - 1));
                if (chkExitD13.Checked) iDestination += (1 << (13 - 1));
                if (chkExitD14.Checked) iDestination += (1 << (14 - 1));
                if (chkExitD15.Checked) iDestination += (1 << (15 - 1));
                if (chkExitD16.Checked) iDestination += (1 << (16 - 1));
                if (chkExitD17.Checked) iDestination += (1 << (17 - 1));
                if (chkExitD18.Checked) iDestination += (1 << (18 - 1));
                if (chkExitD19.Checked) iDestination += (1 << (19 - 1));
                hSid.Destination = iDestination;

                hSid.HelpId = piHelpId;
                hSid.Save(CurrentUser.Identity.Name);
                BindSurveyList();
                upPartial.Update();

                ExitBindViewData(hSid.Id);
            }
        }

        protected void ExitCancelButton_Click(object sender, EventArgs e)
        {
            ExitBindViewData(Convert.ToInt32(hidLastClickId.Value));
        }

        protected void ExitNew_Click(object sender, EventArgs e)
        {
            hidLastClickId.Value = "-1";
            ExitBindEditData(-1);
        }

        protected void ExitBindViewData(int hmisId)
        {
            pExitEdit.Visible = false;
            pExitView.Visible = true;
            ResourceCenterHMIS hSid = new ResourceCenterHMIS(hmisId);

            if (hSid.TagDate > Arena.DataLib.SqlData.DateTimeMinValue)
            {
                litExitDate.Text = hSid.TagDate.ToShortDateString();
            }
            else
            {
                litExitDate.Text = "None Specified";
            }

            string sReason = string.Empty;
            if ((hSid.ReasonForLeaving & (1 << (1 - 1))) > 0) sReason += whiteSpace + "Left for housing opportunity before completing program" + nextLine;
            if ((hSid.ReasonForLeaving & (1 << (2 - 1))) > 0) sReason += whiteSpace + "Completed program" + nextLine;
            if ((hSid.ReasonForLeaving & (1 << (3 - 1))) > 0) sReason += whiteSpace + "Non-payment of rent" + nextLine;
            if ((hSid.ReasonForLeaving & (1 << (4 - 1))) > 0) sReason += whiteSpace + "Non-compliance with program" + nextLine;
            if ((hSid.ReasonForLeaving & (1 << (5 - 1))) > 0) sReason += whiteSpace + "Criminal activity/violence" + nextLine;
            if ((hSid.ReasonForLeaving & (1 << (6 - 1))) > 0) sReason += whiteSpace + "Reached maximum time allowed" + nextLine;
            if ((hSid.ReasonForLeaving & (1 << (7 - 1))) > 0) sReason += whiteSpace + "Needs could not be met" + nextLine;
            if ((hSid.ReasonForLeaving & (1 << (8 - 1))) > 0) sReason += whiteSpace + "Disagreement with rules/persons" + nextLine;
            if ((hSid.ReasonForLeaving & (1 << (9 - 1))) > 0) sReason += whiteSpace + "Death" + nextLine;
            if ((hSid.ReasonForLeaving & (1 << (10 - 1))) > 0) sReason += whiteSpace + "Unknown/Disappeared" + nextLine;
            if ((hSid.ReasonForLeaving & (1 << (11 - 1))) > 0) sReason += whiteSpace + "Other" + nextLine;

            if (sReason.Length > 0)
            {
                sReason = sReason.Substring(0, sReason.Length - nextLine.Length);
            }
            else
            {
                sReason = whiteSpace + "None Specified";
            }
            litExitReason.Text = sReason;


            string sDestination = string.Empty;
            if ((hSid.Destination & (1 << (1 - 1))) > 0) sDestination += whiteSpace + "Emergency shelter" + nextLine;
            if ((hSid.Destination & (1 << (2 - 1))) > 0) sDestination += whiteSpace + "Place not meant for habitation" + nextLine;
            if ((hSid.Destination & (1 << (3 - 1))) > 0) sDestination += whiteSpace + "Hotel or motel paid for by client" + nextLine;
            if ((hSid.Destination & (1 << (4 - 1))) > 0) sDestination += whiteSpace + "Transitional housing" + nextLine;
            if ((hSid.Destination & (1 << (5 - 1))) > 0) sDestination += whiteSpace + "Permanent supportive housing" + nextLine;
            if ((hSid.Destination & (1 << (6 - 1))) > 0) sDestination += whiteSpace + "Staying or living with family (temporary)" + nextLine;
            if ((hSid.Destination & (1 << (7 - 1))) > 0) sDestination += whiteSpace + "Staying or living with family (permanent)" + nextLine;
            if ((hSid.Destination & (1 << (8 - 1))) > 0) sDestination += whiteSpace + "Staying or living with friends (temporary)" + nextLine;
            if ((hSid.Destination & (1 << (9 - 1))) > 0) sDestination += whiteSpace + "Staying or living with friends (permanent)" + nextLine;
            if ((hSid.Destination & (1 << (10 - 1))) > 0) sDestination += whiteSpace + "Rental by client, no housing subsidy" + nextLine;
            if ((hSid.Destination & (1 << (11 - 1))) > 0) sDestination += whiteSpace + "Rental by client, housing subsidy" + nextLine;
            if ((hSid.Destination & (1 << (12 - 1))) > 0) sDestination += whiteSpace + "Rental by client, VASH subsidy" + nextLine;
            if ((hSid.Destination & (1 << (13 - 1))) > 0) sDestination += whiteSpace + "Hospital (non-psychiatric)" + nextLine;
            if ((hSid.Destination & (1 << (14 - 1))) > 0) sDestination += whiteSpace + "Owned by client, no housing subsidy" + nextLine;
            if ((hSid.Destination & (1 << (15 - 1))) > 0) sDestination += whiteSpace + "Psychiatric hospital or other psychiatric facility" + nextLine;
            if ((hSid.Destination & (1 << (16 - 1))) > 0) sDestination += whiteSpace + "Owned by client, with housing subsidy" + nextLine;
            if ((hSid.Destination & (1 << (17 - 1))) > 0) sDestination += whiteSpace + "Substance abuse treatment facility or detox center" + nextLine;
            if ((hSid.Destination & (1 << (18 - 1))) > 0) sDestination += whiteSpace + "Foster care home or foster care group home" + nextLine;
            if ((hSid.Destination & (1 << (19 - 1))) > 0) sDestination += whiteSpace + "Jail, prison, or juvenile detention facility" + nextLine;

            if (sDestination.Length > 0)
            {
                sDestination = sDestination.Substring(0, sDestination.Length - nextLine.Length);
            }
            else
            {
                sDestination = whiteSpace + "None Specified";
            }
            litExitDestination.Text = sDestination;
        
        }

        protected void ExitBindEditData(int hmisId)
        {
            pExitEdit.Visible = true;
            pExitView.Visible = false;
            ResourceCenterHMIS hSid = new ResourceCenterHMIS(hmisId);

            if (hSid.TagDate > Arena.DataLib.SqlData.DateTimeMinValue)
            {
                dtbExitDate.Text = hSid.TagDate.ToShortDateString();
            }
            else
            {
                dtbExitDate.Text = DateTime.Now.ToShortDateString();
            }

            if ((hSid.ReasonForLeaving & (1 << (1 - 1))) > 0) chkExitR01.Checked = true; else chkExitR01.Checked = false;
            if ((hSid.ReasonForLeaving & (1 << (2 - 1))) > 0) chkExitR02.Checked = true; else chkExitR02.Checked = false;
            if ((hSid.ReasonForLeaving & (1 << (3 - 1))) > 0) chkExitR03.Checked = true; else chkExitR03.Checked = false;
            if ((hSid.ReasonForLeaving & (1 << (4 - 1))) > 0) chkExitR04.Checked = true; else chkExitR04.Checked = false;
            if ((hSid.ReasonForLeaving & (1 << (5 - 1))) > 0) chkExitR05.Checked = true; else chkExitR05.Checked = false;
            if ((hSid.ReasonForLeaving & (1 << (6 - 1))) > 0) chkExitR06.Checked = true; else chkExitR06.Checked = false;
            if ((hSid.ReasonForLeaving & (1 << (7 - 1))) > 0) chkExitR07.Checked = true; else chkExitR07.Checked = false;
            if ((hSid.ReasonForLeaving & (1 << (8 - 1))) > 0) chkExitR08.Checked = true; else chkExitR08.Checked = false;
            if ((hSid.ReasonForLeaving & (1 << (9 - 1))) > 0) chkExitR09.Checked = true; else chkExitR09.Checked = false;
            if ((hSid.ReasonForLeaving & (1 << (10 - 1))) > 0) chkExitR10.Checked = true; else chkExitR10.Checked = false;
            if ((hSid.ReasonForLeaving & (1 << (11 - 1))) > 0) chkExitR11.Checked = true; else chkExitR11.Checked = false;

            if ((hSid.Destination & (1 << (1 - 1))) > 0) chkExitD01.Checked = true; else chkExitD01.Checked = false;
            if ((hSid.Destination & (1 << (2 - 1))) > 0) chkExitD02.Checked = true; else chkExitD02.Checked = false;
            if ((hSid.Destination & (1 << (3 - 1))) > 0) chkExitD03.Checked = true; else chkExitD03.Checked = false;
            if ((hSid.Destination & (1 << (4 - 1))) > 0) chkExitD04.Checked = true; else chkExitD04.Checked = false;
            if ((hSid.Destination & (1 << (5 - 1))) > 0) chkExitD05.Checked = true; else chkExitD05.Checked = false;
            if ((hSid.Destination & (1 << (6 - 1))) > 0) chkExitD06.Checked = true; else chkExitD06.Checked = false;
            if ((hSid.Destination & (1 << (7 - 1))) > 0) chkExitD07.Checked = true; else chkExitD07.Checked = false;
            if ((hSid.Destination & (1 << (8 - 1))) > 0) chkExitD08.Checked = true; else chkExitD08.Checked = false;
            if ((hSid.Destination & (1 << (9 - 1))) > 0) chkExitD09.Checked = true; else chkExitD09.Checked = false;
            if ((hSid.Destination & (1 << (10 - 1))) > 0) chkExitD10.Checked = true; else chkExitD10.Checked = false;
            if ((hSid.Destination & (1 << (11 - 1))) > 0) chkExitD11.Checked = true; else chkExitD11.Checked = false;
            if ((hSid.Destination & (1 << (12 - 1))) > 0) chkExitD12.Checked = true; else chkExitD12.Checked = false;
            if ((hSid.Destination & (1 << (13 - 1))) > 0) chkExitD13.Checked = true; else chkExitD13.Checked = false;
            if ((hSid.Destination & (1 << (14 - 1))) > 0) chkExitD14.Checked = true; else chkExitD14.Checked = false;
            if ((hSid.Destination & (1 << (15 - 1))) > 0) chkExitD15.Checked = true; else chkExitD15.Checked = false;
            if ((hSid.Destination & (1 << (16 - 1))) > 0) chkExitD16.Checked = true; else chkExitD16.Checked = false;
            if ((hSid.Destination & (1 << (17 - 1))) > 0) chkExitD17.Checked = true; else chkExitD17.Checked = false;
            if ((hSid.Destination & (1 << (18 - 1))) > 0) chkExitD18.Checked = true; else chkExitD18.Checked = false;
            if ((hSid.Destination & (1 << (19 - 1))) > 0) chkExitD19.Checked = true; else chkExitD19.Checked = false;
        }

        protected void HMISCommand(Object sender, RepeaterCommandEventArgs e)
        {
            int iSid = Convert.ToInt32((string)e.CommandArgument);
            //ResourceCenterHMIS hSid = new ResourceCenterHMIS(iSid);
            hidLastClickId.Value = iSid.ToString();
            ExitBindViewData(iSid);
            upPartial.Update();
        }

        protected string SurveyName(int id)
        {
            ResourceCenterHMIS hSid = new ResourceCenterHMIS(Convert.ToInt32(id));
            return hSid.TagDate.ToShortDateString();
        }
    }
}