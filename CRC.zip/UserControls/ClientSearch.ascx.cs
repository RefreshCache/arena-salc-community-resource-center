﻿namespace ArenaWeb.UserControls.Cutsom.SALC.ResourceCenter
{
    using System;
    using System.Linq;
    using Arena.Portal;
    using Arena.Portal.UI;
    using Arena.Security;
    using Arena.Custom.SALC.ResourceCenter.Entity;

    public partial class ClientSearch : PortalControl
    {

        [PageSetting("Client Details Page", "The Client Details page", true)]
        public string ClientDetailsPageSetting { get { return Setting("ClientDetailsPage", "", true); } }

        private ResourceCenterPersonCollection clients;

        protected void Page_Load(object sender, EventArgs e)
        {

            if (IsPostBack)
            {
                clients = ResourceCenterPersonCollection.LoadAll(CurrentOrganization.OrganizationID, tbFirstName.Text, tbLastName.Text, tbPhone.Text);
                ClientDataGrid.NoResultText = "There are no results to display.";
                Clients_Rebind();
            }
            else
            {
                if (CanEdit)
                {
                    lCreate.Text = "<a href=\"default.aspx?page=" + ClientDetailsPageSetting + "\">Add New Client</a>";
                }
                else
                {
                    lCreate.Text = "";
                }
                clients = new ResourceCenterPersonCollection();
                ClientDataGrid.NoResultText = "Please enter a search parameter.";
                Clients_Rebind();
            }
        }

        protected void Clients_Rebind()
        {
            ClientDataGrid.DataSource = clients.DataTable();
            ClientDataGrid.DataBind();
            upPartial.Update();
        }

        protected void Clients_ReBind(object sender, EventArgs e)
        {
            clients = ResourceCenterPersonCollection.LoadAll(CurrentOrganization.OrganizationID, tbFirstName.Text, tbLastName.Text, tbPhone.Text);
            Clients_Rebind();
        }

        protected bool CanEdit
        {
            get
            {
                return CurrentModule.Permissions.Allowed(OperationType.Edit, CurrentUser);
            }
        }

    }
}