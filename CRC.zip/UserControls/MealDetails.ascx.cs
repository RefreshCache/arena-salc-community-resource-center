﻿namespace Arena.UserControls.Custom.SALC.ResourceCenter
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Web;
    using System.Web.UI;
    using System.Web.UI.WebControls;
    using Arena.Core;
    using Arena.Portal;
    using Arena.Portal.UI;
    using Arena.Security;
    using Arena.Custom.SALC.ResourceCenter.Entity;

    public partial class MealDetails : PortalControl
    {
        [PageSetting("Meal Search Page", "The Meal Search page", true)]
        public string MealSearchPageSetting { get { return Setting("MealSearchPage", "", true); } }

        public int _mealId = -1;
        private ResourceCenterMeal _mealdata = new ResourceCenterMeal();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (CanEdit)
                {
                    EditLink.Visible = true;
                    lbCreate.Visible = true;
                }
                else
                {
                    EditLink.Visible = false;
                    lbCreate.Visible = false;
                }
                lPageName.Text = "Meal Details";
                iHeaderImage.ImageUrl = "~/Images/whitepages/bgchecks.JPG";
            }

            if (Request.QueryString["mealid"] != null)
                _mealId = Convert.ToInt32(Request.QueryString["mealid"].ToString());
            else
                _mealId = 0;

            if (_mealId > 0)
            {
                _mealdata = new ResourceCenterMeal(_mealId);
                BindViewData();
            }
            else
            {
                if (!IsPostBack)
                {
                    BindEditData();
                }
                else
                {
                }
            }
        }

        protected void BindViewData()
        {
            panEdit.Visible = false;
            panView.Visible = true;

            lblVID.Text = _mealdata.Id.ToString();
            if (_mealdata.Date > Convert.ToDateTime("1/1/1901"))
            {
                lblVDate.Text = _mealdata.Date.ToShortDateString();
            }
            else
            {
                lblVDate.Text = "Undefined";
            }
            lblVDist.Text = _mealdata.Dist.ToString();
            lblVMeals.Text = _mealdata.Meals.ToString();
            lblVPounds.Text = _mealdata.Pounds.ToString();
            lblVServed.Text = _mealdata.Served.ToString();
        }

        protected void BindEditData()
        {
            panEdit.Visible = true;
            panView.Visible = false;

            if (_mealdata.Id > 0)
            {
                lblEID.Text = _mealdata.Id.ToString();
            }
            else
            {
                lblEID.Text = "Not yet saved!";
            }

            if (_mealdata.Date > Convert.ToDateTime("1/1/1901"))
            {
                dtbEDate.Text = _mealdata.Date.ToShortDateString();
            }
            else
            {
                DateTime dt = DateTime.Now;
                while (dt.DayOfWeek != DayOfWeek.Thursday) dt = dt.AddDays(-1);
                dtbEDate.Text = dt.ToShortDateString();
            }
            tbEDist.Text = _mealdata.Dist.ToString();
            tbEMeals.Text = _mealdata.Meals.ToString();
            tbEPounds.Text = _mealdata.Pounds.ToString();
            tbEServed.Text = _mealdata.Meals.ToString();
        }

        protected void Edit_Click(object sender, EventArgs e)
        {
            BindEditData();
        }

        protected void List_Click(object sender, EventArgs e)
        {
            Response.Redirect("default.aspx?page=" + MealSearchPageSetting);
        }

        protected void Create_Click(object sender, EventArgs e)
        {
            string page = Request.QueryString["page"];
            Response.Redirect("default.aspx?page=" + page + "&mealid=0");
        }

        protected void Save_Click(object sender, EventArgs e)
        {
            if (Page.IsValid)
            {
                _mealdata.Date = Convert.ToDateTime(dtbEDate.Text);
                _mealdata.Dist = Convert.ToInt32(tbEDist.Text);
                _mealdata.Meals = Convert.ToInt32(tbEMeals.Text);
                _mealdata.Pounds = Convert.ToInt32(tbEPounds.Text);
                _mealdata.Served = Convert.ToInt32(tbEServed.Text);
                _mealdata.Save(Page.User.Identity.Name);
                _mealdata = new ResourceCenterMeal(_mealdata.Id);
                BindViewData();
            }
        }

        protected void Cancel_Click(object sender, EventArgs e)
        {
            if (_mealId > 0)
            {
                BindViewData();
            }
            else
            {
                Response.Redirect("default.aspx?page=" + MealSearchPageSetting);
            }
        }

        protected bool CanEdit
        {
            get
            {
                return CurrentModule.Permissions.Allowed(OperationType.Edit, CurrentUser);
            }
        }

    }
}