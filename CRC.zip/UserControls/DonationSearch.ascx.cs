﻿namespace Arena.UserControls.Custom.SALC.ResourceCenter
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Linq;
    using System.Web;
    using System.Web.UI;
    using System.Web.UI.WebControls;
    using Arena.Core;
    using Arena.Portal;
    using Arena.Portal.UI;
    using Arena.Security;
    using Arena.Custom.SALC.ResourceCenter.Entity;

    public partial class DonationSearch : PortalControl
    {

        [PageSetting("Donation Details Page", "The Donation Details page", true)]
        public string DonationDetailsPageSetting { get { return Setting("DonationDetailsPage", "", true); } }

        [PageSetting("Member Details Page", "The Member Details page", true)]
        public string MemberDetailsPageSetting { get { return Setting("MemberDetailsPage", "", true); } }

        private ResourceCenterDonationCollection donations;
        private ArrayList typeList = new ArrayList();

        private class typeListType
        {
            public int index;
            public string value;

            public typeListType()
            {
                index = -1;
                value = "";
            }

            public typeListType(int idx, string val)
            {
                index = idx;
                value = val;
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {

            if (IsPostBack)
            {
                BindDonationGrid();
            }
            else
            {
                if (CanEdit)
                {
                    lCreateLink.Text = "<a href=\"default.aspx?page=" + DonationDetailsPageSetting + "\">Add New Donation</a>";
                    DonationGrid.DeleteEnabled = true;
                }
                else
                {
                    lCreateLink.Text = "";
                    DonationGrid.DeleteEnabled = false;
                }

                ResourceCenterDonationTypeCollection types = ResourceCenterDonationTypeCollection.LoadAllWithBlank(CurrentOrganization.OrganizationID);
                ddlType.Items.Clear();
                ddlType.DataSource = types.DataTable();
                ddlType.DataTextField = "Name";
                ddlType.DataValueField = "Id";
                ddlType.DataBind();

                DonationGrid.NoResultText = "Please enter a search parameter.";
                donations = ResourceCenterDonationCollection.LoadAll(int.MaxValue, Convert.ToDateTime("1/1/1901"), Convert.ToDateTime("1/1/1901"), tbFirstName.Text, tbLastName.Text, int.MaxValue);
                DonationGrid.DataSource = donations.DataTable();
                DonationGrid.DataBind();
            }
        }

        protected void BindDonationGrid()
        {
            DateTime st;
            DateTime et;
            if (dtbStartDate.Text == "")
            {
                st = Convert.ToDateTime("1/1/1901");
            }
            else
            {
                st = dtbStartDate.SelectedDate;
            }
            if (dtbEndDate.Text == "")
            {
                et = Convert.ToDateTime("12/31/2199");
            }
            else
            {
                et = dtbEndDate.SelectedDate;
            }
            donations = ResourceCenterDonationCollection.LoadAll(CurrentOrganization.OrganizationID, st, et, tbFirstName.Text, tbLastName.Text, Convert.ToInt32(ddlType.SelectedValue));
            DonationGrid.NoResultText = "There are no results to display.";
            DonationGrid.DataSource = donations.DataTable();
            DonationGrid.DataBind();

            upPartial.Update();
        }

        protected string GenerateNameLink(int personId)
        {
            string s = string.Empty;

            if (personId > 0)
            {
                Person p = new Person(personId);
                if (p.NickName == "")
                {
                    s = p.LastName + ", " + p.FirstName;
                }
                else
                {
                    s = p.LastName + ", " + p.NickName;
                }

                s = "<a href=\"default.aspx?page=" + MemberDetailsPageSetting + "&guid=" + p.PersonGUID.ToString() + "\">" + s + "</a>";
            }
            else
            {
                s = "Anonymous";
            }
            return s;
        }

        protected string GetTypeName(int type)
        {
            ResourceCenterDonationTypeCollection types = ResourceCenterDonationTypeCollection.LoadAllWithBlank(CurrentOrganization.OrganizationID);
            foreach (ResourceCenterHelpSubType sub in types)
            {
                if (type == sub.Id)
                    return sub.Name;
            }
            return "Unknown";
        }

        protected void DonationGrid_Delete(object sender, DataGridCommandEventArgs e)
        {
            TableCell t = e.Item.Cells[0];
            ResourceCenterDonation.Delete(Convert.ToInt32(t.Text));
            BindDonationGrid();
        }

        protected bool CanEdit
        {
            get
            {
                return CurrentModule.Permissions.Allowed(OperationType.Edit, CurrentUser);
            }
        }

        protected void DonationGrid_ReBind(object sender, EventArgs e)
        {
            BindDonationGrid();
        }

    }
}