﻿namespace ArenaWeb.UserControls.Custom.SALC.ResourceCenter
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Web;
    using System.Web.UI;
    using System.Web.UI.WebControls;
    using Arena.Core;
    using Arena.Portal;
    using Arena.Portal.UI;
    using Arena.Security;
    using Arena.Custom.SALC.ResourceCenter.Entity;

    public partial class CallSearch : PortalControl
    {

        [PageSetting("Call Details Page", "The Call Details page", true)]
        public string CallDetailsPageSetting { get { return Setting("CallDetailsPage", "", true); } }

        [PageSetting("Client Details Page", "The Client Details page", true)]
        public string ClientDetailsPageSetting { get { return Setting("ClientDetailsPage", "", true); } }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (CanEdit)
                {
                    lbNewCall.Visible = true;
                }
                else
                {
                    lbNewCall.Visible = false;
                }

                RestoreFilters();
            }
            BindGrid();
        }

        protected void SaveSetting(string key, string value)
        {
            string keyStart = "SALC CRC Call Log ";

            PersonSetting ps = CurrentPerson.Settings.FindByKey(keyStart + key);
            if (ps == null)
            {
                ps = new PersonSetting();
                CurrentPerson.Settings.Add(ps);
            }
            ps.Key = keyStart + key;
            ps.OrganizationId = CurrentOrganization.OrganizationID;
            ps.Value = value;
            ps.PersonId = CurrentPerson.PersonID;
            ps.Save();
        }

        protected void SaveCurrentFilters()
        {
            SaveSetting("DateType", ddlDateFrame.SelectedValue);

            if (dtbSearchDate.SelectedDate.Date.ToShortDateString() == DateTime.Today.Date.ToShortDateString())
                SaveSetting("Date", "");
            else
                SaveSetting("Date", dtbSearchDate.SelectedDate.ToShortDateString());

            SaveSetting("Tag", ddlSearchMessageFor.SelectedValue);

            SaveSetting("Filter", ddlFilter.SelectedValue);

            SaveSetting("Request", ddlRequest.SelectedValue);

            SaveSetting("Search", tbSearch.Text);

        }

        protected string GetSetting(string key, string defaultValue)
        {
            string keyStart = "SALC CRC Call Log ";

            PersonSetting ps = CurrentPerson.Settings.FindByKey(keyStart + key);
            if (ps == null)
            {
                return defaultValue;
            }
            else
            {
                return ps.Value;
            }
        }

        protected void RestoreFilters()
        {
            ddlDateFrame.SelectedValue = GetSetting("DateType", "0");

            if (GetSetting("Date", "") == "")
            {
                dtbSearchDate.SelectedDate = DateTime.Today;
            } else {
                dtbSearchDate.SelectedDate = Convert.ToDateTime(GetSetting("Date", DateTime.Today.ToShortDateString()));
            }

            ddlSearchMessageFor.SelectedValue = GetSetting("Tag", "");

            ddlFilter.SelectedValue = GetSetting("Filter", "0");

            ddlRequest.SelectedValue = GetSetting("Request", "0");

            tbSearch.Text = GetSetting("Search", "");
        }

        protected void Page_Init(object sender, System.EventArgs e)
        {
            CallDataGrid.ReBind += new DataGridReBindEventHandler(CallDataGrid_ReBind);
        }

        void CallDataGrid_ReBind(object sender, EventArgs e)
        {
            BindGrid();
        }

        protected void NewCall_Click(object sender, EventArgs e)
        {
            Response.Redirect("default.aspx?page=" + CallDetailsPageSetting + "&callid=0");
        }

        private void BindGrid()
        {
            DateTime newStartDate = Convert.ToDateTime("1/1/1901");
            DateTime newEndDate = Convert.ToDateTime("12/31/2199");

            //newEndDate = dtbSearchDate.SelectedDate.AddDays(1);

            string msg = ddlSearchMessageFor.SelectedValue;
            if (msg == "")
            {
                msg = "%";
            }
            else
            {
                msg = "%" + msg + "%";
            }
            string search = tbSearch.Text;
            if (search == "")
            {
                search = "%";
            }
            else
            {
                search = "%" + search + "%";
            }

            int status = Convert.ToInt32(ddlFilter.SelectedValue);

            ResourceCenterCallCollection calls = null;
            switch (Convert.ToInt32(ddlDateFrame.SelectedValue))
            {
                case 0:
                    newStartDate = dtbSearchDate.SelectedDate;
                    newEndDate = dtbSearchDate.SelectedDate.AddDays(1);
                    dtbSearchDate.Enabled = true;
                    break;
                case 1:
                    newStartDate = dtbSearchDate.SelectedDate;
                    dtbSearchDate.Enabled = true;
                    break;
                case 2:
                    newEndDate = dtbSearchDate.SelectedDate.AddDays(1);
                    dtbSearchDate.Enabled = true;
                    break;
                case 3:
                    dtbSearchDate.Enabled = false;
                    break;
                default:
                    //do nothing
                    break;
            }
            calls = ResourceCenterCallCollection.LoadAll(newStartDate, newEndDate, msg, Convert.ToInt32(ddlRequest.SelectedValue), search, status, CurrentOrganization.OrganizationID);
            CallDataGrid.DataSource = calls.DataTable();
            CallDataGrid.DataBind();
            upPartial.Update();
        }

        protected string GetCallType(int t)
        {
            switch (t)
            {
                case 1:
                    return "Assistance Request";
                case 2:
                    return "Volunteer/Donation";
                case 3:
                    return "Info Request";
                case 4:
                    return "Check-In";
                case 5:
                    return "Donation";
                case 6:
                    return "Agency Rep";
                default:
                    return "Unknown";
            }
        }

        protected string GetImageLink(int t)
        {
            switch (t)
            {
                case 0:
                    return "UserControls/Custom/SALC/ResourceCenter/Images/Exclamation.png";
                case 1:
                    return "UserControls/Custom/SALC/ResourceCenter/Images/CheckMark.png";
                case 2:
                    return "UserControls/Custom/SALC/ResourceCenter/Images/Minus.png";
                default:
                    return "";
            }
        }

        protected bool CanEdit
        {
            get
            {
                return CurrentModule.Permissions.Allowed(OperationType.Edit, CurrentUser);
            }
        }

        protected void CallGrid_ReBind(object sender, EventArgs e)
        {
            BindGrid();
        }

        public string CreateNameExpression(string name, int personId)
        {
            if (personId > 0)
            {
                return "<a href=\"default.aspx?page=" + ClientDetailsPageSetting + "&personid=" + personId.ToString() + "\">" + name + "</a>";
            }
            else
            {
                return name;
            }
        }

        public void Global_OnChange(object sender, EventArgs e)
        {
            SaveCurrentFilters();
        }

    }
}
