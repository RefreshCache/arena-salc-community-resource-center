﻿namespace ArenaWeb.UserControls.Custom.SALC.ResourceCenter
{
    using System;
    using System.Data;
    using System.Linq;
    using System.Web.UI;
    using System.Web.UI.WebControls;
    using Arena.Core;
    using Arena.Portal;
    using Arena.Security;
    using Arena.Custom.SALC.ResourceCenter.Entity;

    public partial class ClientDetailsContactTab : PortalControl
    {
        [PageSetting("Call Details Page", "The Call Details page", true)]
        public string CallDetailsPageSetting
        {
            get
            {
                return Setting("CallDetailsPage", "", true);
            }
        }

        [PageSetting("Offer Details Page", "The Offer Details page", true)]
        public string OfferDetailsPageSetting
        {
            get
            {
                return Setting("OfferDetailsPage", "", true);
            }
        }

        [PageSetting("Member Details Page", "The Member Details page", true)]
        public string MemberDetailsPageSetting { get { return Setting("MemberDetailsPage", "", true); } }


        private bool _editEnabled = true;
        public int _personId = -1;
        public string _thisPage = string.Empty;
        private bool _isQuick = false;
        private ResourceCenterPerson _rcdata;
        public ResourceCenterHelpCollection _helpList;
        public ResourceCenterPersonCollection _familyList;
        public ResourceCenterEventCollection _paydates;

        protected void Page_Load(object sender, EventArgs e)
        {
            _thisPage = Request.QueryString["page"];
            _isQuick = ((Request.QueryString["quick"] != null) || (Request.QueryString["similar"] != null));

            if (Request.QueryString["personid"] != null)
            {
                try
                {
                    _personId = Convert.ToInt32(Request.QueryString["personid"]);
                    _rcdata = new ResourceCenterPerson(_personId);
                    CurrentPortalPage.TemplateControl.Title = _rcdata.FirstName + " " + _rcdata.LastName;
                }
                catch
                {
                    _personId = -1;
                }
            }
            else
            {
                _personId = -1;
            }

            if (!IsPostBack)
            {
                if (CanEdit)
                {
                }
                else
                {
                }
            }

            BindCallGrid();
            BindOfferGrid();
        }

        protected void SetPageDescription(string description)
        {
            lblCurrentInfo.Text = description + "<br /><br />";
            upHeader.Update();
        }

        protected void DeleteHelpLink_Click(object sender, DataGridCommandEventArgs e)
        {
            TableCell itemCell = e.Item.Cells[0];
            int helpId = Convert.ToInt32(itemCell.Text);
            ResourceCenterHelp _helpdata = new ResourceCenterHelp();
            _helpdata.Delete(helpId, _personId);
            //HideEdit(null, null);
            //lblDebug.Text = (helpId.ToString());
        }

        protected string CreateDateString(DateTime d)
        {
            if (d > Convert.ToDateTime("1/1/1901"))
            {
                return d.ToShortDateString();
            }
            else
            {
                return "Unknown Date";
            }
        }

        public string GetNeedNameFromId(int needId)
        {
            return ResourceCenterHelp.GetTypeNameById(needId);
        }

        public string GetResourceNameFromId(int resourceId)
        {
            return ResourceCenterHelp.GetSubtypeNameById(resourceId);
        }

        public string GetCompletedString(DateTime completedOn)
        {
            string s = string.Empty;

            if (completedOn > Convert.ToDateTime("1/1/1901"))
            {
                s = "Yes (" + completedOn.ToShortDateString() + ")";
            }
            else
            {
                s = "No";
            }

            return s;
        }

        public bool IsDate(string sdate)
        {
            bool isDate = true;

            try
            {
                DateTime.Parse(sdate);
            }
            catch
            {
                isDate = false;
            }

            return isDate;
        }

        protected void StrictDate_Validate(object sender, ServerValidateEventArgs args)
        {
            args.IsValid = IsDate(args.Value.ToString());
        }

        protected void Date_Validate(object sender, ServerValidateEventArgs args)
        {
            args.IsValid = ((IsDate(args.Value.ToString())) || (args.Value.ToString() == ""));
        }

        protected void Decimal_Validate(object sender, ServerValidateEventArgs args)
        {
            bool isDecimal = true;

            try
            {
                decimal.Parse(args.Value.ToString());
            }
            catch
            {
                isDecimal = false;
            }

            args.IsValid = (isDecimal && (args.Value.ToString() != ""));
        }

        protected bool CanEdit
        {
            get
            {
                return CurrentModule.Permissions.Allowed(OperationType.Edit, CurrentUser);
            }
        }

        protected void CallGrid_ReBind(object sender, EventArgs e)
        {
            BindCallGrid();
        }

        protected void BindCallGrid()
        {
            ResourceCenterCallCollection calls = new ResourceCenterCallCollection(_personId);
            CallDataGrid.DataSource = calls.DataTable();
            CallDataGrid.DataBind();
        }

        protected void OfferGrid_ReBind(object sender, EventArgs e)
        {
            BindOfferGrid();
        }

        protected void BindOfferGrid()
        {
            ResourceCenterOfferCollection offers = ResourceCenterOfferCollection.LoadAll(CurrentOrganization.OrganizationID, _personId);
            OfferGrid.DataSource = offers.DataTable();
            OfferGrid.DataBind();
        }

        protected string GetImageLink(int t)
        {
            switch (t)
            {
                case 0:
                    return "UserControls/Custom/SALC/ResourceCenter/Images/Exclamation.png";
                case 1:
                    return "UserControls/Custom/SALC/ResourceCenter/Images/CheckMark.png";
                case 2:
                    return "UserControls/Custom/SALC/ResourceCenter/Images/Minus.png";
                default:
                    return "";
            }
        }

        protected string GetCallType(int t)
        {
            switch (t)
            {
                case 1:
                    return "Assistance Request";
                case 2:
                    return "Volunteer/Donation";
                case 3:
                    return "Info Request";
                case 4:
                    return "Check-In";
                default:
                    return "Unknown";
            }
        }

        protected string GenerateNameLink(int personId, string name)
        {
            string s = string.Empty;

            if (personId > 0)
            {
                Person p = new Person(personId);
                if (p.NickName == "")
                {
                    s = p.LastName + ", " + p.FirstName;
                }
                else
                {
                    s = p.LastName + ", " + p.NickName;
                }

                s = "<a href=\"default.aspx?page=" + MemberDetailsPageSetting + "&guid=" + p.PersonGUID.ToString() + "\">" + s + "</a>";
            }
            else
            {
                s = name;
            }
            return s;
        }

        protected string GetTypeName(int type)
        {
            ResourceCenterDonationTypeCollection types = ResourceCenterDonationTypeCollection.LoadAllWithBlank(CurrentOrganization.OrganizationID);
            foreach (ResourceCenterHelpSubType sub in types)
            {
                if (type == sub.Id)
                    return sub.Name;
            }
            return "Unknown";
        }

    }
}