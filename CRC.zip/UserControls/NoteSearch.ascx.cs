﻿namespace ArenaWeb.UserControls.Custom.SALC.ResourceCenter
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Web;
    using System.Web.UI;
    using System.Web.UI.WebControls;
    using Arena.Core;
    using Arena.Portal;
    using Arena.Portal.UI;
    using Arena.Security;
    using Arena.Custom.SALC.ResourceCenter.Entity;

    public partial class NoteSearch : PortalControl
    {

        [PageSetting("Assistance Details Page", "The Assistance Details page", true)]
        public string AssistanceDetailsPage
        {
            get
            {
                return Setting("AssistanceDetailsPage", "", true);
            }
        }

        [PageSetting("Client Details Page", "The Client Details page", true)]
        public string ClientDetailsPage
        {
            get
            {
                return Setting("ClientDetailsPage", "", true);
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                dtbSearchDate.SelectedDate = DateTime.Today;
                BindGrid();
            }
        }

        protected void Page_Init(object sender, System.EventArgs e)
        {
            NotesDataGrid.ReBind += new DataGridReBindEventHandler(CallDataGrid_ReBind);
        }

        void CallDataGrid_ReBind(object sender, EventArgs e)
        {
            BindGrid();
        }

        protected void NewCall_Click(object sender, EventArgs e)
        {
            //Response.Redirect("default.aspx?page=" + CallDetailsPageSetting + "&callid=0");
        }

        private void BindGrid()
        {
            DateTime newStartDate = Convert.ToDateTime("1/1/1901");
            DateTime newEndDate = Convert.ToDateTime("12/31/2199");

            //newEndDate = dtbSearchDate.SelectedDate.AddDays(1);

            ResourceCenterNoteCollection notes = null;
            switch (Convert.ToInt32(ddlDateFrame.SelectedValue))
            {
                case 0:
                    newStartDate = dtbSearchDate.SelectedDate;
                    newEndDate = dtbSearchDate.SelectedDate.AddDays(1);
                    dtbSearchDate.Enabled = true;
                    break;
                case 1:
                    newStartDate = dtbSearchDate.SelectedDate;
                    dtbSearchDate.Enabled = true;
                    break;
                case 2:
                    newEndDate = dtbSearchDate.SelectedDate.AddDays(1);
                    dtbSearchDate.Enabled = true;
                    break;
                case 3:
                    dtbSearchDate.Enabled = false;
                    break;
                default:
                    //do nothing
                    break;
            }
            notes = ResourceCenterNoteCollection.LoadAll(CurrentOrganization.OrganizationID, newStartDate, newEndDate, -1, -1);
            NotesDataGrid.DataSource = notes.DataTable();
            NotesDataGrid.DataBind();

            ProgressReportCollection prc = ProgressReportCollection.LoadAll(newStartDate, newEndDate, 0, 0);
            ReportDataGrid.DataSource = prc.DataTable();
            ReportDataGrid.DataBind();
            upPartial.Update();
        }

        protected bool CanEdit
        {
            get
            {
                return CurrentModule.Permissions.Allowed(OperationType.Edit, CurrentUser);
            }
        }

        protected void GridNotes_Rebind(object sender, EventArgs e)
        {
            BindGrid();
        }

        protected string GenerateLink(int helpId, int personId)
        {
            if (helpId > 0)
            {
                ResourceCenterHelp help = new ResourceCenterHelp(helpId);
                ResourceCenterHelpSubTypeCollection types = ResourceCenterHelpSubTypeCollection.LoadAll(CurrentOrganization.OrganizationID);
                string name = string.Empty;

                foreach (ResourceCenterHelpSubType r in types)
                {
                    if (r.Id == help.SubType)
                    {
                        name = r.Name;
                    }
                }

                ResourceCenterPersonCollection clients = ResourceCenterPersonCollection.LoadAll(helpId);
                ResourceCenterPerson client = null;
                foreach (ResourceCenterPerson c in clients)
                {
                    if (client == null)
                    {
                        client = c;
                    }
                    else
                    {
                        if (c.Id < client.Id)
                        {
                            client = c;
                        }
                    }
                }

                string html = string.Empty;
                html += "Client: <a href=\"default.aspx?page=" + ClientDetailsPage + "&personid=" + client.PersonId.ToString() + "\">Family of " + client.FirstName + " " + client.LastName + "</a>";
                html += "&nbsp;Assistance: <a href=\"default.aspx?page=" + AssistanceDetailsPage + "&helpid=" + helpId.ToString() + "\">" + name + "</a>";
                return html;
            }
            else if (personId > 0)
            {
                ResourceCenterPerson client = new ResourceCenterPerson(personId);
                return "Client: <a href=\"default.aspx?page=" + ClientDetailsPage + "&personid=" + personId.ToString() + "\">" + client.FirstName + " " + client.LastName + "</a>";
            }
            else
            {
                return string.Empty;
            }
        }

        protected string DisplayHTMLNote(string note)
        {
            return note.Replace("\n", "<br />");
        }

        protected void ReportGrid_ReBind(object sender, EventArgs e)
        {
            BindGrid();
        }

        public string CreateNameExpression(string personId)
        {
            ResourceCenterPerson p = new ResourceCenterPerson(Convert.ToInt32(personId));
            return "<a href=\"default.aspx?page=" + ClientDetailsPage + "&personid=" + personId.ToString() + "\">" + p.FirstName + " " + p.LastName + "</a>";
        }

        public void Note_Click(object sender, CommandEventArgs e)
        {
            int rprtId = Convert.ToInt32(e.CommandArgument);
            ProgressReport pg = new ProgressReport(rprtId);

            Goal g = new Goal(pg.GoalId);

            ResourceCenterNote note = new ResourceCenterNote();
            note.HelpId = g.HelpId;
            note.Note = pg.Description;
            note.TagDate = pg.DateCreated;
            
            note.Save(CurrentUser.Identity.Name);
            //e.CommandArgument
            BindGrid();
        }

        public void ReportDataGrid_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            e.Row.ID = Guid.NewGuid().ToString();
        }

        public void Search_Changed(object sender, EventArgs e)
        {
            BindGrid();
        }

    }
}
