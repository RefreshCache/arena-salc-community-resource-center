﻿namespace ArenaWeb.UserControls.Custom.SALC.ResourceCenter
{
    using System;
    using System.Data;
    using System.Linq;
    using System.Web.UI;
    using System.Web.UI.WebControls;
    using Arena.Portal;
    using Arena.Security;
    using Arena.Custom.SALC.ResourceCenter.Entity;

    public partial class ClientDetailsGeneralTab : PortalControl
    {
        [PageSetting("Client Search Page", "The Client Search page", true)]
        public string SearchPageSetting
        {
            get
            {
                return Setting("SearchPage", "", true);
            }
        }

        [PageSetting("Assistance Details Page", "The Assistance Details page", true)]
        public string AssistanceDetailsPage
        {
            get
            {
                return Setting("AssistanceDetailsPage", "", true);
            }
        }

        [PageSetting("Bulk Change Address Page", "The Bulk Change Address page", true)]
        public string BulkChangeAddressPage
        {
            get
            {
                return Setting("BulkChangeAddressPage", "", true);
            }
        }

        private bool _editEnabled = true;
        public int _personId = -1;
        public string _thisPage = string.Empty;
        private bool _isQuick = false;
        private ResourceCenterPerson _rcdata;
        public ResourceCenterHelpCollection _helpList;
        public ResourceCenterPersonCollection _familyList;
        public ResourceCenterEventCollection _paydates;

        protected void Page_Load(object sender, EventArgs e)
        {
            _thisPage = Request.QueryString["page"];
            _isQuick = ((Request.QueryString["quick"] != null) || (Request.QueryString["similar"] != null));

            if (Request.QueryString["personid"] != null)
            {
                try
                {
                    _personId = Convert.ToInt32(Request.QueryString["personid"]);
                    _rcdata = new ResourceCenterPerson(_personId);
                    CurrentPortalPage.TemplateControl.Title = _rcdata.FirstName + " " + _rcdata.LastName;
                }
                catch
                {
                    _personId = -1;
                }
            }
            else
            {
                _personId = -1;
            }
            if ((_personId <= 0) && (SimDone.Value != "true"))
            {
                //creating a new person
                _rcdata = new ResourceCenterPerson();
                if (_editEnabled)
                {
                    EditLink.Visible = true;
                }
                else
                {
                    EditLink.Visible = false;
                }
                pStatsFooter.Visible = false;
                pBottomSectionHeader.Visible = false;
                SetPageDescription("Add New Client");

                int iSim = Convert.ToInt32(Request.QueryString["similar"]);

                if (iSim > 0)
                {
                    ResourceCenterPerson sim = new ResourceCenterPerson(iSim);
                    _rcdata.LastName = sim.LastName;
                    _rcdata.FoodSupport = sim.FoodSupport;
                    _rcdata.HelpRequested = sim.HelpRequested;
                    _rcdata.EBT = sim.EBT;
                    _rcdata.PhoneHome = sim.PhoneHome;
                    _rcdata.PastDoubled = sim.PastDoubled;
                    _rcdata.PastDoubledDate = sim.PastDoubledDate;
                    _rcdata.PastEviction = sim.PastEviction;
                    _rcdata.PastEvictionDate = sim.PastEvictionDate;
                    _rcdata.PastForeclosure = sim.PastForeclosure;
                    _rcdata.PastForeclosureDate = sim.PastForeclosureDate;
                    _rcdata.PastShelter = sim.PastShelter;
                    _rcdata.PastShelterDate = sim.PastShelterDate;
                    _rcdata.PastTransitional = sim.PastTransitional;
                    _rcdata.PastTransitionalDate = sim.PastTransitionalDate;
                    _rcdata.PastUnsheltered = sim.PastUnsheltered;
                    _rcdata.PastUnshelteredDate = sim.PastUnshelteredDate;
                    _rcdata.FoodShelf = sim.FoodShelf;
                    _rcdata.FoodShelfVisit = sim.FoodShelfVisit;
                    _rcdata.County = sim.County;
                    _rcdata.StreetAddress = sim.StreetAddress;
                    _rcdata.City = sim.City;
                    _rcdata.PostalCode = sim.PostalCode;
                    _rcdata.State = sim.State;
                    _rcdata.CaseMgr1Agency = sim.CaseMgr1Agency;
                    _rcdata.CaseMgr1Name = sim.CaseMgr1Name;
                    _rcdata.CaseMgr1Notes = sim.CaseMgr1Notes;
                    _rcdata.CaseMgr1Phone = sim.CaseMgr1Phone;
                    _rcdata.CaseMgr2Agency = sim.CaseMgr2Agency;
                    _rcdata.CaseMgr2Name = sim.CaseMgr2Name;
                    _rcdata.CaseMgr2Notes = sim.CaseMgr2Notes;
                    _rcdata.CaseMgr2Phone = sim.CaseMgr2Phone;
                    SetPageDescription("Add New Client <em>Similar to <strong>" + sim.FirstName + " " + sim.LastName + "</strong></em>");
                }
                SimDone.Value = "true";
                ShowEdit(null, null);
            }
            else
            {
                if (!IsPostBack)
                {
                    _editEnabled = CurrentModule.Permissions.Allowed(OperationType.Edit, CurrentUser);
                    if (_editEnabled)
                    {
                        EditLink.Visible = true;
                    }
                    else
                    {
                        EditLink.Visible = false;
                    }
                }
                //editing an existing person
                _rcdata = new ResourceCenterPerson(_personId);
                HideEdit(null, null);
            }

            calDates.Width = 400;
            calDates.Height = 400;

            if (!IsPostBack)
            {
                BindCalendar(DateTime.Today);
                if (CanEdit)
                {
                    EditLink.Visible = true;
                    SimilarLink.Visible = true;
                }
                else
                {
                    EditLink.Visible = false;
                    SimilarLink.Visible = false;
                }
            }
        }

        protected void SetPageDescription(string description)
        {
            //lblCurrentInfo.Text = description + "<br /><br />";
            //upHeader.Update();
        }

        protected void DeleteHelpLink_Click(object sender, DataGridCommandEventArgs e)
        {
            TableCell itemCell = e.Item.Cells[0];
            int helpId = Convert.ToInt32(itemCell.Text);
            ResourceCenterHelp _helpdata = new ResourceCenterHelp();
            _helpdata.Delete(helpId, _personId);
            HideEdit(null, null);
            //lblDebug.Text = (helpId.ToString());
        }

        protected void BindEditData()
        {
            SetPageDescription("Edit Client Details: <strong>" + _rcdata.FirstName + " " + _rcdata.LastName + "</strong>");
            if (_personId != -1)
            {
                _rcdata = new ResourceCenterPerson(_personId);
            }

            tbEMessage.Text = _rcdata.Message;
            //lblName.Text = "<a class=\"trigger\" href=\"default.aspx?page=" + DetailsPageSetting + "&guid=" + _rcdata.Person.PersonGUID + "\" rel=\"" + PopupPageSetting + "," + _rcdata.Person.PersonGUID + "\">" + _rcdata.Person.FullName + "</a>";
            //lblDOB.Text = _rcdata.Person.BirthDate.ToShortDateString();
            tbFirstName.Text = _rcdata.FirstName;
            tbNickName.Text = _rcdata.NickName;
            tbMiddleName.Text = _rcdata.MiddleName;
            tbLastName.Text = _rcdata.LastName;
            tbSuffix.Text = _rcdata.Suffix;
            if (_rcdata.Birthday > Convert.ToDateTime("1/1/1901"))
            {
                dtbBirthday.Text = _rcdata.Birthday.ToShortDateString();
            }
            if (_rcdata.SSN.Length >= 9)
            {
                tbSSN1.Text = _rcdata.SSN.Substring(0, 3);
                tbSSN2.Text = _rcdata.SSN.Substring(3, 2);
                tbSSN3.Text = _rcdata.SSN.Substring(5, 4);
            }
            tbSchoolDistrict.Text = _rcdata.SchoolDistrict;
            ddlGender.SelectedValue = _rcdata.Gender;
            if (_rcdata.LastDateWorked > Convert.ToDateTime("1/1/1901"))
            {
                dtbLastWorked.Text = _rcdata.LastDateWorked.ToShortDateString();
            }
            ddlEMStatus.SelectedValue = _rcdata.MaritalStatus.ToString();
            ddlCounty.Text = _rcdata.County;

            cbInfoMentalIllness.Checked = ((_rcdata.IssuesOfNote & 1) > 0);
            cbInfoDomestic.Checked = ((_rcdata.IssuesOfNote & 8) > 0);
            cbInfoDisabled.Checked = ((_rcdata.IssuesOfNote & 2) > 0);
            cbInfoAddiction.Checked = ((_rcdata.IssuesOfNote & 16) > 0);
            cbInfoVeteran.Checked = ((_rcdata.IssuesOfNote & 4) > 0);

            tbEmail.Text = _rcdata.Email;
            tbPhoneHome.Text = _rcdata.PhoneHome;
            tbPhoneMobile.Text = _rcdata.PhoneWork;
            tbPhoneMobile.Text = _rcdata.PhoneMobile;
            tbPhoneOther.Text = _rcdata.PhoneOther;

            tbIncomeEmployment.Text = String.Format("{0:0.00}", _rcdata.IncomeEmployment);
            tbIncomeUnemployment.Text = String.Format("{0:0.00}", _rcdata.IncomeUnemployment);
            tbIncomeMFIP.Text = String.Format("{0:0.00}", _rcdata.IncomeMFIP);
            tbIncomeSSISSDI.Text = String.Format("{0:0.00}", _rcdata.IncomeSSISSDI);
            tbIncomeChildSupport.Text = String.Format("{0:0.00}", _rcdata.IncomeChildSupport);
            //tbIncomeMA.Text = String.Format("{0:0.00}", _rcdata.IncomeMA);
            if (_rcdata.IncomeMA != 0)
            {
                chkEMA.Checked = true;
            }
            else
            {
                chkEMA.Checked = false;
            }
            tbIncomeOtherSources.Text = String.Format("{0:0.00}", _rcdata.IncomeOther);
            tbCashOnHand.Text = String.Format("{0:0.00}", _rcdata.CashOnHand);

            cbComputer.Checked = ((_rcdata.HelpRequested & 1) > 0);
            cbFood.Checked = ((_rcdata.HelpRequested & 2) > 0);
            cbHoliday.Checked = ((_rcdata.HelpRequested & 4) > 0);
            cbHousing.Checked = ((_rcdata.HelpRequested & 8) > 0);
            cbInternet.Checked = ((_rcdata.HelpRequested & 16) > 0);
            cbJobRelated.Checked = ((_rcdata.HelpRequested & 32) > 0);
            cbOther.Checked = ((_rcdata.HelpRequested & 64) > 0);
            cbOtherBasic.Checked = ((_rcdata.HelpRequested & 128) > 0);
            cbTax.Checked = ((_rcdata.HelpRequested & 256) > 0);
            cbSchoolSupplies.Checked = ((_rcdata.HelpRequested & 512) > 0);
            cbCoats.Checked = ((_rcdata.HelpRequested & 1024) > 0);
            cbShelter.Checked = ((_rcdata.HelpRequested & 2048) > 0);
            cbHealthCare.Checked = ((_rcdata.HelpRequested & 4096) > 0);

            tbFoodSupportAmount.Text = String.Format("{0:0.00}", _rcdata.FoodSupport);
            cbLicense.Checked = (_rcdata.DriversLicense > 0);
            cbEBT.Checked = (_rcdata.EBT > 0);
            if (_rcdata.AssistanceApplied > Convert.ToDateTime("1/1/1901"))
            {
                dtbAssistanceRequested.Text = _rcdata.AssistanceApplied.ToShortDateString();
            }
            tbFoodShelf.Text = _rcdata.FoodShelf;
            if (_rcdata.FoodShelfVisit > Convert.ToDateTime("1/1/1901"))
            {
                dtbFoodShelfVisit.Text = _rcdata.FoodShelfVisit.ToShortDateString();
            }

            cbSheltered.Checked = (_rcdata.PastShelter > 0);
            if (_rcdata.PastShelterDate > Convert.ToDateTime("1/1/1901"))
            {
                dtbShelteredDate.Text = _rcdata.PastShelterDate.ToShortDateString();
            }
            cbUnsheltered.Checked = (_rcdata.PastUnsheltered > 0);
            if (_rcdata.PastUnshelteredDate > Convert.ToDateTime("1/1/1901"))
            {
                dtbUnshelteredDate.Text = _rcdata.PastUnshelteredDate.ToShortDateString();
            }
            cbEviction.Checked = (_rcdata.PastEviction > 0);
            if (_rcdata.PastEvictionDate > Convert.ToDateTime("1/1/1901"))
            {
                dtbEvictionDate.Text = _rcdata.PastEvictionDate.ToShortDateString();
            }
            cbForeclosure.Checked = (_rcdata.PastForeclosure > 0);
            if (_rcdata.PastForeclosureDate > Convert.ToDateTime("1/1/1901"))
            {
                dtbForeclosureDate.Text = _rcdata.PastForeclosureDate.ToShortDateString();
            }
            cbTransitional.Checked = (_rcdata.PastTransitional > 0);
            if (_rcdata.PastTransitionalDate > Convert.ToDateTime("1/1/1901"))
            {
                dtbTransitionalDate.Text = _rcdata.PastTransitionalDate.ToShortDateString();
            }
            cbDoubled.Checked = (_rcdata.PastDoubled > 0);
            if (_rcdata.PastDoubledDate > Convert.ToDateTime("1/1/1901"))
            {
                dtbDoubledDate.Text = _rcdata.PastDoubledDate.ToShortDateString();
            }
            cbChemical.Checked = (_rcdata.PastChemical > 0);
            if (_rcdata.PastChemicalDate > Convert.ToDateTime("1/1/1901"))
            {
                dtbChemicalDate.Text = _rcdata.PastChemicalDate.ToShortDateString();
            }

            tbCaseManager1.Text = _rcdata.CaseMgr1Name;
            tbAgency1.Text = _rcdata.CaseMgr1Agency;
            tbPhone1.Text = _rcdata.CaseMgr1Phone;
            tbNotes1.Text = _rcdata.CaseMgr1Notes;
            tbCaseManager2.Text = _rcdata.CaseMgr2Name;
            tbAgency2.Text = _rcdata.CaseMgr2Agency;
            tbPhone2.Text = _rcdata.CaseMgr2Phone;
            tbNotes2.Text = _rcdata.CaseMgr2Notes;

            tbEAngency1.Text = _rcdata.EmgAssist1Agency;
            tbECaseManager1.Text = _rcdata.EmgAssist1CaseMgr;
            tbEPhone1.Text = _rcdata.EmgAssist1Phone;
            if (_rcdata.EmgAssist1Date > Convert.ToDateTime("1/1/1901"))
            {
                dtbEDate1.Text = _rcdata.EmgAssist1Date.ToShortDateString();
            }
            tbEAmount1.Text = String.Format("{0:0.00}", _rcdata.EmgAssist1Amount);
            ddlEStatus1.SelectedValue = _rcdata.EmgAssist1Status.ToString();

            tbEAgency2.Text = _rcdata.EmgAssist2Agency;
            tbECaseManager2.Text = _rcdata.EmgAssist2CaseMgr;
            tbEPhone2.Text = _rcdata.EmgAssist2Phone;
            if (_rcdata.EmgAssist2Date > Convert.ToDateTime("1/1/1901"))
            {
                dtbEDate2.Text = _rcdata.EmgAssist2Date.ToShortDateString();
            }
            tbEAmount2.Text = String.Format("{0:0.00}", _rcdata.EmgAssist2Amount);
            ddlEStatus2.SelectedValue = _rcdata.EmgAssist2Status.ToString();

            tbNotes.Text = _rcdata.Notes;

            lblCreated.Text = _rcdata.DateCreated.Date.ToShortDateString();
            lblCreatedBy.Text = "by " + _rcdata.CreatedBy;
            lblModified.Text = _rcdata.DateUpdated.Date.ToShortDateString();
            lblModifiedBy.Text = "by " + _rcdata.UpdatedBy;

            tbState.Text = _rcdata.State;
            tbCity.Text = _rcdata.City;
            tbStreet.Text = _rcdata.StreetAddress;
            tbZip.Text = _rcdata.PostalCode;

            ddlEBGC.SelectedValue = _rcdata.NumChildren.ToString();

            bool pastShelter = ((_rcdata.LastShelter != DateTime.MinValue) && (_rcdata.LastShelterExit > Convert.ToDateTime("1/1/1901") && (_rcdata.LastShelterExit <= DateTime.Today)));
            if ((_rcdata.NumAdults & 1) > 0)
            {
                chkEB2B.ForeColor = System.Drawing.Color.Green;
                chkEB2B.Checked = true;
            }
            else
            {
                if (_rcdata.DateCreated > Convert.ToDateTime("1/1/1901"))
                {
                    chkEB2B.ForeColor = System.Drawing.Color.Red;
                    chkEB2B.Text = "B2B (" + (DateTime.Now - _rcdata.DateCreated).Days + " days overdue)";
                    ddlEBGC.SelectedValue = _rcdata.NumChildren.ToString();
                }
                else
                {
                    chkEB2B.Visible = false;
                    lblEBGC.Visible = false;
                    ddlEBGC.Visible = false;
                }
            }

            if (_rcdata.LastShelter > DateTime.MinValue)
            {
                chkEHMIS.Visible = true;
                chkEIntake.Visible = true;

                if ((_rcdata.NumAdults & 2) > 0)
                {
                    chkEHMIS.ForeColor = System.Drawing.Color.Green;
                    chkEHMIS.Checked = true;
                }
                else
                {
                    chkEHMIS.ForeColor = System.Drawing.Color.Red;
                    chkEHMIS.Text = "HMIS (" + (DateTime.Now - _rcdata.LastShelter).Days + " days overdue)";
                }

                if ((_rcdata.NumAdults & 4) > 0)
                {
                    chkEIntake.ForeColor = System.Drawing.Color.Green;
                    chkEIntake.Checked = true;
                }
                else
                {
                    chkEIntake.ForeColor = System.Drawing.Color.Red;
                    chkEIntake.Text = "Intake (" + (DateTime.Now - _rcdata.LastShelter).Days + " days overdue)";
                }

                if (_rcdata.NumChildren == 0)
                {
                    lblEBGC.ForeColor = System.Drawing.Color.Red;
                }
                else
                {
                    lblEBGC.ForeColor = System.Drawing.Color.Empty;
                }
            }
            else
            {
                if (pastShelter)
                {
                    chkEHMIS.ForeColor = System.Drawing.Color.Empty;
                    chkEHMIS.Text = "HMIS";
                    if ((_rcdata.NumAdults & 2) > 0)
                        chkEHMIS.Checked = true;

                    chkEIntake.ForeColor = System.Drawing.Color.Empty;
                    chkEIntake.Text = "Intake";
                    if ((_rcdata.NumAdults & 4) > 0)
                        chkEIntake.Checked = true;
                }
                else
                {
                    chkEHMIS.Visible = false;
                    chkEIntake.Visible = false;
                }
            }

            if ((_rcdata.LastShelterExit > DateTime.MinValue) && (_rcdata.LastShelterExit > _rcdata.LastShelter) && (_rcdata.LastShelterExit <= DateTime.Today))
            {
                chkEExit.Visible = true;

                if ((_rcdata.NumAdults & 8) > 0)
                {
                    chkEExit.ForeColor = System.Drawing.Color.Green;
                    chkEExit.Checked = true;
                }
                else
                {
                    chkEExit.ForeColor = System.Drawing.Color.Red;
                    chkEExit.Text = "Exit (" + (DateTime.Now - _rcdata.LastShelterExit).Days + " days overdue)";
                }
            }
            else
            {
                if (pastShelter)
                {
                    chkEExit.ForeColor = System.Drawing.Color.Empty;
                    chkEExit.Text = "Exit";
                    if ((_rcdata.NumAdults & 8) > 0)
                        chkEExit.Checked = true;
                }
                else
                {
                    chkEExit.Visible = false;
                }
            }

            if ((_rcdata.LastShelterExit > DateTime.MinValue) && (_rcdata.LastShelterExit > _rcdata.LastShelter) &&
                ((_rcdata.LastShelterExit - _rcdata.LastShelter).Days >= 30) && ((DateTime.Now - _rcdata.LastShelter).Days >= 30))
            {
                chkE30Day.Visible = true;

                if ((_rcdata.NumAdults & 16) > 0)
                {
                    chkE30Day.ForeColor = System.Drawing.Color.Green;
                    chkE30Day.Checked = true;
                }
                else
                {
                    chkE30Day.ForeColor = System.Drawing.Color.Red;
                    chkE30Day.Text = "30 Day (" + ((DateTime.Now - _rcdata.LastShelter).Days - 30) + " days overdue)";
                }
            }
            else
            {
                if (pastShelter)
                {
                    chkE30Day.Visible = true;
                    chkE30Day.ForeColor = System.Drawing.Color.Empty;
                    chkE30Day.Text = "30 Day";
                    if ((_rcdata.NumAdults & 16) > 0)
                        chkE30Day.Checked = true;
                }
                else
                {
                    chkE30Day.Visible = false;
                }
            }

            if ((_rcdata.LastShelterExit > DateTime.MinValue) && (_rcdata.LastShelterExit > _rcdata.LastShelter) &&
                ((_rcdata.LastShelterExit - _rcdata.LastShelter).Days >= 30) && ((DateTime.Now - _rcdata.LastShelter).Days >= 180))
            {
                chkE6Month.Visible = true;

                if ((_rcdata.NumAdults & 32) > 0)
                {
                    chkE6Month.ForeColor = System.Drawing.Color.Green;
                    chkE6Month.Checked = true;
                }
                else
                {
                    chkE6Month.ForeColor = System.Drawing.Color.Red;
                    chkE6Month.Text = "6 Month (" + ((DateTime.Now - _rcdata.LastShelter).Days - 180) + " days overdue)";
                }
            }
            else
            {
                if (pastShelter)
                {
                    chkE6Month.Visible = true;
                    chkE6Month.ForeColor = System.Drawing.Color.Empty;
                    chkE6Month.Text = "6 Month";
                    if ((_rcdata.NumAdults & 32) > 0)
                        chkE6Month.Checked = true;
                }
                else
                {
                    chkE6Month.Visible = false;
                }
            }

            if ((_rcdata.LastShelterExit > DateTime.MinValue) && (_rcdata.LastShelterExit > _rcdata.LastShelter) &&
                ((_rcdata.LastShelterExit - _rcdata.LastShelter).Days >= 30) && ((DateTime.Now - _rcdata.LastShelter).Days >= 365))
            {
                chkE1Year.Visible = true;

                if ((_rcdata.NumAdults & 64) > 0)
                {
                    chkE1Year.ForeColor = System.Drawing.Color.Green;
                    chkE1Year.Checked = true;
                }
                else
                {
                    chkE1Year.ForeColor = System.Drawing.Color.Red;
                    chkE1Year.Text = "1 Year (" + ((DateTime.Now - _rcdata.LastShelter).Days - 365) + " days overdue)";
                }
            }
            else
            {
                if (pastShelter)
                {
                    chkE1Year.Visible = true;
                    chkE1Year.ForeColor = System.Drawing.Color.Empty;
                    chkE1Year.Text = "1 Year";
                    if ((_rcdata.NumAdults & 64) > 0)
                        chkE1Year.Checked = true;
                }
                else
                {
                    chkE1Year.Visible = false;
                }
            }

            ddlEFinEmploymentFrequency.SelectedValue = _rcdata.EmploymentFrequency.ToString();
            dtbEFinEmployment.Text = (_rcdata.EmploymentDate > Convert.ToDateTime("1/1/1901") ? _rcdata.EmploymentDate.ToShortDateString() : "");
            tbEFinMFIP.Text = _rcdata.MFIPDay.ToString();
            dtbEFinChildSupport.Text = (_rcdata.ChildSupportDate > Convert.ToDateTime("1/1/1901") ? _rcdata.ChildSupportDate.ToShortDateString() : "");
            dtbEFinOtherSources.Text = (_rcdata.OtherSourcesDate > Convert.ToDateTime("1/1/1901") ? _rcdata.OtherSourcesDate.ToShortDateString() : "");
        }

        protected string CreateDateString(DateTime d)
        {
            if (d > Convert.ToDateTime("1/1/1901"))
            {
                return d.ToShortDateString();
            }
            else
            {
                return "Unknown Date";
            }
        }

        protected void BindViewData()
        {
            SetPageDescription("Client Details: <strong>" + _rcdata.FirstName + " " + _rcdata.LastName + "</strong>");
            if (_personId != -1)
            {
                _rcdata = new ResourceCenterPerson(_personId);
            }

            if (_rcdata.Message != "")
            {
                lMessage.Text = "<span class=\"pageTitle\" style=\"color: Red;\"><strong>" + _rcdata.Message + "</strong></span><br /><br />\n";
            }
            else
            {
                lMessage.Text = "";
            }
            string name = _rcdata.FirstName + " ";
            if (_rcdata.NickName != "")
            {
                name += "(" + _rcdata.NickName + ") ";
            }
            name += _rcdata.MiddleName + " " + _rcdata.LastName;
            if (_rcdata.Suffix != "")
            {
                name += " " + _rcdata.Suffix;
            }
            lblVName.Text = name;

            if (_rcdata.Birthday > Convert.ToDateTime("1/1/1901"))
            {
                lblVDOB.Text = _rcdata.Birthday.ToShortDateString();
            }
            lblVCounty.Text = _rcdata.County;
            lblVNotes.Text = _rcdata.Notes;
            lblVCreated.Text = _rcdata.DateCreated.Date.ToShortDateString();
            lblVCreatedBy.Text = "by " + _rcdata.CreatedBy;
            lblVModified.Text = _rcdata.DateUpdated.Date.ToShortDateString();
            lblVModifiedBy.Text = "by " + _rcdata.UpdatedBy;
            string s = "";
            if ((_rcdata.HelpRequested & 1) > 0)
            {
                s += "Utilities<br />";
            }
            if ((_rcdata.HelpRequested & 2) > 0)
            {
                s += "Food<br />";
            }
            if ((_rcdata.HelpRequested & 4) > 0)
            {
                s += "Holiday<br />";
            }
            if ((_rcdata.HelpRequested & 8) > 0)
            {
                s += "Transportation<br />";
            }
            if ((_rcdata.HelpRequested & 16) > 0)
            {
                s += "Internet Access<br />";
            }
            if ((_rcdata.HelpRequested & 32) > 0)
            {
                s += "Job Related<br />";
            }
            if ((_rcdata.HelpRequested & 64) > 0)
            {
                s += "Other<br />";
            }
            if ((_rcdata.HelpRequested & 128) > 0)
            {
                s += "Basic Household Needs<br />";
            }
            if ((_rcdata.HelpRequested & 256) > 0)
            {
                s += "Tax Prep/Budget<br />";
            }
            if ((_rcdata.HelpRequested & 512) > 0)
            {
                s += "Child Care<br />";
            }
            if ((_rcdata.HelpRequested & 1024) > 0)
            {
                s += "Coat/Jacket<br />";
            }
            if ((_rcdata.HelpRequested & 2048) > 0)
            {
                s += "Shelter<br />";
            }
            if ((_rcdata.HelpRequested & 4096) > 0)
            {
                s += "Health Care Referral<br />";
            }
            if (s.Length > 0)
            {
                s = s.Substring(0, s.Length - 6);
            }
            lblVHelp.Text = s;

            string mstatus = string.Empty;
            switch (_rcdata.MaritalStatus)
            {
                case 0:
                    mstatus = "Unknown";
                    break;
                case 1:
                    mstatus = "Single";
                    break;
                case 2:
                    mstatus = "Married";
                    break;
                case 3:
                    mstatus = "Partnered";
                    break;
                case 4:
                    mstatus = "Divorced";
                    break;
                case 5:
                    mstatus = "Widowed";
                    break;
                default:
                    mstatus = "Error " + _rcdata.MaritalStatus.ToString();
                    break;
            }
            lblVMaritalStatus.Text = mstatus;
            if (_rcdata.SSN.Length >= 9)
            {
                lblSSN.Text = " " + _rcdata.SSN.Substring(0, 3) + "-" + _rcdata.SSN.Substring(3, 2) + "-" + _rcdata.SSN.Substring(5, 4);
            }

            if (_rcdata.Gender == "M")
            {
                lblVGender.Text = "Male";
            }
            else if (_rcdata.Gender == "F")
            {
                lblVGender.Text = "Female";
            }
            else
            {
                lblVGender.Text = "Unknown";
            }

            string ion = string.Empty;
            if ((_rcdata.IssuesOfNote & 1) > 0)
            {
                ion += "Mental Illness<br />";
            }
            if ((_rcdata.IssuesOfNote & 2) > 0)
            {
                ion += "Disabled<br />";
            }
            if ((_rcdata.IssuesOfNote & 4) > 0)
            {
                ion += "Veteran<br />";
            }
            if ((_rcdata.IssuesOfNote & 8) > 0)
            {
                ion += "Domestic<br />";
            }
            if ((_rcdata.IssuesOfNote & 16) > 0)
            {
                ion += "Addiction<br />";
            }
            lblVIssues.Text = ion;

            //lblVIncome.Text = "$" + String.Format("{0:0.00}", _rcdata.IncomeChildSupport + _rcdata.IncomeEmployment + _rcdata.IncomeMA + _rcdata.IncomeMFIP + _rcdata.IncomeOther + _rcdata.IncomeSSISSDI + _rcdata.IncomeUnemployment);
            lblVIncome.Text = "$" + String.Format("{0:0.00}", _rcdata.IncomeChildSupport + _rcdata.IncomeEmployment + _rcdata.IncomeMFIP + _rcdata.IncomeOther + _rcdata.IncomeSSISSDI + _rcdata.IncomeUnemployment);
            lblVPhoneHome.Text = _rcdata.PhoneHome;
            lblVPhoneMobile.Text = _rcdata.PhoneMobile;
            lblVPhoneOther.Text = _rcdata.PhoneOther;
            lblVPhoneWork.Text = _rcdata.PhoneWork;
            if (_rcdata.Email != "")
            {
                lblVEmail.Text = "<a href=\"mailto:" + _rcdata.Email + "\">" + _rcdata.Email + "</a>";
            }
            else
            {
                lblVEmail.Text = "";
            }

            pCM_None.Visible = true;
            pCM1.Visible = false;
            pCM2.Visible = false;
            if ((_rcdata.CaseMgr1Name != "") || (_rcdata.CaseMgr1Agency != ""))
            {
                pCM_None.Visible = false;
                pCM1.Visible = true;
                lblCM1Agency.Text = _rcdata.CaseMgr1Agency;
                lblCM1Case.Text = _rcdata.CaseMgr1Name;
                lblCM1Phone.Text = _rcdata.CaseMgr1Phone;
                lblCM1Notes.Text = _rcdata.CaseMgr1Notes;
            }
            if ((_rcdata.CaseMgr2Name != "") || (_rcdata.CaseMgr2Agency != ""))
            {
                pCM_None.Visible = false;
                pCM2.Visible = true;
                lblCM2Agency.Text = _rcdata.CaseMgr2Agency;
                lblCM2Case.Text = _rcdata.CaseMgr2Name;
                lblCM2Phone.Text = _rcdata.CaseMgr2Phone;
                lblCM2Notes.Text = _rcdata.CaseMgr2Notes;
            }

            pEmg_None.Visible = true;
            pEmg1.Visible = false;
            pEmg2.Visible = false;
            if ((_rcdata.EmgAssist1Agency != "") || (_rcdata.EmgAssist1CaseMgr != ""))
            {
                pEmg_None.Visible = false;
                pEmg1.Visible = true;
                lblEmg1Agency.Text = _rcdata.EmgAssist1Agency;
                lblEmg1CaseMgr.Text = _rcdata.EmgAssist1CaseMgr;
                lblEmg1Phone.Text = _rcdata.EmgAssist1Phone;
                if (_rcdata.EmgAssist1Date > Convert.ToDateTime("1/1/1901"))
                {
                    lblEmg1Date.Text = _rcdata.EmgAssist1Date.ToShortDateString();
                }
                lblEmg1Amount.Text = String.Format("{0:0.00}", _rcdata.EmgAssist1Amount);
                switch (_rcdata.EmgAssist1Status)
                {
                    case 0:
                        lblEmg1Status.Text = "Unknown";
                        break;
                    case 1:
                        lblEmg1Status.Text = "Pending";
                        break;
                    case 2:
                        lblEmg1Status.Text = "Approved";
                        break;
                    case 3:
                        lblEmg1Status.Text = "Denied";
                        break;
                    default:
                        lblEmg1Status.Text = "Error " + _rcdata.EmgAssist1Status.ToString();
                        break;
                }
            }
            if ((_rcdata.EmgAssist2Agency != "") || (_rcdata.EmgAssist2CaseMgr != ""))
            {
                pEmg_None.Visible = false;
                pEmg2.Visible = true;
                lblEmg2Agency.Text = _rcdata.EmgAssist2Agency;
                lblEmg2CaseMgr.Text = _rcdata.EmgAssist2CaseMgr;
                lblEmg2Phone.Text = _rcdata.EmgAssist2Phone;
                if (_rcdata.EmgAssist2Date > Convert.ToDateTime("1/1/1901"))
                {
                    lblEmg2Date.Text = _rcdata.EmgAssist2Date.ToShortDateString();
                }
                lblEmg2Amount.Text = String.Format("{0:0.00}", _rcdata.EmgAssist2Amount);
                switch (_rcdata.EmgAssist2Status)
                {
                    case 0:
                        lblEmg2Status.Text = "Unknown";
                        break;
                    case 1:
                        lblEmg2Status.Text = "Pending";
                        break;
                    case 2:
                        lblEmg2Status.Text = "Approved";
                        break;
                    case 3:
                        lblEmg2Status.Text = "Denied";
                        break;
                    default:
                        lblEmg2Status.Text = "Error " + _rcdata.EmgAssist2Status.ToString();
                        break;
                }
            }

            string hist = string.Empty;
            string hisd = string.Empty;
            if (_rcdata.PastShelter > 0)
            {
                hist += "Shelter<br />";
                hisd += CreateDateString(_rcdata.PastShelterDate) + "<br />";
            }
            if (_rcdata.PastUnsheltered > 0)
            {
                hist += "Unsheltered<br />";
                hisd += CreateDateString(_rcdata.PastUnshelteredDate) + "<br />";
            }
            if (_rcdata.PastChemical > 0)
            {
                hist += "Addiction<br />";
                hisd += CreateDateString(_rcdata.PastChemicalDate) + "<br />";
            }
            if (_rcdata.PastTransitional > 0)
            {
                hist += "Transitional<br />";
                hisd += CreateDateString(_rcdata.PastTransitionalDate) + "<br />";
            }
            if (_rcdata.PastDoubled > 0)
            {
                hist += "Doubled<br />";
                hisd += CreateDateString(_rcdata.PastDoubledDate) + "<br />";
            }
            if (_rcdata.PastEviction > 0)
            {
                hist += "Eviction<br />";
                hisd += CreateDateString(_rcdata.PastEvictionDate) + "<br />";
            }
            if (_rcdata.PastForeclosure > 0)
            {
                hist += "Foreclosure<br />";
                hisd += CreateDateString(_rcdata.PastForeclosureDate) + "<br />";
            }
            if (hist.Length > 0)
            {
                hist = hist.Substring(0, hist.Length - 6);
            }
            if (hisd.Length > 0)
            {
                hisd = hisd.Substring(0, hisd.Length - 6);
            }
            lblVHistory.Text = hist;
            lblVHistoryDate.Text = hisd;

            lblVSchoolDistrict.Text = _rcdata.SchoolDistrict;
            lblVFoodSupport.Text = "$" + String.Format("{0:0.00}", _rcdata.FoodSupport);

            lblVCashOnHand.Text = "$" + String.Format("{0:0.00}", _rcdata.CashOnHand);
            if (_rcdata.EBT > 0)
            {
                lblVEBT.Text = "Yes";
                //lblVEBT.ForeColor = System.Drawing.Color.Black;
            }
            else
            {
                lblVEBT.Text = "No";
                lblVEBT.ForeColor = System.Drawing.Color.Red;
            }

            if (_rcdata.IncomeMA > 0)
            {
                lblVMA.Text = "Yes";
            }
            else
            {
                lblVMA.Text = "No";
                lblVEBT.ForeColor = System.Drawing.Color.Red;
            }

            if (_rcdata.DriversLicense > 0)
            {
                lblVLicense.Text = "Yes";
                //lblVLicense.ForeColor = System.Drawing.Color.Black;
            }
            else
            {
                lblVLicense.Text = "No";
                lblVLicense.ForeColor = System.Drawing.Color.Red;
            }

            if (_rcdata.AssistanceApplied > Convert.ToDateTime("1/1/1901"))
            {
                lblVAssistanceApplied.Text = "Yes " + _rcdata.AssistanceApplied.ToShortDateString();
            }
            else
            {
                lblVAssistanceApplied.Text = "No";
            }

            string fs = string.Empty;
            if (_rcdata.FoodShelf != "")
            {
                fs += _rcdata.FoodShelf + " (";
                if (_rcdata.FoodShelfVisit > Convert.ToDateTime("1/1/1901"))
                {
                    fs += _rcdata.FoodShelfVisit.ToShortDateString() + ")";
                }
                else
                {
                    fs += "Unknown)";
                }
            }
            else
            {
                fs += "No";
            }
            lblVFoodShelf.Text = fs;

            if (_rcdata.LastDateWorked > Convert.ToDateTime("1/1/1901"))
            {
                lblVLastDateWorked.Text = _rcdata.LastDateWorked.ToShortDateString();
            }
            else
            {
                lblVLastDateWorked.Text = "Unspecified";
            }

            lblVStreet.Text = _rcdata.StreetAddress;
            lblVCity.Text = _rcdata.City;
            lblVZip.Text = _rcdata.PostalCode;
            lblVState.Text = _rcdata.State;

            lblVBGC.ForeColor = System.Drawing.Color.Empty;
            switch (_rcdata.NumChildren)
            {
                case 0:
                    lblVBGCStatus.Text = "Unknown";
                    lblVBGCStatus.ForeColor = System.Drawing.Color.Empty;
                    break;
                case 1:
                    lblVBGCStatus.Text = "CLEARED";
                    lblVBGCStatus.ForeColor = System.Drawing.Color.Green;
                    break;
                case 2:
                    lblVBGCStatus.Text = "FAILED";
                    lblVBGCStatus.ForeColor = System.Drawing.Color.Red;
                    break;
                default:
                    lblVBGCStatus.Text = "Error " + _rcdata.NumChildren.ToString();
                    break;
            }

            if ((_rcdata.NumAdults & 1) > 0)
            {
                lblVB2B.ForeColor = System.Drawing.Color.Green;
            }
            else
            {
                lblVB2B.ForeColor = System.Drawing.Color.Red;
                lblVB2B.Text = "B2B (" + (DateTime.Now - _rcdata.DateCreated).Days + " days overdue)";
            }

            if (_rcdata.LastShelter > DateTime.MinValue)
            {
                lblVHMIS.Visible = true;
                lblVIntake.Visible = true;

                if ((_rcdata.NumAdults & 2) > 0)
                {
                    lblVHMIS.ForeColor = System.Drawing.Color.Green;
                }
                else
                {
                    lblVHMIS.ForeColor = System.Drawing.Color.Red;
                    lblVHMIS.Text = "HMIS (" + (DateTime.Now - _rcdata.LastShelter).Days + " days overdue)";
                }

                if ((_rcdata.NumAdults & 4) > 0)
                {
                    lblVIntake.ForeColor = System.Drawing.Color.Green;
                }
                else
                {
                    lblVIntake.ForeColor = System.Drawing.Color.Red;
                    lblVIntake.Text = "Intake (" + (DateTime.Now - _rcdata.LastShelter).Days + " days overdue)";
                }

                if (_rcdata.NumChildren == 0)
                {
                    lblVBGC.ForeColor = System.Drawing.Color.Red;
                    lblVBGCStatus.ForeColor = System.Drawing.Color.Red;
                }
            }
            else
            {
                if ((_rcdata.NumAdults & 2) > 0)
                {
                    lblVHMIS.Visible = true;
                    lblVHMIS.ForeColor = System.Drawing.Color.Empty;
                    lblVHMIS.Text = "HMIS";
                }
                else
                {
                    lblVHMIS.Visible = false;
                }

                if ((_rcdata.NumAdults & 4) > 0)
                {
                    lblVIntake.Visible = true;
                    lblVIntake.ForeColor = System.Drawing.Color.Empty;
                    lblVIntake.Text = "Intake";
                }
                else
                {
                    lblVIntake.Visible = false;
                }
            }

            if ((_rcdata.LastShelterExit > DateTime.MinValue) && (_rcdata.LastShelterExit > _rcdata.LastShelter) && (_rcdata.LastShelterExit <= DateTime.Today))
            {
                lblVExit.Visible = true;

                if ((_rcdata.NumAdults & 8) > 0)
                {
                    lblVExit.ForeColor = System.Drawing.Color.Green;
                }
                else
                {
                    lblVExit.ForeColor = System.Drawing.Color.Red;
                    lblVExit.Text = "Exit (" + (DateTime.Now - _rcdata.LastShelterExit).Days + " days overdue)";
                }
            }
            else
            {
                if ((_rcdata.NumAdults & 8) > 0)
                {
                    lblVExit.Visible = true;
                    lblVExit.ForeColor = System.Drawing.Color.Empty;
                    lblVExit.Text = "Exit";
                }
                else
                {
                    lblVExit.Visible = false;
                }
            }

            if ((_rcdata.LastShelterExit > DateTime.MinValue) && (_rcdata.LastShelterExit > _rcdata.LastShelter) &&
                ((_rcdata.LastShelterExit - _rcdata.LastShelter).Days >= 30) && ((DateTime.Now - _rcdata.LastShelter).Days >= 30))
            {
                lblV30Day.Visible = true;

                if ((_rcdata.NumAdults & 16) > 0)
                {
                    lblV30Day.ForeColor = System.Drawing.Color.Green;
                }
                else
                {
                    lblV30Day.ForeColor = System.Drawing.Color.Red;
                    lblV30Day.Text = "30 Day (" + ((DateTime.Now - _rcdata.LastShelter).Days - 30) + " days overdue)";
                }
            }
            else
            {
                if ((_rcdata.NumAdults & 16) > 0)
                {
                    lblV30Day.Visible = true;
                    lblV30Day.ForeColor = System.Drawing.Color.Empty;
                    lblV30Day.Text = "30 Day";
                }
                else
                {
                    lblV30Day.Visible = false;
                }
            }

            if ((_rcdata.LastShelterExit > DateTime.MinValue) && (_rcdata.LastShelterExit > _rcdata.LastShelter) &&
                ((_rcdata.LastShelterExit - _rcdata.LastShelter).Days >= 30) && ((DateTime.Now - _rcdata.LastShelter).Days >= 180))
            {
                lblV6Month.Visible = true;

                if ((_rcdata.NumAdults & 32) > 0)
                {
                    lblV6Month.ForeColor = System.Drawing.Color.Green;
                }
                else
                {
                    lblV6Month.ForeColor = System.Drawing.Color.Red;
                    lblV6Month.Text = "6 Month (" + ((DateTime.Now - _rcdata.LastShelter).Days - 180) + " days overdue)";
                }
            }
            else
            {
                if ((_rcdata.NumAdults & 32) > 0)
                {
                    lblV6Month.Visible = true;
                    lblV6Month.ForeColor = System.Drawing.Color.Empty;
                    lblV6Month.Text = "6 Month";
                }
                else
                {
                    lblV6Month.Visible = false;
                }
            }

            if ((_rcdata.LastShelterExit > DateTime.MinValue) && (_rcdata.LastShelterExit > _rcdata.LastShelter) &&
                ((_rcdata.LastShelterExit - _rcdata.LastShelter).Days >= 30) && ((DateTime.Now - _rcdata.LastShelter).Days >= 365))
            {
                lblV1Year.Visible = true;

                if ((_rcdata.NumAdults & 64) > 0)
                {
                    lblV1Year.ForeColor = System.Drawing.Color.Green;
                }
                else
                {
                    lblV1Year.ForeColor = System.Drawing.Color.Red;
                    lblV1Year.Text = "1 Year (" + ((DateTime.Now - _rcdata.LastShelter).Days - 365) + " days overdue)";
                }
            }
            else
            {
                if ((_rcdata.NumAdults & 64) > 0)
                {
                    lblV1Year.Visible = true;
                    lblV1Year.ForeColor = System.Drawing.Color.Empty;
                    lblV1Year.Text = "1 Year";
                }
                else
                {
                    lblV1Year.Visible = false;
                }
            }
        }

        protected void SaveButton_Click(object sender, EventArgs e)
        {
            pConflicts.Visible = false;

            if (Page.IsValid)
            {
                ResourceCenterPerson rc = null;
                rc = new ResourceCenterPerson(_personId);
                rc.Message = tbEMessage.Text;
                int hf = 0;
                if (cbComputer.Checked)
                {
                    hf += 1;
                }
                if (cbFood.Checked)
                {
                    hf += 2;
                }
                if (cbHoliday.Checked)
                {
                    hf += 4;
                }
                if (cbHousing.Checked)
                {
                    hf += 8;
                }
                if (cbInternet.Checked)
                {
                    hf += 16;
                }
                if (cbJobRelated.Checked)
                {
                    hf += 32;
                }
                if (cbOther.Checked)
                {
                    hf += 64;
                }
                if (cbOtherBasic.Checked)
                {
                    hf += 128;
                }
                if (cbTax.Checked)
                {
                    hf += 256;
                }
                if (cbSchoolSupplies.Checked)
                {
                    hf += 512;
                }
                if (cbCoats.Checked)
                {
                    hf += 1024;
                }
                if (cbShelter.Checked)
                {
                    hf += 2048;
                }
                rc.HelpRequested = hf;
                rc.County = ddlCounty.Text;
                //rc.NumAdults = Convert.ToInt32(tbAdults.Text);
                //rc.NumAdults = 0;
                //rc.NumChildren = Convert.ToInt32(tbChildren.Text);
                //rc.NumChildren = 0;
                rc.Notes = tbNotes.Text;
                rc.NickName = tbNickName.Text;
                rc.FirstName = tbFirstName.Text;
                rc.MiddleName = tbMiddleName.Text;
                rc.LastName = tbLastName.Text;
                rc.Suffix = tbSuffix.Text;
                if (dtbBirthday.Text != "")
                {
                    rc.Birthday = Convert.ToDateTime(dtbBirthday.Text);
                }
                else
                {
                    rc.Birthday = Convert.ToDateTime("1/1/1901");
                }
                rc.Gender = ddlGender.SelectedValue;
                rc.Email = tbEmail.Text;
                rc.SSN = tbSSN1.Text + tbSSN2.Text + tbSSN3.Text;
                rc.SchoolDistrict = tbSchoolDistrict.Text;
                rc.IncomeEmployment = Convert.ToDecimal(tbIncomeEmployment.Text);
                rc.IncomeMFIP = Convert.ToDecimal(tbIncomeMFIP.Text);
                //rc.IncomeMA = Convert.ToDecimal(tbIncomeMA.Text);
                if (chkEMA.Checked)
                {
                    rc.IncomeMA = 1;
                }
                else
                {
                    rc.IncomeMA = 0;
                }
                rc.IncomeChildSupport = Convert.ToDecimal(tbIncomeChildSupport.Text);
                rc.IncomeUnemployment = Convert.ToDecimal(tbIncomeUnemployment.Text);
                rc.IncomeSSISSDI = Convert.ToDecimal(tbIncomeSSISSDI.Text);
                rc.IncomeOther = Convert.ToDecimal(tbIncomeOtherSources.Text);
                rc.CashOnHand = Convert.ToDecimal(tbCashOnHand.Text);

                int nf = 0;
                if (cbInfoMentalIllness.Checked)
                {
                    nf += 1;
                }
                if (cbInfoDisabled.Checked)
                {
                    nf += 2;
                }
                if (cbInfoVeteran.Checked)
                {
                    nf += 4;
                }
                if (cbInfoDomestic.Checked)
                {
                    nf += 8;
                }
                if (cbInfoAddiction.Checked)
                {
                    nf += 16;
                }
                rc.IssuesOfNote = nf;
                if (dtbLastWorked.Text != "")
                {
                    rc.LastDateWorked = dtbLastWorked.SelectedDate;
                }
                else
                {
                    rc.LastDateWorked = Convert.ToDateTime("1/1/1901");
                }
                rc.MaritalStatus = Convert.ToInt32(ddlEMStatus.SelectedValue);
                if (cbLicense.Checked)
                {
                    rc.DriversLicense = 1;
                }
                else
                {
                    rc.DriversLicense = 0;
                }
                if (cbEBT.Checked)
                {
                    rc.EBT = 1;
                }
                else
                {
                    rc.EBT = 0;
                }
                rc.FoodSupport = Convert.ToDecimal(tbFoodSupportAmount.Text);
                if (dtbAssistanceRequested.Text != "")
                {
                    rc.AssistanceApplied = dtbAssistanceRequested.SelectedDate;
                }
                else
                {
                    rc.AssistanceApplied = Convert.ToDateTime("1/1/1901");
                }
                rc.FoodShelf = tbFoodShelf.Text;
                if (dtbFoodShelfVisit.Text != "")
                {
                    rc.FoodShelfVisit = dtbFoodShelfVisit.SelectedDate;
                }
                else
                {
                    rc.FoodShelfVisit = Convert.ToDateTime("1/1/1901");
                }
                rc.CaseMgr1Name = tbCaseManager1.Text;
                rc.CaseMgr1Agency = tbAgency1.Text;
                rc.CaseMgr1Phone = tbPhone1.Text;
                rc.CaseMgr1Notes = tbNotes1.Text;
                rc.CaseMgr2Name = tbCaseManager2.Text;
                rc.CaseMgr2Agency = tbAgency2.Text;
                rc.CaseMgr2Phone = tbPhone2.Text;
                rc.CaseMgr2Notes = tbNotes2.Text;

                rc.EmgAssist1Agency = tbEAngency1.Text;
                rc.EmgAssist1CaseMgr = tbECaseManager1.Text;
                rc.EmgAssist1Phone = tbEPhone1.Text;
                if (dtbEDate1.Text != "")
                {
                    rc.EmgAssist1Date = dtbEDate1.SelectedDate;
                }
                else
                {
                    rc.EmgAssist1Date = Convert.ToDateTime("1/1/1901");
                }
                rc.EmgAssist1Amount = Convert.ToDecimal(tbEAmount1.Text);
                rc.EmgAssist1Status = Convert.ToInt32(ddlEStatus1.SelectedValue);
                rc.EmgAssist2Agency = tbEAgency2.Text;
                rc.EmgAssist2CaseMgr = tbECaseManager2.Text;
                rc.EmgAssist2Phone = tbEPhone2.Text;
                if (dtbEDate2.Text != "")
                {
                    rc.EmgAssist2Date = dtbEDate2.SelectedDate;
                }
                else
                {
                    rc.EmgAssist2Date = Convert.ToDateTime("1/1/1901");
                }
                rc.EmgAssist2Amount = Convert.ToDecimal(tbEAmount2.Text);
                rc.EmgAssist2Status = Convert.ToInt32(ddlEStatus2.SelectedValue);

                rc.NumChildren = Convert.ToInt32(ddlEBGC.SelectedValue);

                if (cbSheltered.Checked)
                {
                    rc.PastShelter = 1;
                }
                else
                {
                    rc.PastShelter = 0;
                }
                if (dtbShelteredDate.Text != "")
                {
                    rc.PastShelterDate = dtbShelteredDate.SelectedDate;
                }
                else
                {
                    rc.PastShelterDate = Convert.ToDateTime("1/1/1901");
                }
                if (cbUnsheltered.Checked)
                {
                    rc.PastUnsheltered = 1;
                }
                else
                {
                    rc.PastUnsheltered = 0;
                }
                if (dtbUnshelteredDate.Text != "")
                {
                    rc.PastUnshelteredDate = dtbUnshelteredDate.SelectedDate;
                }
                else
                {
                    rc.PastUnshelteredDate = Convert.ToDateTime("1/1/1901");
                }
                if (cbChemical.Checked)
                {
                    rc.PastChemical = 1;
                }
                else
                {
                    rc.PastChemical = 0;
                }
                if (dtbChemicalDate.Text != "")
                {
                    rc.PastChemicalDate = dtbChemicalDate.SelectedDate;
                }
                else
                {
                    rc.PastChemicalDate = Convert.ToDateTime("1/1/1901");
                }
                if (cbTransitional.Checked)
                {
                    rc.PastTransitional = 1;
                }
                else
                {
                    rc.PastTransitional = 0;
                }
                if (dtbTransitionalDate.Text != "")
                {
                    rc.PastTransitionalDate = dtbTransitionalDate.SelectedDate;
                }
                else
                {
                    rc.PastTransitionalDate = Convert.ToDateTime("1/1/1901");
                }
                if (cbDoubled.Checked)
                {
                    rc.PastDoubled = 1;
                }
                else
                {
                    rc.PastDoubled = 0;
                }
                if (dtbDoubledDate.Text != "")
                {
                    rc.PastDoubledDate = dtbDoubledDate.SelectedDate;
                }
                else
                {
                    rc.PastDoubledDate = Convert.ToDateTime("1/1/1901");
                }
                if (cbEviction.Checked)
                {
                    rc.PastEviction = 1;
                }
                else
                {
                    rc.PastEviction = 0;
                }
                if (dtbEvictionDate.Text != "")
                {
                    rc.PastEvictionDate = dtbEvictionDate.SelectedDate;
                }
                else
                {
                    rc.PastEvictionDate = Convert.ToDateTime("1/1/1901");
                }
                if (cbForeclosure.Checked)
                {
                    rc.PastForeclosure = 1;
                }
                else
                {
                    rc.PastForeclosure = 0;
                }
                if (dtbForeclosureDate.Text != "")
                {
                    rc.PastForeclosureDate = dtbForeclosureDate.SelectedDate;
                }
                else
                {
                    rc.PastForeclosureDate = Convert.ToDateTime("1/1/1901");
                }

                rc.PhoneHome = tbPhoneHome.Text;
                rc.PhoneWork = tbPhoneWork.Text;
                rc.PhoneMobile = tbPhoneMobile.Text;
                rc.PhoneOther = tbPhoneOther.Text;

                rc.StreetAddress = tbStreet.Text;
                rc.City = tbCity.Text;
                rc.PostalCode = tbZip.Text;
                rc.State = tbState.Text;

                int i = 0;
                if (chkEB2B.Checked)
                    i += 1;
                if (chkEHMIS.Checked)
                    i += 2;
                if (chkEIntake.Checked)
                    i += 4;
                if (chkEExit.Checked)
                    i += 8;
                if (chkE30Day.Checked)
                    i += 16;
                if (chkE6Month.Checked)
                    i += 32;
                if (chkE1Year.Checked)
                    i += 64;

                rc.NumAdults = i;

                bool canSave = true;
                if (SimDone.Value != "true")
                {
                    if (new ResourceCenterPerson().CountSimilars(tbFirstName.Text, tbLastName.Text, "", "", _personId) > 0)
                    {
                        pConflicts.Visible = true;
                        cbConflictingName.Visible = true;

                        if (!cbConflictingName.Checked)
                        {
                            canSave = false;
                            dgConflictingNames.Visible = true;
                            ResourceCenterPersonCollection badNames = ResourceCenterPersonCollection.LoadAll(CurrentOrganization.OrganizationID, tbFirstName.Text, tbLastName.Text, "", "", "");
                            dgConflictingNames.DataSource = badNames.DataTable();
                            dgConflictingNames.DataBind();
                        }
                    }
                    else
                    {
                        cbConflictingName.Visible = false;
                        dgConflictingNames.Visible = false;
                    }

                    if (new ResourceCenterPerson().CountSimilars("", "", tbStreet.Text, tbZip.Text, _personId) > 0)
                    {
                        if ((tbZip.Text != _rcdata.PostalCode) && (tbStreet.Text != _rcdata.StreetAddress))
                        {
                            pConflicts.Visible = true;
                            cbConflictingAddress.Visible = true;

                            if (!cbConflictingAddress.Checked)
                            {
                                canSave = false;
                                dgConflictingAddresses.Visible = true;
                                ResourceCenterPersonCollection badAddresses = ResourceCenterPersonCollection.LoadAll(CurrentOrganization.OrganizationID, "", "", "", tbStreet.Text, tbZip.Text);
                                dgConflictingAddresses.DataSource = badAddresses.DataTable();
                                dgConflictingAddresses.DataBind();
                            }
                        }
                    }
                    else
                    {
                        cbConflictingAddress.Visible = false;
                        dgConflictingAddresses.Visible = false;
                    }
                }

                rc.EmploymentFrequency = Convert.ToInt32(ddlEFinEmploymentFrequency.SelectedValue);
                rc.EmploymentDate = dtbEFinEmployment.Text != "" ? dtbEFinEmployment.SelectedDate : Convert.ToDateTime("1/1/1901");
                rc.MFIPDay = Convert.ToInt32(tbEFinMFIP.Text);
                rc.ChildSupportDate = dtbEFinChildSupport.Text != "" ? dtbEFinChildSupport.SelectedDate : Convert.ToDateTime("1/1/1901");
                rc.OtherSourcesDate = dtbEFinOtherSources.Text != "" ? dtbEFinOtherSources.SelectedDate : Convert.ToDateTime("1/1/1901");

                if (canSave)
                {
                    cbConflictingAddress.Checked = false;
                    cbConflictingName.Checked = false;

                    rc.Save(CurrentOrganization.OrganizationID, Page.User.Identity.Name);

                    if (_personId != rc.Id)
                    {
                        Response.Redirect("default.aspx?page=" + _thisPage + "&personid=" + rc.Id.ToString());
                    }
                    else
                    {
                        HideEdit(null, null);
                    }
                }
                else
                {
                    cbConflictingAddress.Checked = false;
                    cbConflictingName.Checked = false;

                    ViewDetails.Visible = false;
                    EditDetails.Visible = true;
                    EditButton.Visible = false;
                }
            }
        }

        protected void CancelButton_Click(object sender, EventArgs e)
        {
            if (_personId > 0)
            {
                HideEdit(null, null);
            }
            else
            {
                string sSim = Request.QueryString["similar"];
                if (Convert.ToInt32(sSim) > 0)
                {
                    Response.Redirect("default.aspx?page=" + _thisPage + "&personid=" + sSim);
                }
                else
                {
                    Response.Redirect("default.aspx?page=" + SearchPageSetting);
                }
            }
        }

        protected void CreateButton_Click(object sender, EventArgs e)
        {
            Response.Redirect("default.aspx?page=" + _thisPage + "&similar=" + _personId.ToString());
        }

        protected void ShowEdit(object sender, EventArgs e)
        {
            pCalendar.Visible = false;
            pConflicts.Visible = false;

            ViewDetails.Visible = false;
            BindEditData();
            EditDetails.Visible = true;
            EditLinks.Visible = true;
            pFullEdit.Visible = !_isQuick;
            EditButton.Visible = false;

            pBottomSectionHeader.Visible = false;
        }

        protected void HideEdit(object sender, EventArgs e)
        {
            pCalendar.Visible = true;
            pConflicts.Visible = false;

            EditDetails.Visible = false;
            pFullEdit.Visible = false;
            EditLinks.Visible = false;
            BindViewData();
            ViewDetails.Visible = true;
            EditButton.Visible = true;

            pBottomSectionHeader.Visible = true;
            BindFamilyTable();
        }

        public void BindFamilyTable()
        {
            _familyList = new ResourceCenterPersonCollection(CurrentOrganization.OrganizationID, _personId);
            gridFamily.DataSource = _familyList.DataTable();
            gridFamily.DataBind();
        }

        public string GetNeedNameFromId(int needId)
        {
            return ResourceCenterHelp.GetTypeNameById(needId);
        }

        public string GetResourceNameFromId(int resourceId)
        {
            return ResourceCenterHelp.GetSubtypeNameById(resourceId);
        }

        public string GetCompletedString(DateTime completedOn)
        {
            string s = string.Empty;

            if (completedOn > Convert.ToDateTime("1/1/1901"))
            {
                s = "Yes (" + completedOn.ToShortDateString() + ")";
            }
            else
            {
                s = "No";
            }

            return s;
        }

        public string CreateHelpLink(int helpId)
        {
            return "<a href=\"default.aspx?page=" + AssistanceDetailsPage + "&helpid=" + helpId.ToString() + "\">View/Edit</a>";
        }

        public string CreateNewHelpLink()
        {
            if (CanEdit)
                return "<a href=\"default.aspx?page=" + AssistanceDetailsPage + "&personid=" + _personId + "\">Create New Assistance</a>";
            else
                return "";
        }

        public void SortFamily_Click(object sender, DataGridSortCommandEventArgs e)
        {
            DataView dv = new DataView(new ResourceCenterPersonCollection(CurrentOrganization.OrganizationID, _personId).DataTable());
            dv.Sort = e.SortExpression;
            gridFamily.DataSource = dv;
            gridFamily.DataBind();
        }

        public string CreateBulkChangeAddressLink()
        {
            if (CanEdit)
                return "<a href=\"default.aspx?page=" + BulkChangeAddressPage + "&personid=" + _personId + "\">Bulk Change Address</a>";
            else
                return "";
        }

        public void gridFamily_Rebind(object sender, EventArgs e)
        {
            BindFamilyTable();
        }

        public bool IsDate(string sdate)
        {
            bool isDate = true;

            try
            {
                DateTime.Parse(sdate);
            }
            catch
            {
                isDate = false;
            }

            return isDate;
        }

        protected void StrictDate_Validate(object sender, ServerValidateEventArgs args)
        {
            args.IsValid = IsDate(args.Value.ToString());
        }

        protected void Date_Validate(object sender, ServerValidateEventArgs args)
        {
            args.IsValid = ((IsDate(args.Value.ToString())) || (args.Value.ToString() == ""));
        }

        protected void Decimal_Validate(object sender, ServerValidateEventArgs args)
        {
            bool isDecimal = true;

            try
            {
                decimal.Parse(args.Value.ToString());
            }
            catch
            {
                isDecimal = false;
            }

            args.IsValid = (isDecimal && (args.Value.ToString() != ""));
        }

        protected void BindCalendar(DateTime date)
        {
            calDates.OtherMonthDayStyle.ForeColor = System.Drawing.Color.FromArgb(0x00909090);
            calDates.OtherMonthDayStyle.BackColor = System.Drawing.Color.FromArgb(0x00eeeeee);
            calDates.WeekendDayStyle.BackColor = System.Drawing.Color.FromArgb(0x00f2f2f2);
            calDates.BorderStyle = BorderStyle.Inset;
            calDates.DayStyle.BackColor = System.Drawing.Color.White;
            calDates.DayHeaderStyle.BackColor = System.Drawing.Color.White;
            DateTime start = new DateTime(date.Year, date.Month, 1).AddDays(-7);
            DateTime end = new DateTime(date.Year, date.Month, 1).AddMonths(1).AddDays(6);
            _paydates = ResourceCenterEventCollection.LoadAll(CurrentOrganization.OrganizationID, start, end, Convert.ToInt32(Request.QueryString["personid"]), 0);
        }

        protected void calDates_DayRender(object sender, DayRenderEventArgs e)
        {
            if (_paydates == null)
            {
                BindCalendar(e.Day.Date);
            }

            decimal tot = 0;
            e.Cell.Controls.Add(new LiteralControl("<br />"));
            foreach (ResourceCenterEvent ev in _paydates)
            {
                if (e.Day.Date.ToShortDateString() == ev.Date.ToShortDateString())
                {
                    string color = string.Empty;
                    if (ev.Source == "Employment")
                    {
                        color = "#cdc0b0";
                    }
                    if (ev.Source == "Child Suppoer")
                    {
                        color = "#eee8dc";
                    }
                    if (ev.Source == "Other")
                    {
                        color = "#dccdc";
                    }
                    if (ev.Source == "MFIP")
                    {
                        color = "#e0eee0";
                    }
                    if (ev.Source == "Unemployment")
                    {
                        color = "#ffe4e1";
                    }
                    e.Cell.Controls.Add(new LiteralControl("<div style=\"border: 1px solid " + color + "; border-radius: 10px / 5px; background-color: " + color + ";\"><strong>" + ev.Source + "</strong> $" + String.Format("{0:0.00}", ev.Amount) + "</div>"));
                }
                tot += ev.Amount;
                lblCalTotal.Text = "<strong>" + _paydates.Count.ToString() + "</strong> pay dates totaling <strong>$" + string.Format("{0:0.00}", tot) + "</strong>";
            }
        }

        protected void calDates_VisibleMonthChanged(object sender, MonthChangedEventArgs e)
        {
            BindCalendar(e.NewDate);
        }

        protected bool CanEdit
        {
            get
            {
                return CurrentModule.Permissions.Allowed(OperationType.Edit, CurrentUser);
            }
        }

        protected string GetImageLink(int t)
        {
            switch (t)
            {
                case 0:
                    return "UserControls/Custom/SALC/ResourceCenter/Images/Exclamation.png";
                case 1:
                    return "UserControls/Custom/SALC/ResourceCenter/Images/CheckMark.png";
                case 2:
                    return "UserControls/Custom/SALC/ResourceCenter/Images/Minus.png";
                default:
                    return "";
            }
        }

        protected string GetCallType(int t)
        {
            switch (t)
            {
                case 1:
                    return "Assistance Request";
                case 2:
                    return "Volunteer/Donation";
                case 3:
                    return "Info Request";
                case 4:
                    return "Check-In";
                default:
                    return "Unknown";
            }
        }

        protected void bSSNShowHide_Click(object sender, EventArgs e)
        {
            if (bSSNShowHide.Text == "Show")
            {
                bSSNShowHide.Text = "Hide";
                lblSSN.Visible = true;
                upPartial.Update();
            }
            else
            {
                bSSNShowHide.Text = "Show";
                lblSSN.Visible = false;
                upPartial.Update();
            }
        }
    }
}