﻿namespace ArenaWeb.UserControls.Custom.SALC.ResourceCenter
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Web;
    using System.Web.UI;
    using System.Web.UI.WebControls;
    using Arena.Core;
    using Arena.Portal;
    using Arena.Portal.UI;
    using Arena.Security;
    using Arena.Custom.SALC.ResourceCenter.Entity;

    public partial class AssistanceDetails : PortalControl
    {
        [PageSetting("Main Client Search Page", "The Main Client Search page", true)]
        public string MainClientSearchPageSetting { get { return Setting("MainClientSearchPage", "", true); } }

        [PageSetting("Client Details Page", "The Client Details page", true)]
        public string ClientDetailsPageSetting { get { return Setting("ClientDetailsPage", "", true); } }

        [PageSetting("Assistance Add Client Page", "The Assistance Add Client page", true)]
        public string AssistanceAddClientPageSetting { get { return Setting("AssistanceAddClientPage", "", true); } }

        [PageSetting("Assistance Shelter Page", "The Assistance Shelter page", true)]
        public string AssistanceShelterPageSetting { get { return Setting("AssistanceShelterPage", "", true); } }

        [PageSetting("Assistance Non Shelter Page", "The Assistance Non Shelter page", true)]
        public string AssistanceNonShelterPageSetting { get { return Setting("AssistanceNonShelterPage", "", true); } }

        public int _helpId = -1;
        private int _prototypeId = -1;
        private bool _new = false;
        private bool _del = false;
        public string _thisPage = string.Empty;
        private ResourceCenterHelp _helpdata = new ResourceCenterHelp();
        private ResourceCenterPerson _proto = new ResourceCenterPerson();

        protected void Page_Load(object sender, EventArgs e)
        {

            //Page.EnableViewState = false;
            _thisPage = Request.QueryString["page"];
            if (Convert.ToInt32(Request.QueryString["helpid"]) > 0)
            {
                _helpId = Convert.ToInt32(Request.QueryString["helpid"]);
                _helpdata = new ResourceCenterHelp(_helpId);
            }
            if (Convert.ToInt32(Request.QueryString["personid"]) > 0)
            {
                _prototypeId = Convert.ToInt32(Request.QueryString["personid"]);
                _proto = new ResourceCenterPerson(_prototypeId);
            }

            if (!IsPostBack)
            {
                if (CanEdit)
                {
                    GeneralInformationEditLink.Visible = true;
                    GridAccount.AddEnabled = true;
                    GridAccount.DeleteEnabled = true;
                    GridAccount.EditEnabled = true;
                    GridFamily.DeleteEnabled = true;
                    lAddClientLink.Text = "<a href=\"default.aspx?page=" + AssistanceAddClientPageSetting + "&helpid=" + _helpId.ToString() + "\">Add Client to this Assistance</a>";
                }
                else
                {
                    GeneralInformationEditLink.Visible = false;
                    GridAccount.AddEnabled = false;
                    GridAccount.DeleteEnabled = false;
                    GridAccount.EditEnabled = false;
                    GridFamily.DeleteEnabled = false;
                    lAddClientLink.Text = "";
                }

                if (_helpId > 0)
                {
                    BindViewData();
                }
                else
                {
                    _new = true;
                    _helpdata = new ResourceCenterHelp();
                    lblECounty.Visible = false;
                    ddlCounty.Visible = false;
                    ddlCounty.Enabled = false;
                    RequiredFieldValidator9.Enabled = false;
                    EditGeneralInformation(null, null);
                }

                if (Request.QueryString["add"] == "true")
                {
                    AddLink();
                }

                string suffix = string.Empty;
                if (_helpId != -1) suffix += "&helpid=" + _helpId.ToString();
                if (_prototypeId != -1) suffix += "&personid=" + _prototypeId.ToString();
                if ((_helpdata.SubType == 14) && (_thisPage != AssistanceShelterPageSetting))
                {
                    Response.Redirect("default.aspx?page=" + AssistanceShelterPageSetting + suffix);
                }
                if ((_helpdata.SubType != 14) && (_thisPage == AssistanceShelterPageSetting))
                {
                    Response.Redirect("default.aspx?page=" + AssistanceNonShelterPageSetting + suffix);
                }
            }
            else
            {
                SetupQVOptions();
            }
        }

        protected bool CanEdit
        {
            get
            {
                return CurrentModule.Permissions.Allowed(OperationType.Edit, CurrentUser);
            }
        }

        protected void BindAccounts()
        {
            ResourceCenterAccountCollection acc = ResourceCenterAccountCollection.LoadAll(_helpId);
            GridAccount.DataSource = acc.DataTable();
            GridAccount.DataBind();

            decimal total = 0;
            foreach (ResourceCenterAccount rcac in acc)
            {
                total += rcac.Amount;
            }
            if (total >= 0)
            {
                lblBalance.ForeColor = System.Drawing.Color.Empty;
            }
            else
            {
                lblBalance.ForeColor = System.Drawing.Color.FromArgb(0x990000);
            }
            lblBalance.Text = String.Format("${0:0.00}", total);
        }

        protected void BindFamily()
        {
            ResourceCenterPersonCollection fam = ResourceCenterPersonCollection.LoadAll(_helpId);
            GridFamily.DataSource = fam.DataTable();
            GridFamily.DataBind();
        }

        protected void AccountAdd_Click(object sender, EventArgs e)
        {
            ResourceCenterAccount accountData = new ResourceCenterAccount();
            accountData.OrganizationId = CurrentArenaContext.Organization.OrganizationID;
            accountData.HelpId = _helpId;
            accountData.Date = DateTime.Today;
            accountData.Note = " ";
            accountData.Save();
            BindAccounts();
        }

        protected void AccountEdit_Click(object sender, DataGridCommandEventArgs e)
        {
            //GridAccount.Add
            //lblGeneralInfoVAmount.Text = "done";
            bool hasIssue = false;
            ResourceCenterAccount accountData = new ResourceCenterAccount(Convert.ToInt32(e.Item.Cells[0].Text));
            //lblGeneralInfoVAmount.Text = e.Item.Cells[0].Text;
            try
            {
                accountData.Date = Convert.ToDateTime(((TextBox)e.Item.Cells[1].Controls[0]).Text); //((TextBox)e.Item.Controls[1].Controls[0]).Text;
            }
            catch
            {
                hasIssue = true;
            }
            try
            {
                accountData.Amount = Decimal.Parse(((TextBox)e.Item.Controls[2].Controls[0]).Text.Replace("$", ""));
            }
            catch
            {
                hasIssue = true;
            }
            accountData.Note = ((TextBox)e.Item.Controls[3].Controls[0]).Text;
            if (!hasIssue)
            {
                GridAccount.EditItemIndex = -1;
                accountData.Save();
            }
            BindAccounts();
        }

        protected void DeleteAccount_Click(object sender, DataGridCommandEventArgs e)
        {
            if (GridAccount.EditItemIndex > -1)
            {
                //GridAccount.CancelCommand(sender, e);
                GridAccount.EditItemIndex = -1;
            }
            TableCell itemCell = e.Item.Cells[0];
            int accountId = 0;
            try
            {
                accountId = Convert.ToInt32(itemCell.Text);
            }
            catch
            {
                accountId = 0;
            }
            if (accountId > 0)
            {
                ResourceCenterAccount.Delete(accountId);
                BindAccounts();
            }
        }

        protected void DeleteHelpLink_Click(object sender, DataGridCommandEventArgs e)
        {
            TableCell itemCell = e.Item.Cells[0];
            int personId = Convert.ToInt32(itemCell.Text);
            ResourceCenterHelp helpdata = new ResourceCenterHelp();
            helpdata.Delete(_helpId, personId);

            if (helpdata.Erased)
            {
                Response.Redirect("default.aspx?page=" + MainClientSearchPageSetting);
            }
            BindFamily();

        }

        protected void SetupQVOptions()
        {
            ResourceCenterHelpSubType item = ResourceCenterHelp.GetSubtypeDisplayById(Convert.ToInt32(ddlGeneralInfoESecondaryType.SelectedValue));
            if (item.IsQuantity)
            {
                tbGeneralInfoESize.Enabled = true;
                rfvSize.Enabled = true;
                lblQuantity.Text = item.Text;
            }
            else
            {
                tbGeneralInfoESize.Enabled = false;
                rfvSize.Enabled = false;
                lblQuantity.Text = "";
            }
            if (item.IsAmount)
            {
                tbGeneralInfoEAmount.Enabled = true;
                rfvAmount.Enabled = true;
                lblValue.Text = item.Text;
            }
            else
            {
                tbGeneralInfoEAmount.Enabled = false;
                rfvAmount.Enabled = false;
                lblValue.Text = "";
            }
            if (item.IsAmount && item.IsQuantity)
            {
                rfvAmount.Enabled = false;
                rfvSize.Enabled = false;
            }
        }

        protected void Delete()
        {
            _helpdata.Delete(_helpId, _prototypeId);
            if (!_helpdata.Erased)
            {
                string page = Request.QueryString["page"];
                Response.Redirect("default.aspx?page=" + page + "&helpid=" + _helpId);
            }
            else
            {
                Response.Redirect("default.aspx?page=" + MainClientSearchPageSetting);
            }
        }

        protected void AddLink()
        {
            _helpdata.AddLink(_helpId, _prototypeId);
            Response.Redirect("default.aspx?page=" + _thisPage + "&helpid=" + _helpId);
        }

        protected void BindViewData()
        {
            BindAccounts();
            BindFamily();
            pInfo.Visible = true;
            if (_helpdata.Amount != 0)
            {
                lblGeneralInfoVAmount.Text = "$" + String.Format("{0:0.00}", _helpdata.Amount);
            }
            lblGeneralInfoVAssistanceID.Text = _helpdata.Id.ToString();
            lblGeneralInfoVAssistant.Text = _helpdata.Assistant;
            lblGeneralInfoVDateAdded.Text = _helpdata.DateCreated.ToShortDateString();
            lblGeneralInfoVDateModified.Text = _helpdata.DateUpdated.ToShortDateString();
            lblGeneralInfoVDescription.Text = _helpdata.Description;

            lblGeneralInfoVPrimaryType.Text = ResourceCenterHelp.GetTypeNameById(_helpdata.Type);
            lblGeneralInfoVSecondaryType.Text = ResourceCenterHelp.GetSubtypeNameById(_helpdata.SubType);

            if (_helpdata.Size != 0)
            {
                lblGeneralInfoVSize.Text = _helpdata.Size.ToString();
            }
            if (_helpdata.Subsidized > 0)
            {
                lblGeneralInfoVSubsidy.Text = "Yes (" + _helpdata.SubSource + ")";
                lblStatusInfoVSubsidy.Text = "$" + String.Format("{0:0.00}", _helpdata.SubAmountReceived);
            }
            else
            {
                lblGeneralInfoVSubsidy.Text = "No";
                lblStatusInfoVSubsidy.Text = "N/A";
            }
            lblGeneralInfoVVendor.Text = _helpdata.Vendor;
            if (_helpdata.DateCompleted > Convert.ToDateTime("1/1/1901"))
            {
                lblStatusInfoVCompletionDate.Text = _helpdata.DateCompleted.ToShortDateString();
            }
            else
            {
                lblStatusInfoVCompletionDate.Text = "Not Completed";
            }
            if (_helpdata.Date > Convert.ToDateTime("1/1/1901"))
            {
                lblStatusInfoVStartDate.Text = _helpdata.Date.ToShortDateString();
            }
            else
            {
                lblStatusInfoVStartDate.Text = "Unknown";
            }
            lblStatusInfoVNotes.Text = _helpdata.Notes;
            lblStatusInfoVResolution.Text = _helpdata.Resolution;
        }

        protected void BindEditData()
        {
            if (_helpId != -1)
            {
                _helpdata = new ResourceCenterHelp(_helpId);
            }
            else
            {
                //_helpdata.Date = DateTime.Now;
                //_helpdata.DateCompleted = DateTime.Now;

            }
            if (_new)
            {
                if (dtbStatusInfoEStartDate.Text == "")
                    dtbStatusInfoEStartDate.SelectedDate = DateTime.Now;
                if (dtbStatusInfoECompltionDate.Text == "")
                {
                    if (!IsPostBack)
                    {
                        dtbStatusInfoECompltionDate.SelectedDate = DateTime.Now;
                    }
                }
            }
            else
            {
                if (_helpdata.Date > Convert.ToDateTime("1/1/1901"))
                {
                    dtbStatusInfoEStartDate.SelectedDate = _helpdata.Date;
                }
                if (_helpdata.DateCompleted > Convert.ToDateTime("1/1/1901"))
                {
                    dtbStatusInfoECompltionDate.SelectedDate = _helpdata.DateCompleted;
                }
            }
            cbGeneralInfoESubsidy.Checked = (_helpdata.Subsidized > 0);
            ddlGeneralInfoEPrimaryType.SelectedValue = _helpdata.Type.ToString();
            ddlGeneralInfoESecondaryType.SelectedValue = _helpdata.SubType.ToString();
            if (_helpdata.Amount != 0)
            {
                tbGeneralInfoEAmount.Text = String.Format("{0:0.00}", _helpdata.Amount);
            }
            tbGeneralInfoEAssistant.Text = _helpdata.Assistant;
            tbGeneralInfoEDescription.Text = _helpdata.Description;
            if (_helpdata.Size != 0)
            {
                tbGeneralInfoESize.Text = _helpdata.Size.ToString();
            }
            tbGeneralInfoESubsidySource.Text = _helpdata.SubSource;
            tbGeneralInfoEVendor.Text = _helpdata.Vendor;
            tbStatusInfoENotes.Text = _helpdata.Notes;
            tbStatusInfoResolution.Text = _helpdata.Resolution;
            if (_helpdata.SubAmountReceived != 0)
            {
                tbStatusInfoSubsidyRecieved.Text = String.Format("{0:0.00}", _helpdata.SubAmountReceived);
            }
            if (_prototypeId > 0)
            {
                panClientName.Visible = true;
                lblClientName.Text = "Family of: <strong>" + _proto.FirstName + " " + _proto.LastName + "</strong>";
            }

            if (lblECounty.Visible)
            {
                ddlCounty.SelectedValue = _helpdata.County;
            }

            SetupQVOptions();
        }

        protected void EditGeneralInformation(object sender, EventArgs e)
        {
            GeneralInfoView.Visible = false;
            GeneralInfoEdit.Visible = true;
            pInfo.Visible = false;

            //ddlGeneralInfoESecondaryType.Items.Clear();
            //ddlGeneralInfoESecondaryType.DataSource = new ResourceCenterHelpSubTypeCollection(CurrentOrganization.OrganizationID).DataTable();
            //ddlGeneralInfoESecondaryType.DataTextField = "Name";
            //ddlGeneralInfoESecondaryType.DataValueField = "id";
            //ddlGeneralInfoESecondaryType.DataBind();

            BindEditData();
        }

        protected void GeneralInfoSave(object sender, EventArgs e)
        {
            if (Page.IsValid)
            {
                if (_helpId != -1)
                {
                    _helpdata = new ResourceCenterHelp(_helpId);
                }
                else
                {
                    _helpdata = new ResourceCenterHelp();
                }
                if (tbGeneralInfoEAmount.Text.Length > 0)
                {
                    _helpdata.Amount = Convert.ToDecimal(tbGeneralInfoEAmount.Text);
                }
                else
                {
                    _helpdata.Amount = 0;
                }
                _helpdata.Assistant = tbGeneralInfoEAssistant.Text;
                _helpdata.Complete = "";
                if (dtbStatusInfoEStartDate.Text == "")
                {
                    _helpdata.Date = Convert.ToDateTime("1/1/1901");
                }
                else
                {
                    _helpdata.Date = Convert.ToDateTime(dtbStatusInfoEStartDate.Text);
                }
                if (dtbStatusInfoECompltionDate.Text == "")
                {
                    _helpdata.DateCompleted = Convert.ToDateTime("1/1/1901");
                }
                else
                {
                    _helpdata.DateCompleted = Convert.ToDateTime(dtbStatusInfoECompltionDate.Text);
                }
                _helpdata.Description = tbGeneralInfoEDescription.Text;
                _helpdata.Notes = tbStatusInfoENotes.Text;
                _helpdata.Resolution = tbStatusInfoResolution.Text;
                if (tbGeneralInfoESize.Text.Length > 0)
                {
                    _helpdata.Size = Convert.ToInt32(tbGeneralInfoESize.Text);
                }
                else
                {
                    _helpdata.Size = 0;
                }
                if (tbStatusInfoSubsidyRecieved.Text.Length > 0)
                {
                    _helpdata.SubAmountReceived = Convert.ToDecimal(tbStatusInfoSubsidyRecieved.Text);
                }
                else
                {
                    _helpdata.SubAmountReceived = 0;
                }
                if (cbGeneralInfoESubsidy.Checked)
                {
                    _helpdata.Subsidized = 1;
                }
                else
                {
                    _helpdata.Subsidized = 0;
                }

                if (lblECounty.Visible)
                {
                    _helpdata.County = ddlCounty.SelectedValue;
                }

                _helpdata.SubSource = tbGeneralInfoESubsidySource.Text;
                _helpdata.SubType = Convert.ToInt32(ddlGeneralInfoESecondaryType.SelectedValue);
                _helpdata.Type = Convert.ToInt32(ddlGeneralInfoEPrimaryType.SelectedValue);
                _helpdata.Vendor = tbGeneralInfoEVendor.Text;
                _helpdata.Save(Page.User.Identity.Name, _prototypeId);

                Response.Redirect("default.aspx?page=" + _thisPage + "&helpid=" + _helpdata.Id.ToString());
            }
        }

        protected void GeneralInfoCancel(object sender, EventArgs e)
        {
            if (_helpdata.Id > 0)
            {
                GeneralInfoEdit.Visible = false;
                GeneralInfoView.Visible = true;

                BindViewData();
            }
            else
            {
                Response.Redirect("default.aspx?page=" + ClientDetailsPageSetting + "&personid=" + _prototypeId.ToString());
            }
        }

        protected string GetAge(DateTime birthday, DateTime date)
        {
            if (birthday > Convert.ToDateTime("1/1/1901"))
            {
                return (birthday > date.AddYears(-(date.Year - birthday.Year)) ? (date.Year - birthday.Year) - 1 : (date.Year - birthday.Year)).ToString();
            }
            else
            {
                return "";
            }
        }

        protected string GetBirthday(DateTime birthday)
        {
            if (birthday > Convert.ToDateTime("1/1/1901"))
            {
                return birthday.ToShortDateString();
            }
            else
            {
                return "";
            }
        }

        protected void GridAccount_Rebind(object sender, EventArgs e)
        {
            BindAccounts();
        }

        protected void GridFamily_Rebind(object sender, EventArgs e)
        {
            BindFamily();
        }

        protected DateTime GetDate(string s)
        {
            DateTime dt;
            try
            {
                dt = DateTime.Parse(s);
            }
            catch
            {
                return Convert.ToDateTime("1/1/1901");
            }
            return dt;
        }

        protected int DayDiff(DateTime d1, DateTime d2)
        {
            return (d1 - d2).Days;
        }

        protected void TimeSpanMax_Validate(object sender, ServerValidateEventArgs args)
        {

            if (DayDiff(GetDate(dtbStatusInfoECompltionDate.Text), GetDate(dtbStatusInfoEStartDate.Text)) >= 365)
            {
                args.IsValid = false;
            }
            else
            {
                args.IsValid = true;
            }
        }

        protected void TimeSpanMin_Validate(object sender, ServerValidateEventArgs args)
        {
            if (DayDiff(GetDate(dtbStatusInfoECompltionDate.Text), GetDate(dtbStatusInfoEStartDate.Text)) < 0)
            {
                args.IsValid = false;
            }
            else
            {
                args.IsValid = true;
            }
        }

        protected void Subsidy_Validate(object sender, ServerValidateEventArgs args)
        {
            if (cbGeneralInfoESubsidy.Checked && (tbGeneralInfoESubsidySource.Text == ""))
            {
                args.IsValid = false;
            }
            else
            {
                args.IsValid = true;
            }
        }

        protected void Description_Validate(object sender, ServerValidateEventArgs args)
        {
            if (((ddlGeneralInfoESecondaryType.SelectedValue == "13")
                    || (ddlGeneralInfoESecondaryType.SelectedValue == "14")
                    || (ddlGeneralInfoESecondaryType.SelectedValue == "26")
                ) && (tbGeneralInfoEDescription.Text == ""))
            {
                args.IsValid = false;
            }
            else
            {
                args.IsValid = true;
            }
        }
    }
}
