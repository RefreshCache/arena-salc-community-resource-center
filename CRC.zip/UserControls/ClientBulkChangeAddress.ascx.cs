﻿namespace ArenaWeb.UserControls.Custom.SALC.ResourceCenter
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Web;
    using System.Web.UI;
    using System.Web.UI.WebControls;
    using Arena.Core;
    using Arena.Portal;
    using Arena.Portal.UI;
    using Arena.Security;
    using Arena.Custom.SALC.ResourceCenter.Entity;

    public partial class ClientBulkChangeAddress : PortalControl
    {
        [PageSetting("Client Details Page", "The Client Details page", true)]
        public string ClientDetailsPageSetting { get { return Setting("ClientDetailsPage", "", true); } }

        private int _personId = -1;
        public string _thisPage = string.Empty;
        private ResourceCenterPerson _rcdata = new ResourceCenterPerson();
        private ResourceCenterPersonCollection personCollection;

        protected void Page_Load(object sender, EventArgs e)
        {
            _thisPage = Request.QueryString["page"];
            _personId = Convert.ToInt32(Request.QueryString["personid"].ToString());
            if (_personId > 0)
            {
                _rcdata = new ResourceCenterPerson(_personId);
            }

            if (!IsPostBack)
            {
                lblCity.Text = _rcdata.City;
                lblCounty.Text = _rcdata.County;
                lblState.Text = _rcdata.State;
                lblStreet.Text = _rcdata.StreetAddress;
                lblZip.Text = _rcdata.PostalCode;

                ddlCounty.Text = _rcdata.County;
                tbCity.Text = _rcdata.City;
                tbState.Text = _rcdata.State;
                tbStreet.Text = _rcdata.StreetAddress;
                tbZip.Text = _rcdata.PostalCode;

                BindFamilyGrid();
            }
        }

        protected void BindFamilyGrid()
        {
            personCollection = ResourceCenterPersonCollection.LoadAll(CurrentOrganization.OrganizationID, "", "", "", lblStreet.Text, lblZip.Text);
            GridFamily.DataSource = personCollection.DataTable();
            GridFamily.DataBind();
        }

        protected void SaveClick(object sender, EventArgs e)
        {
            ResourceCenterPerson rc = new ResourceCenterPerson();
            rc.City = tbCity.Text;
            rc.County = ddlCounty.Text;
            rc.State = tbState.Text;
            rc.StreetAddress = tbStreet.Text;
            rc.PostalCode = tbZip.Text;
            rc.BulkChangeAddress(_personId, Page.User.Identity.Name);
            Response.Redirect("default.aspx?page=" + ClientDetailsPageSetting + "&personid=" + _personId);
        }

        protected void CancelClick(object sender, EventArgs e)
        {
            Response.Redirect("default.aspx?page=" + ClientDetailsPageSetting + "&personid=" + _personId);
        }

        protected void GridFamily_Rebind(object sender, EventArgs e)
        {
            BindFamilyGrid();
        }
    }
}