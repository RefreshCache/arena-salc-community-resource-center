namespace Arena.UserControls.Custom.SALC.ResourceCenter
{
    using System;
    using System.Data;
    using System.Linq;
    using System.IO;
    using System.Web;
    using System.Web.UI;
    using System.Web.UI.WebControls;
    using Arena.Portal;
    using Arena.Security;
    using Arena.Custom.SALC.ResourceCenter.Entity;
    using Telerik.Web.UI;

    public partial class AssistanceDocuments : PortalControl
    {

        public enum PAGESTATES
        {
            VIEW = 0,
            EDIT = 1
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!CanEdit)
            {
                lbEditLink.Visible = false;
                dgFiles.DeleteEnabled = false;
                pUpload.Visible = false;
            }
            else
            {
                lbEditLink.Visible = false;
                dgFiles.DeleteEnabled = true;
                pUpload.Visible = true;
            }
            if (!IsPostBack)
            {
                lPageName.Text = "Documents";
                iHeaderImage.ImageUrl = "~/Images/whitepages/profile.jpg";
                dgFiles.DeleteConfirmationText = "Are you sure you wish to premenantly delete this file?";
                dgFiles.NoResultText = "There are no files to display.";
                //ResourceCenterPerson p = new ResourceCenterPerson(Convert.ToInt32(Request.QueryString["personid"]));
                //CurrentPortalPage.TemplateControl.Title = p.FirstName + " " + p.LastName;
                BindFiles();
            }
            else
            {
            }
        }

        protected void CreateMessageAlert(string message)
        {
            Page.ClientScript.RegisterStartupScript(this.GetType(), Guid.NewGuid().ToString(), "alert('" + message + "');");
        }

        protected void SetPageDescription(string description)
        {
            if (description == "")
            {
                lblCurrentInfo.Text = "";
            }
            else
            {
                lblCurrentInfo.Text = description + "<br /><br />";
            }
        }

        protected bool CanEdit
        {
            get
            {
                return CurrentModule.Permissions.Allowed(OperationType.Edit, CurrentUser);
            }
        }

        protected void lbEditLink_Click(object sender, EventArgs e)
        {
            
        }

        protected void rauUpload_FileUploaded(object sender, FileUploadedEventArgs e)
        {
            if ((e.File == null) || (String.IsNullOrEmpty(e.File.FileName)) || (e.File.InputStream == null))
            {
                lUploadStatus.Text = "Upload failed!";
            }
            else
            {
                lUploadStatus.Text = "Upload sucessful!";
                using (Stream stream = e.File.InputStream)
                {
                    ResourceCenterDocument docData = new ResourceCenterDocument();
                    docData.Name = e.File.FileName;
                    docData.Parent = 2;
                    docData.ParentId = Convert.ToInt32(Request.QueryString["helpid"]);
                    docData.Mime = e.File.ContentType;
                    byte[] bytes = new byte[stream.Length];
                    docData.Size = bytes.Length;
                    stream.Read(bytes, 0, (int)stream.Length);
                    docData.Data = bytes;
                    docData.Save(CurrentOrganization.OrganizationID, CurrentUser.Identity.Name, false);
                    BindFiles();
                }
            }
            BindFiles();
        }

        protected void BindFiles()
        {
            if (Request.QueryString["helpid"] != null)
            {
                ResourceCenterDocumentCollection files = ResourceCenterDocumentCollection.LoadAll(2, Convert.ToInt32(Request.QueryString["helpid"]));
                dgFiles.DataSource = files.DataTable();
                dgFiles.DataBind();
            }
        }

        protected void dgFiles_Delete(object sender, DataGridCommandEventArgs e)
        {
            ResourceCenterDocument.Delete(Convert.ToInt32(e.Item.Cells[0].Text));
            BindFiles();
        }

        protected void dgFiles_Edit(object sender, DataGridCommandEventArgs e)
        {
            ResourceCenterDocument doc = new ResourceCenterDocument(Convert.ToInt32(e.Item.Cells[0].Text));
            doc.Name = ((TextBox)e.Item.Cells[1].Controls[1]).Text;
            doc.Save(CurrentOrganization.OrganizationID, CurrentUser.Identity.Name, false);
            dgFiles.EditItemIndex = -1;
            BindFiles();
        }

        protected void dgFiles_ReBind(object sender, EventArgs e)
        {
            BindFiles();
        }

        protected void Download_Click(object sender, CommandEventArgs e)
        {
            ResourceCenterDocument docData = new ResourceCenterDocument(Convert.ToInt32(e.CommandArgument));
            HttpContext.Current.Response.Buffer = true;
            HttpContext.Current.Response.ClearContent();
            HttpContext.Current.Response.ClearHeaders();
            HttpContext.Current.Response.ContentType = docData.Mime;
            HttpContext.Current.Response.AddHeader("Content-Disposition", "attachment;filename=" + docData.Name);
            HttpContext.Current.Response.BinaryWrite(docData.Data);
            HttpContext.Current.Response.End();
        }

    }
}