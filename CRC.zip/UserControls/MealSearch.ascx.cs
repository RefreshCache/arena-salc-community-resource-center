namespace Arena.UserControls.Custom.SALC.ResourceCenter
{
    using System;
    using System.Data;
    using System.Linq;
    using System.Web.UI;
    using System.Web.UI.WebControls;
    using Arena.Portal;
    using Arena.Security;
    using Arena.Custom.SALC.ResourceCenter.Entity;

    public partial class MealSearch : PortalControl
    {

        [PageSetting("Meal Details Page", "The Meal Details page", true)]
        public string MealDetailsPageSetting { get { return Setting("MealDetailsPage", "", true); } }

        protected void Page_Load(object sender, EventArgs e)
        {

            if (!IsPostBack)
            {
                if (!CanEdit)
                {
                    lCreateLink.Text = "";
                    ResultsGrid.DeleteEnabled = false;
                }
                else
                {
                    lCreateLink.Text = "<a href=\"default.aspx?page=" + MealDetailsPageSetting + "\">Create Meal Date</a>";
                    ResultsGrid.DeleteEnabled = true;
                }
                BindResultGrid();
            }
            else
            {
                BindResultGrid();
            }
        }

        protected void CreateMessageAlert(string message)
        {
            Page.ClientScript.RegisterStartupScript(this.GetType(), Guid.NewGuid().ToString(), "alert('" + message + "');");
        }


        protected bool CanEdit
        {
            get
            {
                return CurrentModule.Permissions.Allowed(OperationType.Edit, CurrentUser);
            }
        }

        protected void BindResultGrid()
        {
            DateTime start = new DateTime(1901, 1, 1);
            DateTime end = new DateTime(2199, 12, 31);
            if (dtbStartDate.Text.Trim() != "") start = dtbStartDate.SelectedDate;
            if (dtbEndDate.Text.Trim() != "") end = dtbEndDate.SelectedDate;

            DataTable data = ResourceCenterMealCollection.LoadAll(start, end, CurrentOrganization.OrganizationID).DataTable();

            ResultsGrid.DataSource = data;
            ResultsGrid.DataBind();
            upPartial.Update();
        }

        protected void ResultsGrid_Delete(object sender, DataGridCommandEventArgs e)
        {
            if (CanEdit)
            {
                //delete record
            }
        }

        protected void ResultsGrid_ReBind(object sender, EventArgs e)
        {
            BindResultGrid();
        }

    }
}