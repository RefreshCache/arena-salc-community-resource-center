﻿namespace Arena.UserControls.Custom.SALC.ResourceCenter
{
    using Arena.Portal;
    using System;
    using System.Web.UI.HtmlControls;
    using System.Web.UI.WebControls;
    using Arena.Portal.UI;
    using ASP;
    using System.Web.Profile;
    using Arena.Core;
    using Arena.Enums;
    using Arena.Organization;
    using System.Text;
    using Arena.Custom.SALC.ResourceCenter.Entity;

    public partial class ClientSearchPopup : PortalControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            ShowList();
            RegisterScripts();
            RegisterCompleteScript();
        }

        protected void dgPersons_Rebind(object source, EventArgs e)
        {
            ShowList();
            RegisterScripts();
            RegisterCompleteScript();
        }

        private void ShowList()
        {
            if ((tbFirstName.Text == "") && (tbLastName.Text == ""))
            {
                dgPersons.DataSource = new ResourceCenterPersonCollection();
            }
            else
            {
                dgPersons.DataSource = ResourceCenterPersonCollection.LoadAll(CurrentOrganization.OrganizationID, tbFirstName.Text, tbLastName.Text, "").DataTable();
            }
            dgPersons.DataBind();
            //upPartial.Update();
        }

        private void RegisterAddCompleteScript(int personID)
        {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.Append("\n\n<script language=\"javascript\">\n");
            stringBuilder.Append("if (opener != null)\n");
            stringBuilder.Append("{\n");
            stringBuilder.Append(string.Concat("\tvar ctrl = opener.document.frmMain.", base.Request.QueryString["plID"], ";\n"));
            stringBuilder.Append("\tif (ctrl != null)\n");
            stringBuilder.Append("\t{\n");
            stringBuilder.Append("\t\tif (ctrl.value == '')\n");
            stringBuilder.AppendFormat("\t\t\tctrl.value = '{0}';\n", personID.ToString());
            stringBuilder.Append("\t\telse\n");
            stringBuilder.AppendFormat("\t\t\tctrl.value += \",{0}\";\n", personID.ToString());
            stringBuilder.Append(string.Concat("\t\topener.document.frmMain.", base.Request.QueryString["rbID"], ".click();\n"));
            stringBuilder.Append("\t}\n");
            stringBuilder.Append("}\n");
            stringBuilder.Append("\twindow.close();\n");
            stringBuilder.Append("</script>\n\n");
            Page.ClientScript.RegisterClientScriptBlock(base.GetType(), "AddComplete", stringBuilder.ToString());
        }

        private void RegisterCompleteScript()
        {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.Append("\n\n<script language=\"javascript\">\n");
            stringBuilder.Append("function fnDone() {\n");
            stringBuilder.Append("\tif (opener != null)\n");
            stringBuilder.Append("\t{\n");
            stringBuilder.Append(string.Concat("\t\tvar ctrl = opener.document.frmMain.", base.Request.QueryString["plID"], ";\n"));
            stringBuilder.Append("\t\tif (ctrl != null)\n");
            stringBuilder.Append("\t\t{\n");
            stringBuilder.Append("\t\t\tif (ctrl.value == '')\n");
            stringBuilder.Append("\t\t\t\tctrl.value = personId;\n");
            stringBuilder.Append("\t\t\telse\n");
            stringBuilder.Append("\t\t\t\tctrl.value += personId;\n");
            stringBuilder.Append(string.Concat("\t\t\topener.document.frmMain.", base.Request.QueryString["rbID"], ".click();\n"));
            stringBuilder.Append("\t\t}\n");
            stringBuilder.Append("\t}\n");
            stringBuilder.Append("\twindow.close();\n");
            stringBuilder.Append("}\n");
            stringBuilder.Append("</script>\n\n");
            Page.ClientScript.RegisterClientScriptBlock(base.GetType(), "AddComplete", stringBuilder.ToString());
        }

        private void RegisterScripts()
        {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.Append("\n\n<script language=\"javascript\">\n");
            stringBuilder.Append("\tfunction selectPeople(returnUrl)\n");
            stringBuilder.Append("\t{\n");
            stringBuilder.Append("\t\tif (opener != null)\n");
            stringBuilder.Append("\t\t{\n");
            stringBuilder.Append(string.Concat("\t\t\tvar ctrl = opener.document.frmMain.", base.Request.QueryString["plID"], ";\n"));
            stringBuilder.Append("\t\t\tif (ctrl != null)\n");
            stringBuilder.Append("\t\t\t{\n");
            stringBuilder.Append("\t\t\t\tctrl.value = '';\n");
            stringBuilder.Append("\t\t\t\tvar coll = document.getElementsByTagName('INPUT');\n");
            stringBuilder.Append("\t\t\t\tif (coll != null)\n");
            stringBuilder.Append("\t\t\t\t\tfor (i = 0; i < coll.length; i++)\n");
            stringBuilder.Append("\t\t\t\t\t{\n");
            stringBuilder.Append("\t\t\t\t\t\tvar sId = null;\n");
            stringBuilder.Append("\t\t\t\t\t\tif (coll[i].type == 'checkbox' || coll[i].type == 'radio')\n");
            stringBuilder.Append("\t\t\t\t\t\t\tif (coll[i].checked)\n");
            stringBuilder.Append("\t\t\t\t\t\t\t\tsId = coll[i].parentNode.getAttribute(\"personid\");\n");
            stringBuilder.Append("\t\t\t\t\t\t\t\tif (sId != null)\n");
            stringBuilder.Append("\t\t\t\t\t\t\t\t{\n");
            stringBuilder.Append("\t\t\t\t\t\t\t\t\tif (ctrl.value == '')\n");
            stringBuilder.Append("\t\t\t\t\t\t\t\t\t\tctrl.value = sId;\n");
            stringBuilder.Append("\t\t\t\t\t\t\t\t\telse\n");
            stringBuilder.Append("\t\t\t\t\t\t\t\t\t\tctrl.value += \",\" + sId;\n");
            stringBuilder.Append("\t\t\t\t\t\t\t\t}\n");
            stringBuilder.Append("\t\t\t\t\t}\n");
            stringBuilder.Append("\t\t\t\t\tif (ctrl.value == '')\n");
            stringBuilder.Append("\t\t\t\t\t{\n");
            stringBuilder.Append("\t\t\t\t\t\talert('You have not picked anyone to select');\n");
            stringBuilder.Append("\t\t\t\t\t\treturn;\n");
            stringBuilder.Append("\t\t\t\t\t}\n");
            stringBuilder.Append(string.Concat("\t\t\t\t\topener.document.frmMain.", base.Request.QueryString["rbID"], ".click();\n"));
            stringBuilder.Append("\t\t\t}\n");
            stringBuilder.Append("\t\t}\n");
            stringBuilder.Append("\t\t\n");
            stringBuilder.Append("\t\tif (returnUrl == '')\n");
            stringBuilder.Append("\t\t\twindow.close();\n");
            stringBuilder.Append("\t\telse\n");
            stringBuilder.Append("\t\t{\n");
            stringBuilder.Append("\t\t\twindow.location.href = returnUrl;\n");
            stringBuilder.Append("\t\t\twindow.focus();\n");
            stringBuilder.Append("\t\t}\n");
            stringBuilder.Append("\t}\n");
            stringBuilder.Append("\tfunction CheckAll(oCheckBox)\n");
            stringBuilder.Append("\t{\n");
            stringBuilder.Append("\t\tvar coll = document.getElementsByTagName('INPUT');\n");
            stringBuilder.Append("\t\tif (coll != null)\n");
            stringBuilder.Append("\t\t\tfor (i = 0; i < coll.length; i++)\n");
            stringBuilder.Append("\t\t\t\tif (coll[i].type == 'checkbox')\n");
            stringBuilder.Append("\t\t\t\t\tif (coll[i] != oCheckBox)\n");
            stringBuilder.Append("\t\t\t\t\t\tcoll[i].checked = oCheckBox.checked;\n");
            stringBuilder.Append("\t}\n");
            stringBuilder.Append("\tfunction UnCheckAllRBs(rbCurrent)\n");
            stringBuilder.Append("\t{\n");
            stringBuilder.Append("\t\tvar coll = document.getElementsByTagName('INPUT');\n");
            stringBuilder.Append("\t\tif (coll != null)\n");
            stringBuilder.Append("\t\t\tfor (i = 0; i < coll.length; i++)\n");
            stringBuilder.Append("\t\t\t\tif (coll[i].type == 'radio')\n");
            stringBuilder.Append("\t\t\t\t\tcoll[i].checked = false;\n");
            stringBuilder.Append("\t\trbCurrent.checked = true;\n");
            stringBuilder.Append("\t}\n");
            stringBuilder.Append("</script>\n\n");
            Page.ClientScript.RegisterClientScriptBlock(base.GetType(), "CheckAll", stringBuilder.ToString());
        }

    }
}