﻿namespace Arena.UserControls.Custom.SALC.ResourceCenter
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Linq;
    using System.Web;
    using System.Web.UI;
    using System.Web.UI.WebControls;
    using Arena.Core;
    using Arena.Portal;
    using Arena.Portal.UI;
    using Arena.Security;
    using Arena.Custom.SALC.ResourceCenter.Entity;

    public partial class OfferSearch : PortalControl
    {

        [PageSetting("Offer Details Page", "The Offer Details page", true)]
        public string OfferDetailsPageSetting { get { return Setting("OfferDetailsPage", "", true); } }

        [PageSetting("Member Details Page", "The Member Details page", true)]
        public string MemberDetailsPageSetting { get { return Setting("MemberDetailsPage", "", true); } }

        private ResourceCenterOfferCollection donations;
        private ArrayList typeList = new ArrayList();

        private class typeListType
        {
            public int index;
            public string value;

            public typeListType()
            {
                index = -1;
                value = "";
            }

            public typeListType(int idx, string val)
            {
                index = idx;
                value = val;
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {

            if (IsPostBack)
            {
                BindDonationGrid();
            }
            else
            {
                dtbEndDate.SelectedDate = DateTime.Today.AddDays(0);
                dtbStartDate.SelectedDate = DateTime.Today.AddDays(-7);
                if (CanEdit)
                {
                    lCreateLink.Text = "<a href=\"default.aspx?page=" + OfferDetailsPageSetting + "\">Add New Offer</a>";
                    DonationGrid.DeleteEnabled = true;
                }
                else
                {
                    lCreateLink.Text = "";
                    DonationGrid.DeleteEnabled = false;
                }

                ResourceCenterDonationTypeCollection types = ResourceCenterDonationTypeCollection.LoadAllWithBlank(CurrentOrganization.OrganizationID);
                ddlType.Items.Clear();
                ddlType.DataSource = types.DataTable();
                ddlType.DataTextField = "Name";
                ddlType.DataValueField = "Id";
                ddlType.DataBind();

                BindDonationGrid();
            }
        }

        protected void BindDonationGrid()
        {
            DateTime st;
            DateTime et;
            if (dtbStartDate.Text == "")
            {
                st = Convert.ToDateTime("1/1/1901");
            }
            else
            {
                st = dtbStartDate.SelectedDate;
            }
            if (dtbEndDate.Text == "")
            {
                et = Convert.ToDateTime("12/31/2199");
            }
            else
            {
                et = dtbEndDate.SelectedDate;
            }
            donations = ResourceCenterOfferCollection.LoadAll(CurrentOrganization.OrganizationID, st, et, "%", "%", Convert.ToInt32(ddlType.SelectedValue), Convert.ToInt32(ddlEStatus.SelectedValue));
            DonationGrid.NoResultText = "There are no results to display.";
            DonationGrid.DataSource = donations.DataTable();
            DonationGrid.DataBind();

            upPartial.Update();
        }

        protected string GenerateNameLink(int personId, string name)
        {
            string s = string.Empty;

            if (personId > 0)
            {
                Person p = new Person(personId);
                if (p.NickName == "")
                {
                    s = p.LastName + ", " + p.FirstName;
                }
                else
                {
                    s = p.LastName + ", " + p.NickName;
                }

                s = "<a href=\"default.aspx?page=" + MemberDetailsPageSetting + "&guid=" + p.PersonGUID.ToString() + "\">" + s + "</a>";
            }
            else
            {
                s = name;
            }
            return s;
        }

        protected string GetTypeName(int type)
        {
            ResourceCenterDonationTypeCollection types = ResourceCenterDonationTypeCollection.LoadAllWithBlank(CurrentOrganization.OrganizationID);
            foreach (ResourceCenterHelpSubType sub in types)
            {
                if (type == sub.Id)
                    return sub.Name;
            }
            return "Unknown";
        }

        protected void DonationGrid_Delete(object sender, DataGridCommandEventArgs e)
        {
            TableCell t = e.Item.Cells[0];
            ResourceCenterOffer.Delete(Convert.ToInt32(t.Text));
            BindDonationGrid();
        }

        protected bool CanEdit
        {
            get
            {
                return CurrentModule.Permissions.Allowed(OperationType.Edit, CurrentUser);
            }
        }

        protected void DonationGrid_ReBind(object sender, EventArgs e)
        {
            BindDonationGrid();
        }

    }
}