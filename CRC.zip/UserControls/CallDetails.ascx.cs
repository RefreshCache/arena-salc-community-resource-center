﻿namespace Arena.UserControls.Custom.SALC.ResourceCenter
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Web;
    using System.Web.UI;
    using System.Web.UI.WebControls;
    using Arena.Core;
    using Arena.Portal;
    using Arena.Portal.UI;
    using Arena.Security;
    using Arena.Custom.SALC.ResourceCenter.Entity;

    public partial class CallDetails : PortalControl
    {
        [PageSetting("Call Search Page", "The Call Search page", true)]
        public string CallSearchPageSetting { get { return Setting("CallSearchPage", "", true); } }

        [PageSetting("Client Details Page", "The Client Details page", true)]
        public string ClientDetailsPageSetting { get { return Setting("ClientDetailsPage", "", true); } }

        [PageSetting("Client Search Popup Page", "The Client Search Popup page", true)]
        public string ClientSearchPopupPageSetting { get { return Setting("ClientSearchPopupPage", "", true); } }

        [PageSetting("Offer Details Page", "The Offer Details page", true)]
        public string OfferDetailsPageSetting { get { return Setting("OfferDetailsPage", "", true); } }

        public int _callId = -1;
        private ResourceCenterCall _calldata = new ResourceCenterCall();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (CanEdit)
                {
                    EditLink.Visible = true;
                    lbCreate.Visible = true;
                }
                else
                {
                    EditLink.Visible = false;
                    lbCreate.Visible = false;
                }
                lPageName.Text = "Call Details";
                iHeaderImage.ImageUrl = "~/Images/whitepages/history.jpg";
                RegisterScripts();
            }

            if (Request.QueryString["callid"] != null)
            {
                _callId = Convert.ToInt32(Request.QueryString["callid"]);
                _calldata = new ResourceCenterCall(_callId);
            }
            else
            {
                _callId = 0;
            }

            if (!IsPostBack)
            {
                SetAutoDate();
                if (_callId > 0)
                {
                    BindViewData();
                    ddlEStatus.Visible = true;
                    cbAuto.Visible = false;
                    cbAuto.Checked = false;
                }
                else
                {
                    _calldata.Date = DateTime.Now;
                    ddlEStatus.Visible = false;
                    BindEditData();
                    cbAuto.Visible = true;
                    cbAuto.Checked = true;
                }
            }
        }

        protected void SetAutoDate()
        {
            if (cbAuto.Checked)
            {
                tbEDate.Enabled = false;
            }
            else
            {
                tbEDate.Enabled = true;
            }
        }

        protected void BindViewData()
        {
            panEdit.Visible = false;
            panView.Visible = true;

            lblVID.Text = _calldata.Id.ToString();
            if (_calldata.Date > Convert.ToDateTime("1/1/1901"))
            {
                lblVDate.Text = _calldata.Date.ToShortDateTimeString();
            }
            else
            {
                lblVDate.Text = "Undefined";
            }
            lblVAttn.Text = _calldata.MessageFor;
            lblVCounty.Text = _calldata.County;
            lblVDate.Text = _calldata.Date.ToShortDateTimeString();
            lblVHH.Text = _calldata.HH.ToString();
            if (_calldata.PersonId > 0)
            {
                ResourceCenterPerson p = new ResourceCenterPerson(_calldata.PersonId);
                lblVName.Text = "<a href=\"default.aspx?page=" + ClientDetailsPageSetting + "&personid=" + _calldata.PersonId.ToString() + "\">" + p.FirstName + " " + p.LastName + "</a>";
                hfPersonId.Value = _calldata.PersonId.ToString();
            }
            else
            {
                lblVName.Text = _calldata.Name;
                hfPersonId.Value = "";
            }
            lblVNotes.Text = _calldata.Notes;
            lblVPhone.Text = _calldata.phone;
            switch (Convert.ToInt32(_calldata.Recieve))
            {
                case 1:
                    lblVRecieve.Text = "Call";
                    break;
                case 2:
                    lblVRecieve.Text = "Walk-In";
                    break;
                default:
                    lblVRecieve.Text = "Unknown";
                    break;
            }

            string s = string.Empty;
            if (_calldata.ReqFood > 0)
                s += "Food<br />";
            if (_calldata.ReqShelter > 0)
                s += "Shelter<br />";
            if (_calldata.ReqRent > 0)
                s += "Rent<br />";
            if (_calldata.ReqUtility > 0)
                s += "Utility<br />";
            if (_calldata.ReqFurn > 0)
                s += "Furniture<br />";
            if (_calldata.ReqOther > 0)
                s += "Other<br />";
            if (s.Length > 0)
            {
                lblVReq.Text = s.Substring(0, s.Length - 6);
            }
            else
            {
                lblVReq.Text = "";
            }
            lblVNotes.Text = _calldata.Notes;

            string url = string.Empty;
            string msg = string.Empty;
            switch (_calldata.Completed)
            {
                case 0:
                    url = "Images/Exclamation.png";
                    msg = "Open";
                    break;
                case 1:
                    url = "Images/CheckMark.png";
                    msg = "Closed";
                    break;
                case 2:
                    url = "Images/Minus.png";
                    msg = "In-Process";
                    break;
                default:
                    imgVStatus.Visible = false;
                    break;
            }
            imgVStatus.ImageUrl = url;
            lblVStatus.Text = msg;
            lVCreateOffer.Text = "";
            switch (_calldata.CallType)
            {
                case 1:
                    lblVType.Text = "Assistance Request";
                    break;
                case 2:
                    lblVType.Text = "Volunteer";
                    break;
                case 3:
                    lblVType.Text = "Info-Request";
                    break;
                case 4:
                    lblVType.Text = "Check-In";
                    break;
                case 5:
                    lblVType.Text = "Donation";
                    lVCreateOffer.Text = "<a href=\"default.aspx?page=" + OfferDetailsPageSetting + "&callid=" + _callId + "\">Create Donation Offer?</a>";
                    break;
                case 6:
                    lblVType.Text = "Agency Rep";
                    break;
                default:
                    lblVType.Text = "Unknown: " + _calldata.CallType.ToString();
                    break;
            }
        }

        protected void BindEditData()
        {
            panEdit.Visible = true;
            panView.Visible = false;

            if (_calldata.Id > 0)
            {
                lblEID.Text = _calldata.Id.ToString();
            }
            else
            {
                lblEID.Text = "Not yet saved!";
            }

            if (_calldata.Date > Convert.ToDateTime("1/1/1901"))
            {
                tbEDate.Text = _calldata.Date.ToShortDateTimeString();
            }
            else
            {
                tbEDate.Text = "";
            }
            tbEHH.Text = _calldata.HH.ToString();

            if (_calldata.PersonId > 0)
            {
                tbEName.Text = _calldata.Name;
                hfPersonId.Value = _calldata.PersonId.ToString();
                tbEName.Visible = false;
                ResourceCenterPerson p = new ResourceCenterPerson(_calldata.PersonId);
                lbFindPerson.Text = p.FirstName + " " + p.LastName;
                ibDelete.Visible = true;
            }
            else
            {
                tbEName.Text = _calldata.Name;
                tbEName.Visible = true;
                lbFindPerson.Text = "Find...";
                ibDelete.Visible = false;
            }
            tbENotes.Text = _calldata.Notes;
            tbEPhone.Text = _calldata.phone;

            ddlECounty.SelectedValue = _calldata.County;
            ddlEMessageFor.SelectedValue = _calldata.MessageFor;
            ddlERecieve.SelectedValue = _calldata.Recieve.ToString();
            ddlEType.SelectedValue = _calldata.CallType.ToString();

            cbReqFood.Checked = (_calldata.ReqFood > 0);
            cbReqFurn.Checked = (_calldata.ReqFurn > 0);
            cbReqOther.Checked = (_calldata.ReqOther > 0);
            cbReqRent.Checked = (_calldata.ReqRent > 0);
            cbReqShelter.Checked = (_calldata.ReqShelter > 0);
            cbReqUtility.Checked = (_calldata.ReqUtility > 0);

            ddlEStatus.SelectedValue = _calldata.Completed.ToString();
        }

        protected void Edit_Click(object sender, EventArgs e)
        {
            BindEditData();
        }

        protected void List_Click(object sender, EventArgs e)
        {
            Response.Redirect("default.aspx?page=" + CallSearchPageSetting);
        }

        protected void Create_Click(object sender, EventArgs e)
        {
            string page = Request.QueryString["page"];
            Response.Redirect("default.aspx?page=" + page);
        }

        protected void Save_Click(object sender, EventArgs e)
        {
            if (Page.IsValid)
            {
                _calldata.OrganizationId = CurrentOrganization.OrganizationID;
                if (hfPersonId.Value != "")
                {
                    _calldata.PersonId = Convert.ToInt32(hfPersonId.Value);
                }
                _calldata.CallType = Convert.ToInt32(ddlEType.SelectedValue);
                _calldata.County = ddlECounty.SelectedValue;
                if (cbAuto.Checked)
                {
                    _calldata.Date = DateTime.Now;
                }
                else
                {
                    _calldata.Date = Convert.ToDateTime(tbEDate.Text);
                }
                _calldata.HH = Convert.ToInt32(tbEHH.Text);
                _calldata.MessageFor = ddlEMessageFor.SelectedValue;
                if (_calldata.MessageFor == "CRC Volunteer")
                {
                    _calldata.Completed = 1;
                }
                _calldata.Name = tbEName.Text;
                _calldata.Notes = tbENotes.Text;
                _calldata.phone = tbEPhone.Text;
                _calldata.Recieve = Convert.ToInt32(ddlERecieve.Text);
                if (cbReqFood.Checked)
                {
                    _calldata.ReqFood = 1;
                }
                else
                {
                    _calldata.ReqFood = 0;
                }

                if (cbReqFurn.Checked)
                {
                    _calldata.ReqFurn = 1;
                }
                else
                {
                    _calldata.ReqFurn = 0;
                }

                if (cbReqOther.Checked)
                {
                    _calldata.ReqOther = 1;
                }
                else
                {
                    _calldata.ReqOther = 0;
                }

                if (cbReqRent.Checked)
                {
                    _calldata.ReqRent = 1;
                }
                else
                {
                    _calldata.ReqRent = 0;
                }

                if (cbReqShelter.Checked)
                {
                    _calldata.ReqShelter = 1;
                }
                else
                {
                    _calldata.ReqShelter = 0;
                }

                if (cbReqUtility.Checked)
                {
                    _calldata.ReqUtility = 1;
                }
                else
                {
                    _calldata.ReqUtility = 0;
                }

                _calldata.Completed = Convert.ToInt32(ddlEStatus.SelectedValue);

                _calldata.Save(Page.User.Identity.Name);
                _calldata = new ResourceCenterCall(_calldata.Id);
                //BindViewData();

                string page = Request.QueryString["page"];
                Response.Redirect("default.aspx?page=" + page + "&callid=" + _calldata.Id);
            }
        }

        protected void Cancel_Click(object sender, EventArgs e)
        {
            if (_callId > 0)
            {
                BindViewData();
            }
            else
            {
                Response.Redirect("default.aspx?page=" + CallSearchPageSetting);
            }
        }

        protected bool CanEdit
        {
            get
            {
                return CurrentModule.Permissions.Allowed(OperationType.Edit, CurrentUser);
            }
        }

        protected void btnRefresh_Click(object sender, EventArgs e)
        {
            if (ihPersonList.Value != "")
            {
                ResourceCenterPerson rcClient = new ResourceCenterPerson(Convert.ToInt32(ihPersonList.Value.Trim()));
                tbEName.Visible = false;
                lbFindPerson.Text = rcClient.FirstName + " " + rcClient.LastName;
                hfPersonId.Value = ihPersonList.Value.Trim();
                ibDelete.Visible = true;
                if (tbEName.Text == "")
                {
                    tbEName.Text = lbFindPerson.Text;
                }
            }
            ihPersonList.Value = "";
        }

        private void RegisterScripts()
        {
            StringBuilder sbScript = new StringBuilder();
            sbScript.Append("\n\n<script language=\"javascript\">\n");
            sbScript.Append("\tfunction openSearchWindow()\n");
            sbScript.Append("\t{\n");
            sbScript.Append("\t\tvar tPos = window.screenTop + 100;\n");
            sbScript.Append("\t\tvar lPos = window.screenLeft + 100;\n");
            sbScript.AppendFormat("\t\tdocument.frmMain.ihPersonListID.value = '{0}';\n", ihPersonList.ClientID);
            sbScript.AppendFormat("\t\tdocument.frmMain.ihRefreshButtonID.value = '{0}';\n", btnRefresh.ClientID);
            sbScript.AppendFormat("\t\tvar searchWindow = window.open('Default.aspx?page={2}&plID={0}&rbID={1}','Search','height=400,width=600,resizable=yes,scrollbars=yes,toolbar=no,location=no,directories=no,status=no,menubar=no,top=' + tPos + ',left=' + lPos);\n", ihPersonList.ClientID, btnRefresh.ClientID, ClientSearchPopupPageSetting);
            sbScript.Append("\t\tsearchWindow.focus();\n");
            sbScript.Append("\t}\n");
            sbScript.Append("</script>\n\n");
            Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "OpenSearchWindow", sbScript.ToString());
        }

        protected void DeletePerson_Click(object sender, EventArgs e)
        {
            ibDelete.Visible = false;
            tbEName.Visible = true;
            lbFindPerson.Text = "Find...";
            hfPersonId.Value = "";
        }

    }
}